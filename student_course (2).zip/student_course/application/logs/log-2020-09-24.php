<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-24 10:22:24 --> Config Class Initialized
INFO - 2020-09-24 10:22:24 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:22:24 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:22:24 --> Utf8 Class Initialized
INFO - 2020-09-24 10:22:24 --> URI Class Initialized
DEBUG - 2020-09-24 10:22:24 --> No URI present. Default controller set.
INFO - 2020-09-24 10:22:24 --> Router Class Initialized
INFO - 2020-09-24 10:22:25 --> Output Class Initialized
INFO - 2020-09-24 10:22:25 --> Security Class Initialized
DEBUG - 2020-09-24 10:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:22:25 --> Input Class Initialized
INFO - 2020-09-24 10:22:25 --> Language Class Initialized
INFO - 2020-09-24 10:22:25 --> Loader Class Initialized
INFO - 2020-09-24 10:22:25 --> Helper loaded: url_helper
INFO - 2020-09-24 10:22:25 --> Helper loaded: file_helper
INFO - 2020-09-24 10:22:25 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:22:25 --> Helper loaded: form_helper
INFO - 2020-09-24 10:22:25 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:22:25 --> Controller Class Initialized
INFO - 2020-09-24 10:22:25 --> Model Class Initialized
INFO - 2020-09-24 10:22:25 --> Config Class Initialized
INFO - 2020-09-24 10:22:25 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:22:25 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:22:25 --> Utf8 Class Initialized
INFO - 2020-09-24 10:22:25 --> URI Class Initialized
INFO - 2020-09-24 10:22:25 --> Router Class Initialized
INFO - 2020-09-24 10:22:25 --> Output Class Initialized
INFO - 2020-09-24 10:22:25 --> Security Class Initialized
DEBUG - 2020-09-24 10:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:22:25 --> Input Class Initialized
INFO - 2020-09-24 10:22:25 --> Language Class Initialized
INFO - 2020-09-24 10:22:25 --> Loader Class Initialized
INFO - 2020-09-24 10:22:25 --> Helper loaded: url_helper
INFO - 2020-09-24 10:22:25 --> Helper loaded: file_helper
INFO - 2020-09-24 10:22:25 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:22:25 --> Helper loaded: form_helper
INFO - 2020-09-24 10:22:25 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:22:25 --> Controller Class Initialized
INFO - 2020-09-24 10:22:25 --> Model Class Initialized
INFO - 2020-09-24 10:22:25 --> File loaded: C:\xampp\htdocs\student_course\application\views\login.php
INFO - 2020-09-24 10:22:25 --> Final output sent to browser
DEBUG - 2020-09-24 10:22:25 --> Total execution time: 0.1180
INFO - 2020-09-24 10:26:03 --> Config Class Initialized
INFO - 2020-09-24 10:26:03 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:26:03 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:26:03 --> Utf8 Class Initialized
INFO - 2020-09-24 10:26:03 --> URI Class Initialized
INFO - 2020-09-24 10:26:03 --> Router Class Initialized
INFO - 2020-09-24 10:26:03 --> Output Class Initialized
INFO - 2020-09-24 10:26:03 --> Security Class Initialized
DEBUG - 2020-09-24 10:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:26:03 --> Input Class Initialized
INFO - 2020-09-24 10:26:03 --> Language Class Initialized
INFO - 2020-09-24 10:26:03 --> Loader Class Initialized
INFO - 2020-09-24 10:26:03 --> Helper loaded: url_helper
INFO - 2020-09-24 10:26:03 --> Helper loaded: file_helper
INFO - 2020-09-24 10:26:03 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:26:03 --> Helper loaded: form_helper
INFO - 2020-09-24 10:26:03 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:26:03 --> Controller Class Initialized
INFO - 2020-09-24 10:26:03 --> Model Class Initialized
INFO - 2020-09-24 10:26:03 --> Form Validation Class Initialized
INFO - 2020-09-24 10:26:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-24 10:26:03 --> File loaded: C:\xampp\htdocs\student_course\application\views\header.php
INFO - 2020-09-24 10:26:03 --> File loaded: C:\xampp\htdocs\student_course\application\views\login.php
INFO - 2020-09-24 10:26:03 --> Final output sent to browser
DEBUG - 2020-09-24 10:26:03 --> Total execution time: 0.3902
INFO - 2020-09-24 10:26:08 --> Config Class Initialized
INFO - 2020-09-24 10:26:08 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:26:08 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:26:08 --> Utf8 Class Initialized
INFO - 2020-09-24 10:26:08 --> URI Class Initialized
INFO - 2020-09-24 10:26:08 --> Router Class Initialized
INFO - 2020-09-24 10:26:08 --> Output Class Initialized
INFO - 2020-09-24 10:26:08 --> Security Class Initialized
DEBUG - 2020-09-24 10:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:26:08 --> Input Class Initialized
INFO - 2020-09-24 10:26:08 --> Language Class Initialized
INFO - 2020-09-24 10:26:08 --> Loader Class Initialized
INFO - 2020-09-24 10:26:08 --> Helper loaded: url_helper
INFO - 2020-09-24 10:26:08 --> Helper loaded: file_helper
INFO - 2020-09-24 10:26:08 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:26:08 --> Helper loaded: form_helper
INFO - 2020-09-24 10:26:08 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:26:08 --> Controller Class Initialized
INFO - 2020-09-24 10:26:08 --> Model Class Initialized
INFO - 2020-09-24 10:26:08 --> Form Validation Class Initialized
INFO - 2020-09-24 10:26:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-24 10:26:08 --> User Agent Class Initialized
INFO - 2020-09-24 10:26:08 --> Config Class Initialized
INFO - 2020-09-24 10:26:08 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:26:08 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:26:08 --> Utf8 Class Initialized
INFO - 2020-09-24 10:26:08 --> URI Class Initialized
INFO - 2020-09-24 10:26:08 --> Router Class Initialized
INFO - 2020-09-24 10:26:08 --> Output Class Initialized
INFO - 2020-09-24 10:26:08 --> Security Class Initialized
DEBUG - 2020-09-24 10:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:26:08 --> Input Class Initialized
INFO - 2020-09-24 10:26:08 --> Language Class Initialized
INFO - 2020-09-24 10:26:08 --> Loader Class Initialized
INFO - 2020-09-24 10:26:08 --> Helper loaded: url_helper
INFO - 2020-09-24 10:26:08 --> Helper loaded: file_helper
INFO - 2020-09-24 10:26:08 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:26:08 --> Helper loaded: form_helper
INFO - 2020-09-24 10:26:08 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:26:08 --> Controller Class Initialized
INFO - 2020-09-24 10:26:08 --> Model Class Initialized
INFO - 2020-09-24 10:26:08 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-24 10:26:09 --> File loaded: C:\xampp\htdocs\student_course\application\views\dashboard.php
INFO - 2020-09-24 10:26:09 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-24 10:26:09 --> Final output sent to browser
DEBUG - 2020-09-24 10:26:09 --> Total execution time: 0.2158
INFO - 2020-09-24 10:26:32 --> Config Class Initialized
INFO - 2020-09-24 10:26:32 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:26:32 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:26:32 --> Utf8 Class Initialized
INFO - 2020-09-24 10:26:32 --> URI Class Initialized
INFO - 2020-09-24 10:26:32 --> Router Class Initialized
INFO - 2020-09-24 10:26:32 --> Output Class Initialized
INFO - 2020-09-24 10:26:32 --> Security Class Initialized
DEBUG - 2020-09-24 10:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:26:32 --> Input Class Initialized
INFO - 2020-09-24 10:26:32 --> Language Class Initialized
INFO - 2020-09-24 10:26:32 --> Loader Class Initialized
INFO - 2020-09-24 10:26:32 --> Helper loaded: url_helper
INFO - 2020-09-24 10:26:32 --> Helper loaded: file_helper
INFO - 2020-09-24 10:26:32 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:26:32 --> Helper loaded: form_helper
INFO - 2020-09-24 10:26:32 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:26:32 --> Controller Class Initialized
INFO - 2020-09-24 10:26:32 --> Model Class Initialized
INFO - 2020-09-24 10:26:32 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-24 10:26:32 --> File loaded: C:\xampp\htdocs\student_course\application\views\Student/studentListing.php
INFO - 2020-09-24 10:26:32 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-24 10:26:32 --> Final output sent to browser
DEBUG - 2020-09-24 10:26:32 --> Total execution time: 0.1263
INFO - 2020-09-24 10:26:32 --> Config Class Initialized
INFO - 2020-09-24 10:26:32 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:26:32 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:26:32 --> Utf8 Class Initialized
INFO - 2020-09-24 10:26:32 --> URI Class Initialized
INFO - 2020-09-24 10:26:32 --> Router Class Initialized
INFO - 2020-09-24 10:26:32 --> Output Class Initialized
INFO - 2020-09-24 10:26:32 --> Security Class Initialized
DEBUG - 2020-09-24 10:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:26:32 --> Input Class Initialized
INFO - 2020-09-24 10:26:32 --> Language Class Initialized
ERROR - 2020-09-24 10:26:32 --> 404 Page Not Found: Assets/js
INFO - 2020-09-24 10:26:33 --> Config Class Initialized
INFO - 2020-09-24 10:26:33 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:26:33 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:26:33 --> Utf8 Class Initialized
INFO - 2020-09-24 10:26:33 --> URI Class Initialized
INFO - 2020-09-24 10:26:33 --> Router Class Initialized
INFO - 2020-09-24 10:26:33 --> Output Class Initialized
INFO - 2020-09-24 10:26:33 --> Security Class Initialized
DEBUG - 2020-09-24 10:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:26:33 --> Input Class Initialized
INFO - 2020-09-24 10:26:33 --> Language Class Initialized
ERROR - 2020-09-24 10:26:33 --> 404 Page Not Found: Assets/js
INFO - 2020-09-24 10:26:33 --> Config Class Initialized
INFO - 2020-09-24 10:26:33 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:26:33 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:26:33 --> Utf8 Class Initialized
INFO - 2020-09-24 10:26:33 --> URI Class Initialized
INFO - 2020-09-24 10:26:33 --> Router Class Initialized
INFO - 2020-09-24 10:26:33 --> Output Class Initialized
INFO - 2020-09-24 10:26:33 --> Security Class Initialized
DEBUG - 2020-09-24 10:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:26:33 --> Input Class Initialized
INFO - 2020-09-24 10:26:33 --> Language Class Initialized
INFO - 2020-09-24 10:26:33 --> Loader Class Initialized
INFO - 2020-09-24 10:26:33 --> Helper loaded: url_helper
INFO - 2020-09-24 10:26:33 --> Helper loaded: file_helper
INFO - 2020-09-24 10:26:33 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:26:33 --> Helper loaded: form_helper
INFO - 2020-09-24 10:26:33 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:26:33 --> Controller Class Initialized
INFO - 2020-09-24 10:26:33 --> Model Class Initialized
INFO - 2020-09-24 10:26:33 --> Final output sent to browser
DEBUG - 2020-09-24 10:26:33 --> Total execution time: 0.0840
INFO - 2020-09-24 10:27:39 --> Config Class Initialized
INFO - 2020-09-24 10:27:39 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:27:39 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:27:39 --> Utf8 Class Initialized
INFO - 2020-09-24 10:27:39 --> URI Class Initialized
INFO - 2020-09-24 10:27:39 --> Router Class Initialized
INFO - 2020-09-24 10:27:39 --> Output Class Initialized
INFO - 2020-09-24 10:27:39 --> Security Class Initialized
DEBUG - 2020-09-24 10:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:27:39 --> Input Class Initialized
INFO - 2020-09-24 10:27:39 --> Language Class Initialized
INFO - 2020-09-24 10:27:39 --> Loader Class Initialized
INFO - 2020-09-24 10:27:39 --> Helper loaded: url_helper
INFO - 2020-09-24 10:27:39 --> Helper loaded: file_helper
INFO - 2020-09-24 10:27:39 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:27:39 --> Helper loaded: form_helper
INFO - 2020-09-24 10:27:39 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:27:39 --> Controller Class Initialized
INFO - 2020-09-24 10:27:39 --> Model Class Initialized
INFO - 2020-09-24 10:27:39 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-24 10:27:39 --> File loaded: C:\xampp\htdocs\student_course\application\views\Student/addStudent.php
INFO - 2020-09-24 10:27:39 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-24 10:27:39 --> Final output sent to browser
DEBUG - 2020-09-24 10:27:39 --> Total execution time: 0.0791
INFO - 2020-09-24 10:28:02 --> Config Class Initialized
INFO - 2020-09-24 10:28:02 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:28:02 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:28:02 --> Utf8 Class Initialized
INFO - 2020-09-24 10:28:02 --> URI Class Initialized
INFO - 2020-09-24 10:28:02 --> Router Class Initialized
INFO - 2020-09-24 10:28:02 --> Output Class Initialized
INFO - 2020-09-24 10:28:02 --> Security Class Initialized
DEBUG - 2020-09-24 10:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:28:02 --> Input Class Initialized
INFO - 2020-09-24 10:28:02 --> Language Class Initialized
INFO - 2020-09-24 10:28:02 --> Loader Class Initialized
INFO - 2020-09-24 10:28:02 --> Helper loaded: url_helper
INFO - 2020-09-24 10:28:02 --> Helper loaded: file_helper
INFO - 2020-09-24 10:28:02 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:28:02 --> Helper loaded: form_helper
INFO - 2020-09-24 10:28:02 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:28:02 --> Controller Class Initialized
INFO - 2020-09-24 10:28:02 --> Model Class Initialized
INFO - 2020-09-24 10:28:02 --> Form Validation Class Initialized
INFO - 2020-09-24 10:28:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-24 10:28:02 --> Config Class Initialized
INFO - 2020-09-24 10:28:02 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:28:02 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:28:02 --> Utf8 Class Initialized
INFO - 2020-09-24 10:28:02 --> URI Class Initialized
INFO - 2020-09-24 10:28:02 --> Router Class Initialized
INFO - 2020-09-24 10:28:02 --> Output Class Initialized
INFO - 2020-09-24 10:28:02 --> Security Class Initialized
DEBUG - 2020-09-24 10:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:28:02 --> Input Class Initialized
INFO - 2020-09-24 10:28:02 --> Language Class Initialized
ERROR - 2020-09-24 10:28:02 --> 404 Page Not Found: AddStudent/index
INFO - 2020-09-24 10:28:04 --> Config Class Initialized
INFO - 2020-09-24 10:28:04 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:28:04 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:28:04 --> Utf8 Class Initialized
INFO - 2020-09-24 10:28:04 --> URI Class Initialized
INFO - 2020-09-24 10:28:04 --> Router Class Initialized
INFO - 2020-09-24 10:28:04 --> Output Class Initialized
INFO - 2020-09-24 10:28:04 --> Security Class Initialized
DEBUG - 2020-09-24 10:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:28:04 --> Input Class Initialized
INFO - 2020-09-24 10:28:04 --> Language Class Initialized
INFO - 2020-09-24 10:28:04 --> Loader Class Initialized
INFO - 2020-09-24 10:28:04 --> Helper loaded: url_helper
INFO - 2020-09-24 10:28:04 --> Helper loaded: file_helper
INFO - 2020-09-24 10:28:04 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:28:04 --> Helper loaded: form_helper
INFO - 2020-09-24 10:28:04 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:28:04 --> Controller Class Initialized
INFO - 2020-09-24 10:28:04 --> Model Class Initialized
INFO - 2020-09-24 10:28:04 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-24 10:28:04 --> File loaded: C:\xampp\htdocs\student_course\application\views\Student/addStudent.php
INFO - 2020-09-24 10:28:04 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-24 10:28:04 --> Final output sent to browser
DEBUG - 2020-09-24 10:28:04 --> Total execution time: 0.0594
INFO - 2020-09-24 10:29:17 --> Config Class Initialized
INFO - 2020-09-24 10:29:17 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:17 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:17 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:17 --> URI Class Initialized
INFO - 2020-09-24 10:29:17 --> Router Class Initialized
INFO - 2020-09-24 10:29:17 --> Output Class Initialized
INFO - 2020-09-24 10:29:17 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:17 --> Input Class Initialized
INFO - 2020-09-24 10:29:17 --> Language Class Initialized
INFO - 2020-09-24 10:29:17 --> Loader Class Initialized
INFO - 2020-09-24 10:29:17 --> Helper loaded: url_helper
INFO - 2020-09-24 10:29:17 --> Helper loaded: file_helper
INFO - 2020-09-24 10:29:17 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:29:17 --> Helper loaded: form_helper
INFO - 2020-09-24 10:29:17 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:29:17 --> Controller Class Initialized
INFO - 2020-09-24 10:29:17 --> Model Class Initialized
INFO - 2020-09-24 10:29:17 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-24 10:29:17 --> File loaded: C:\xampp\htdocs\student_course\application\views\Student/studentListing.php
INFO - 2020-09-24 10:29:17 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-24 10:29:17 --> Final output sent to browser
DEBUG - 2020-09-24 10:29:17 --> Total execution time: 0.0666
INFO - 2020-09-24 10:29:17 --> Config Class Initialized
INFO - 2020-09-24 10:29:17 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:17 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:17 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:17 --> URI Class Initialized
INFO - 2020-09-24 10:29:17 --> Router Class Initialized
INFO - 2020-09-24 10:29:17 --> Output Class Initialized
INFO - 2020-09-24 10:29:17 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:17 --> Input Class Initialized
INFO - 2020-09-24 10:29:17 --> Language Class Initialized
ERROR - 2020-09-24 10:29:17 --> 404 Page Not Found: Assets/js
INFO - 2020-09-24 10:29:18 --> Config Class Initialized
INFO - 2020-09-24 10:29:18 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:18 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:18 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:18 --> URI Class Initialized
INFO - 2020-09-24 10:29:18 --> Router Class Initialized
INFO - 2020-09-24 10:29:18 --> Output Class Initialized
INFO - 2020-09-24 10:29:18 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:18 --> Input Class Initialized
INFO - 2020-09-24 10:29:18 --> Language Class Initialized
ERROR - 2020-09-24 10:29:18 --> 404 Page Not Found: Assets/js
INFO - 2020-09-24 10:29:18 --> Config Class Initialized
INFO - 2020-09-24 10:29:18 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:18 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:18 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:18 --> URI Class Initialized
INFO - 2020-09-24 10:29:18 --> Router Class Initialized
INFO - 2020-09-24 10:29:18 --> Output Class Initialized
INFO - 2020-09-24 10:29:18 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:18 --> Input Class Initialized
INFO - 2020-09-24 10:29:18 --> Language Class Initialized
INFO - 2020-09-24 10:29:18 --> Loader Class Initialized
INFO - 2020-09-24 10:29:18 --> Helper loaded: url_helper
INFO - 2020-09-24 10:29:18 --> Helper loaded: file_helper
INFO - 2020-09-24 10:29:18 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:29:18 --> Helper loaded: form_helper
INFO - 2020-09-24 10:29:18 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:29:18 --> Controller Class Initialized
INFO - 2020-09-24 10:29:18 --> Model Class Initialized
INFO - 2020-09-24 10:29:18 --> Final output sent to browser
DEBUG - 2020-09-24 10:29:18 --> Total execution time: 0.0728
INFO - 2020-09-24 10:29:28 --> Config Class Initialized
INFO - 2020-09-24 10:29:28 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:28 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:28 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:28 --> URI Class Initialized
INFO - 2020-09-24 10:29:28 --> Router Class Initialized
INFO - 2020-09-24 10:29:28 --> Output Class Initialized
INFO - 2020-09-24 10:29:28 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:28 --> Input Class Initialized
INFO - 2020-09-24 10:29:28 --> Language Class Initialized
INFO - 2020-09-24 10:29:28 --> Loader Class Initialized
INFO - 2020-09-24 10:29:28 --> Helper loaded: url_helper
INFO - 2020-09-24 10:29:28 --> Helper loaded: file_helper
INFO - 2020-09-24 10:29:28 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:29:28 --> Helper loaded: form_helper
INFO - 2020-09-24 10:29:28 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:29:28 --> Controller Class Initialized
INFO - 2020-09-24 10:29:28 --> Model Class Initialized
INFO - 2020-09-24 10:29:28 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-24 10:29:28 --> File loaded: C:\xampp\htdocs\student_course\application\views\Student/editStudentDetails.php
INFO - 2020-09-24 10:29:28 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-24 10:29:28 --> Final output sent to browser
DEBUG - 2020-09-24 10:29:28 --> Total execution time: 0.0982
INFO - 2020-09-24 10:29:37 --> Config Class Initialized
INFO - 2020-09-24 10:29:37 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:37 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:37 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:37 --> URI Class Initialized
INFO - 2020-09-24 10:29:37 --> Router Class Initialized
INFO - 2020-09-24 10:29:37 --> Output Class Initialized
INFO - 2020-09-24 10:29:37 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:37 --> Input Class Initialized
INFO - 2020-09-24 10:29:37 --> Language Class Initialized
INFO - 2020-09-24 10:29:37 --> Loader Class Initialized
INFO - 2020-09-24 10:29:37 --> Helper loaded: url_helper
INFO - 2020-09-24 10:29:37 --> Helper loaded: file_helper
INFO - 2020-09-24 10:29:37 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:29:37 --> Helper loaded: form_helper
INFO - 2020-09-24 10:29:37 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:29:37 --> Controller Class Initialized
INFO - 2020-09-24 10:29:37 --> Model Class Initialized
INFO - 2020-09-24 10:29:37 --> Form Validation Class Initialized
INFO - 2020-09-24 10:29:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-24 10:29:37 --> Config Class Initialized
INFO - 2020-09-24 10:29:37 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:37 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:37 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:37 --> URI Class Initialized
INFO - 2020-09-24 10:29:37 --> Router Class Initialized
INFO - 2020-09-24 10:29:37 --> Output Class Initialized
INFO - 2020-09-24 10:29:37 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:37 --> Input Class Initialized
INFO - 2020-09-24 10:29:37 --> Language Class Initialized
INFO - 2020-09-24 10:29:37 --> Loader Class Initialized
INFO - 2020-09-24 10:29:37 --> Helper loaded: url_helper
INFO - 2020-09-24 10:29:37 --> Helper loaded: file_helper
INFO - 2020-09-24 10:29:37 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:29:37 --> Helper loaded: form_helper
INFO - 2020-09-24 10:29:37 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:29:37 --> Controller Class Initialized
INFO - 2020-09-24 10:29:37 --> Model Class Initialized
INFO - 2020-09-24 10:29:37 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-24 10:29:37 --> File loaded: C:\xampp\htdocs\student_course\application\views\Student/editStudentDetails.php
INFO - 2020-09-24 10:29:37 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-24 10:29:37 --> Final output sent to browser
DEBUG - 2020-09-24 10:29:37 --> Total execution time: 0.0573
INFO - 2020-09-24 10:29:42 --> Config Class Initialized
INFO - 2020-09-24 10:29:42 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:42 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:42 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:42 --> URI Class Initialized
INFO - 2020-09-24 10:29:42 --> Router Class Initialized
INFO - 2020-09-24 10:29:42 --> Output Class Initialized
INFO - 2020-09-24 10:29:42 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:42 --> Input Class Initialized
INFO - 2020-09-24 10:29:42 --> Language Class Initialized
INFO - 2020-09-24 10:29:42 --> Loader Class Initialized
INFO - 2020-09-24 10:29:42 --> Helper loaded: url_helper
INFO - 2020-09-24 10:29:42 --> Helper loaded: file_helper
INFO - 2020-09-24 10:29:42 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:29:42 --> Helper loaded: form_helper
INFO - 2020-09-24 10:29:42 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:29:42 --> Controller Class Initialized
INFO - 2020-09-24 10:29:42 --> Model Class Initialized
INFO - 2020-09-24 10:29:42 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-24 10:29:42 --> File loaded: C:\xampp\htdocs\student_course\application\views\Student/studentListing.php
INFO - 2020-09-24 10:29:42 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-24 10:29:42 --> Final output sent to browser
DEBUG - 2020-09-24 10:29:42 --> Total execution time: 0.0638
INFO - 2020-09-24 10:29:42 --> Config Class Initialized
INFO - 2020-09-24 10:29:42 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:42 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:42 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:42 --> URI Class Initialized
INFO - 2020-09-24 10:29:42 --> Router Class Initialized
INFO - 2020-09-24 10:29:42 --> Output Class Initialized
INFO - 2020-09-24 10:29:42 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:42 --> Input Class Initialized
INFO - 2020-09-24 10:29:42 --> Language Class Initialized
ERROR - 2020-09-24 10:29:42 --> 404 Page Not Found: Assets/js
INFO - 2020-09-24 10:29:43 --> Config Class Initialized
INFO - 2020-09-24 10:29:43 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:43 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:43 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:43 --> URI Class Initialized
INFO - 2020-09-24 10:29:43 --> Router Class Initialized
INFO - 2020-09-24 10:29:43 --> Output Class Initialized
INFO - 2020-09-24 10:29:43 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:43 --> Input Class Initialized
INFO - 2020-09-24 10:29:43 --> Language Class Initialized
ERROR - 2020-09-24 10:29:43 --> 404 Page Not Found: Assets/js
INFO - 2020-09-24 10:29:43 --> Config Class Initialized
INFO - 2020-09-24 10:29:43 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:43 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:43 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:43 --> URI Class Initialized
INFO - 2020-09-24 10:29:43 --> Router Class Initialized
INFO - 2020-09-24 10:29:43 --> Output Class Initialized
INFO - 2020-09-24 10:29:43 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:43 --> Input Class Initialized
INFO - 2020-09-24 10:29:43 --> Language Class Initialized
INFO - 2020-09-24 10:29:43 --> Loader Class Initialized
INFO - 2020-09-24 10:29:43 --> Helper loaded: url_helper
INFO - 2020-09-24 10:29:43 --> Helper loaded: file_helper
INFO - 2020-09-24 10:29:43 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:29:43 --> Helper loaded: form_helper
INFO - 2020-09-24 10:29:43 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:29:43 --> Controller Class Initialized
INFO - 2020-09-24 10:29:43 --> Model Class Initialized
INFO - 2020-09-24 10:29:43 --> Final output sent to browser
DEBUG - 2020-09-24 10:29:43 --> Total execution time: 0.0936
INFO - 2020-09-24 10:29:48 --> Config Class Initialized
INFO - 2020-09-24 10:29:48 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:48 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:48 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:48 --> URI Class Initialized
INFO - 2020-09-24 10:29:48 --> Router Class Initialized
INFO - 2020-09-24 10:29:48 --> Output Class Initialized
INFO - 2020-09-24 10:29:48 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:48 --> Input Class Initialized
INFO - 2020-09-24 10:29:48 --> Language Class Initialized
INFO - 2020-09-24 10:29:48 --> Loader Class Initialized
INFO - 2020-09-24 10:29:48 --> Helper loaded: url_helper
INFO - 2020-09-24 10:29:48 --> Helper loaded: file_helper
INFO - 2020-09-24 10:29:48 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:29:48 --> Helper loaded: form_helper
INFO - 2020-09-24 10:29:48 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:29:48 --> Controller Class Initialized
INFO - 2020-09-24 10:29:48 --> Model Class Initialized
INFO - 2020-09-24 10:29:48 --> Config Class Initialized
INFO - 2020-09-24 10:29:48 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:48 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:48 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:48 --> URI Class Initialized
INFO - 2020-09-24 10:29:48 --> Router Class Initialized
INFO - 2020-09-24 10:29:48 --> Output Class Initialized
INFO - 2020-09-24 10:29:48 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:48 --> Input Class Initialized
INFO - 2020-09-24 10:29:48 --> Language Class Initialized
INFO - 2020-09-24 10:29:48 --> Loader Class Initialized
INFO - 2020-09-24 10:29:48 --> Helper loaded: url_helper
INFO - 2020-09-24 10:29:48 --> Helper loaded: file_helper
INFO - 2020-09-24 10:29:48 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:29:48 --> Helper loaded: form_helper
INFO - 2020-09-24 10:29:48 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:29:48 --> Controller Class Initialized
INFO - 2020-09-24 10:29:48 --> Model Class Initialized
INFO - 2020-09-24 10:29:48 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-24 10:29:48 --> File loaded: C:\xampp\htdocs\student_course\application\views\Student/studentListing.php
INFO - 2020-09-24 10:29:48 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-24 10:29:48 --> Final output sent to browser
DEBUG - 2020-09-24 10:29:48 --> Total execution time: 0.0527
INFO - 2020-09-24 10:29:48 --> Config Class Initialized
INFO - 2020-09-24 10:29:48 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:48 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:48 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:48 --> URI Class Initialized
INFO - 2020-09-24 10:29:48 --> Router Class Initialized
INFO - 2020-09-24 10:29:48 --> Output Class Initialized
INFO - 2020-09-24 10:29:48 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:48 --> Input Class Initialized
INFO - 2020-09-24 10:29:49 --> Language Class Initialized
ERROR - 2020-09-24 10:29:49 --> 404 Page Not Found: Assets/js
INFO - 2020-09-24 10:29:49 --> Config Class Initialized
INFO - 2020-09-24 10:29:49 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:49 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:49 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:49 --> URI Class Initialized
INFO - 2020-09-24 10:29:49 --> Router Class Initialized
INFO - 2020-09-24 10:29:49 --> Output Class Initialized
INFO - 2020-09-24 10:29:49 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:49 --> Input Class Initialized
INFO - 2020-09-24 10:29:49 --> Language Class Initialized
ERROR - 2020-09-24 10:29:49 --> 404 Page Not Found: Assets/js
INFO - 2020-09-24 10:29:49 --> Config Class Initialized
INFO - 2020-09-24 10:29:49 --> Hooks Class Initialized
DEBUG - 2020-09-24 10:29:49 --> UTF-8 Support Enabled
INFO - 2020-09-24 10:29:49 --> Utf8 Class Initialized
INFO - 2020-09-24 10:29:49 --> URI Class Initialized
INFO - 2020-09-24 10:29:49 --> Router Class Initialized
INFO - 2020-09-24 10:29:49 --> Output Class Initialized
INFO - 2020-09-24 10:29:49 --> Security Class Initialized
DEBUG - 2020-09-24 10:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-24 10:29:49 --> Input Class Initialized
INFO - 2020-09-24 10:29:49 --> Language Class Initialized
INFO - 2020-09-24 10:29:49 --> Loader Class Initialized
INFO - 2020-09-24 10:29:49 --> Helper loaded: url_helper
INFO - 2020-09-24 10:29:49 --> Helper loaded: file_helper
INFO - 2020-09-24 10:29:49 --> Helper loaded: cias_helper
INFO - 2020-09-24 10:29:49 --> Helper loaded: form_helper
INFO - 2020-09-24 10:29:49 --> Database Driver Class Initialized
DEBUG - 2020-09-24 10:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-24 10:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-24 10:29:49 --> Controller Class Initialized
INFO - 2020-09-24 10:29:49 --> Model Class Initialized
INFO - 2020-09-24 10:29:49 --> Final output sent to browser
DEBUG - 2020-09-24 10:29:49 --> Total execution time: 0.0702
