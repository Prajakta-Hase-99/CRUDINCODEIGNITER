<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-25 05:26:40 --> Config Class Initialized
INFO - 2020-09-25 05:26:40 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:26:41 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:26:41 --> Utf8 Class Initialized
INFO - 2020-09-25 05:26:41 --> URI Class Initialized
DEBUG - 2020-09-25 05:26:41 --> No URI present. Default controller set.
INFO - 2020-09-25 05:26:41 --> Router Class Initialized
INFO - 2020-09-25 05:26:41 --> Output Class Initialized
INFO - 2020-09-25 05:26:41 --> Security Class Initialized
DEBUG - 2020-09-25 05:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:26:41 --> Input Class Initialized
INFO - 2020-09-25 05:26:41 --> Language Class Initialized
INFO - 2020-09-25 05:26:41 --> Loader Class Initialized
INFO - 2020-09-25 05:26:41 --> Helper loaded: url_helper
INFO - 2020-09-25 05:26:41 --> Helper loaded: file_helper
INFO - 2020-09-25 05:26:41 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:26:41 --> Helper loaded: form_helper
INFO - 2020-09-25 05:26:41 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:26:41 --> Controller Class Initialized
INFO - 2020-09-25 05:26:41 --> Model Class Initialized
INFO - 2020-09-25 05:26:41 --> Config Class Initialized
INFO - 2020-09-25 05:26:41 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:26:41 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:26:41 --> Utf8 Class Initialized
INFO - 2020-09-25 05:26:41 --> URI Class Initialized
INFO - 2020-09-25 05:26:41 --> Router Class Initialized
INFO - 2020-09-25 05:26:41 --> Output Class Initialized
INFO - 2020-09-25 05:26:41 --> Security Class Initialized
DEBUG - 2020-09-25 05:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:26:41 --> Input Class Initialized
INFO - 2020-09-25 05:26:41 --> Language Class Initialized
INFO - 2020-09-25 05:26:41 --> Loader Class Initialized
INFO - 2020-09-25 05:26:41 --> Helper loaded: url_helper
INFO - 2020-09-25 05:26:41 --> Helper loaded: file_helper
INFO - 2020-09-25 05:26:41 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:26:41 --> Helper loaded: form_helper
INFO - 2020-09-25 05:26:41 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:26:41 --> Controller Class Initialized
INFO - 2020-09-25 05:26:41 --> Model Class Initialized
INFO - 2020-09-25 05:26:41 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/login.php
INFO - 2020-09-25 05:26:41 --> Final output sent to browser
DEBUG - 2020-09-25 05:26:41 --> Total execution time: 0.1555
INFO - 2020-09-25 05:27:00 --> Config Class Initialized
INFO - 2020-09-25 05:27:00 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:27:00 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:27:00 --> Utf8 Class Initialized
INFO - 2020-09-25 05:27:00 --> URI Class Initialized
INFO - 2020-09-25 05:27:00 --> Router Class Initialized
INFO - 2020-09-25 05:27:00 --> Output Class Initialized
INFO - 2020-09-25 05:27:00 --> Security Class Initialized
DEBUG - 2020-09-25 05:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:27:00 --> Input Class Initialized
INFO - 2020-09-25 05:27:00 --> Language Class Initialized
INFO - 2020-09-25 05:27:00 --> Loader Class Initialized
INFO - 2020-09-25 05:27:00 --> Helper loaded: url_helper
INFO - 2020-09-25 05:27:00 --> Helper loaded: file_helper
INFO - 2020-09-25 05:27:00 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:27:00 --> Helper loaded: form_helper
INFO - 2020-09-25 05:27:00 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:27:01 --> Controller Class Initialized
INFO - 2020-09-25 05:27:01 --> Model Class Initialized
INFO - 2020-09-25 05:27:01 --> Form Validation Class Initialized
INFO - 2020-09-25 05:27:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-25 05:27:01 --> User Agent Class Initialized
INFO - 2020-09-25 05:27:01 --> Config Class Initialized
INFO - 2020-09-25 05:27:01 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:27:01 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:27:01 --> Utf8 Class Initialized
INFO - 2020-09-25 05:27:01 --> URI Class Initialized
INFO - 2020-09-25 05:27:01 --> Router Class Initialized
INFO - 2020-09-25 05:27:01 --> Output Class Initialized
INFO - 2020-09-25 05:27:01 --> Security Class Initialized
DEBUG - 2020-09-25 05:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:27:01 --> Input Class Initialized
INFO - 2020-09-25 05:27:01 --> Language Class Initialized
INFO - 2020-09-25 05:27:01 --> Loader Class Initialized
INFO - 2020-09-25 05:27:01 --> Helper loaded: url_helper
INFO - 2020-09-25 05:27:01 --> Helper loaded: file_helper
INFO - 2020-09-25 05:27:01 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:27:01 --> Helper loaded: form_helper
INFO - 2020-09-25 05:27:01 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:27:01 --> Controller Class Initialized
INFO - 2020-09-25 05:27:01 --> Model Class Initialized
INFO - 2020-09-25 05:27:01 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 05:27:01 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/dashboard.php
INFO - 2020-09-25 05:27:01 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 05:27:01 --> Final output sent to browser
DEBUG - 2020-09-25 05:27:01 --> Total execution time: 0.1580
INFO - 2020-09-25 05:27:13 --> Config Class Initialized
INFO - 2020-09-25 05:27:13 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:27:13 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:27:13 --> Utf8 Class Initialized
INFO - 2020-09-25 05:27:13 --> URI Class Initialized
INFO - 2020-09-25 05:27:13 --> Router Class Initialized
INFO - 2020-09-25 05:27:13 --> Output Class Initialized
INFO - 2020-09-25 05:27:13 --> Security Class Initialized
DEBUG - 2020-09-25 05:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:27:13 --> Input Class Initialized
INFO - 2020-09-25 05:27:13 --> Language Class Initialized
INFO - 2020-09-25 05:27:13 --> Loader Class Initialized
INFO - 2020-09-25 05:27:13 --> Helper loaded: url_helper
INFO - 2020-09-25 05:27:13 --> Helper loaded: file_helper
INFO - 2020-09-25 05:27:13 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:27:13 --> Helper loaded: form_helper
INFO - 2020-09-25 05:27:13 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:27:13 --> Controller Class Initialized
INFO - 2020-09-25 05:27:13 --> Model Class Initialized
INFO - 2020-09-25 05:27:13 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 05:27:13 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/dashboard.php
INFO - 2020-09-25 05:27:13 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 05:27:13 --> Final output sent to browser
DEBUG - 2020-09-25 05:27:13 --> Total execution time: 0.0941
INFO - 2020-09-25 05:27:15 --> Config Class Initialized
INFO - 2020-09-25 05:27:15 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:27:16 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:27:16 --> Utf8 Class Initialized
INFO - 2020-09-25 05:27:16 --> URI Class Initialized
INFO - 2020-09-25 05:27:16 --> Router Class Initialized
INFO - 2020-09-25 05:27:16 --> Output Class Initialized
INFO - 2020-09-25 05:27:16 --> Security Class Initialized
DEBUG - 2020-09-25 05:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:27:16 --> Input Class Initialized
INFO - 2020-09-25 05:27:16 --> Language Class Initialized
INFO - 2020-09-25 05:27:16 --> Loader Class Initialized
INFO - 2020-09-25 05:27:16 --> Helper loaded: url_helper
INFO - 2020-09-25 05:27:16 --> Helper loaded: file_helper
INFO - 2020-09-25 05:27:16 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:27:16 --> Helper loaded: form_helper
INFO - 2020-09-25 05:27:16 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:27:16 --> Controller Class Initialized
INFO - 2020-09-25 05:27:16 --> Model Class Initialized
INFO - 2020-09-25 05:27:16 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 05:27:16 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/dashboard.php
INFO - 2020-09-25 05:27:16 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 05:27:16 --> Final output sent to browser
DEBUG - 2020-09-25 05:27:16 --> Total execution time: 0.1092
INFO - 2020-09-25 05:27:18 --> Config Class Initialized
INFO - 2020-09-25 05:27:18 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:27:18 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:27:18 --> Utf8 Class Initialized
INFO - 2020-09-25 05:27:18 --> URI Class Initialized
INFO - 2020-09-25 05:27:18 --> Router Class Initialized
INFO - 2020-09-25 05:27:18 --> Output Class Initialized
INFO - 2020-09-25 05:27:18 --> Security Class Initialized
DEBUG - 2020-09-25 05:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:27:18 --> Input Class Initialized
INFO - 2020-09-25 05:27:18 --> Language Class Initialized
INFO - 2020-09-25 05:27:18 --> Loader Class Initialized
INFO - 2020-09-25 05:27:18 --> Helper loaded: url_helper
INFO - 2020-09-25 05:27:18 --> Helper loaded: file_helper
INFO - 2020-09-25 05:27:18 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:27:18 --> Helper loaded: form_helper
INFO - 2020-09-25 05:27:18 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:27:18 --> Controller Class Initialized
INFO - 2020-09-25 05:27:18 --> Model Class Initialized
INFO - 2020-09-25 05:27:18 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 05:27:18 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/dashboard.php
INFO - 2020-09-25 05:27:18 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 05:27:18 --> Final output sent to browser
DEBUG - 2020-09-25 05:27:18 --> Total execution time: 0.1096
INFO - 2020-09-25 05:27:24 --> Config Class Initialized
INFO - 2020-09-25 05:27:24 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:27:24 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:27:24 --> Utf8 Class Initialized
INFO - 2020-09-25 05:27:24 --> URI Class Initialized
INFO - 2020-09-25 05:27:24 --> Router Class Initialized
INFO - 2020-09-25 05:27:24 --> Output Class Initialized
INFO - 2020-09-25 05:27:24 --> Security Class Initialized
DEBUG - 2020-09-25 05:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:27:24 --> Input Class Initialized
INFO - 2020-09-25 05:27:24 --> Language Class Initialized
INFO - 2020-09-25 05:27:24 --> Loader Class Initialized
INFO - 2020-09-25 05:27:24 --> Helper loaded: url_helper
INFO - 2020-09-25 05:27:24 --> Helper loaded: file_helper
INFO - 2020-09-25 05:27:24 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:27:24 --> Helper loaded: form_helper
INFO - 2020-09-25 05:27:24 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:27:24 --> Controller Class Initialized
INFO - 2020-09-25 05:27:24 --> Model Class Initialized
INFO - 2020-09-25 05:27:24 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 05:27:24 --> File loaded: C:\xampp\htdocs\student_course\application\views\Course/CourseListing.php
INFO - 2020-09-25 05:27:24 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 05:27:24 --> Final output sent to browser
DEBUG - 2020-09-25 05:27:24 --> Total execution time: 0.2154
INFO - 2020-09-25 05:27:25 --> Config Class Initialized
INFO - 2020-09-25 05:27:25 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:27:25 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:27:25 --> Utf8 Class Initialized
INFO - 2020-09-25 05:27:25 --> URI Class Initialized
INFO - 2020-09-25 05:27:25 --> Router Class Initialized
INFO - 2020-09-25 05:27:25 --> Output Class Initialized
INFO - 2020-09-25 05:27:25 --> Security Class Initialized
DEBUG - 2020-09-25 05:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:27:25 --> Input Class Initialized
INFO - 2020-09-25 05:27:25 --> Language Class Initialized
INFO - 2020-09-25 05:27:25 --> Loader Class Initialized
INFO - 2020-09-25 05:27:25 --> Helper loaded: url_helper
INFO - 2020-09-25 05:27:25 --> Helper loaded: file_helper
INFO - 2020-09-25 05:27:25 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:27:25 --> Helper loaded: form_helper
INFO - 2020-09-25 05:27:25 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:27:25 --> Controller Class Initialized
INFO - 2020-09-25 05:27:25 --> Model Class Initialized
INFO - 2020-09-25 05:27:25 --> Final output sent to browser
DEBUG - 2020-09-25 05:27:25 --> Total execution time: 0.1314
INFO - 2020-09-25 05:27:27 --> Config Class Initialized
INFO - 2020-09-25 05:27:27 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:27:27 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:27:27 --> Utf8 Class Initialized
INFO - 2020-09-25 05:27:27 --> URI Class Initialized
INFO - 2020-09-25 05:27:27 --> Router Class Initialized
INFO - 2020-09-25 05:27:27 --> Output Class Initialized
INFO - 2020-09-25 05:27:27 --> Security Class Initialized
DEBUG - 2020-09-25 05:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:27:27 --> Input Class Initialized
INFO - 2020-09-25 05:27:27 --> Language Class Initialized
ERROR - 2020-09-25 05:27:27 --> 404 Page Not Found: Access/index
INFO - 2020-09-25 05:27:29 --> Config Class Initialized
INFO - 2020-09-25 05:27:29 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:27:29 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:27:29 --> Utf8 Class Initialized
INFO - 2020-09-25 05:27:29 --> URI Class Initialized
INFO - 2020-09-25 05:27:29 --> Router Class Initialized
INFO - 2020-09-25 05:27:29 --> Output Class Initialized
INFO - 2020-09-25 05:27:29 --> Security Class Initialized
DEBUG - 2020-09-25 05:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:27:29 --> Input Class Initialized
INFO - 2020-09-25 05:27:29 --> Language Class Initialized
INFO - 2020-09-25 05:27:29 --> Loader Class Initialized
INFO - 2020-09-25 05:27:29 --> Helper loaded: url_helper
INFO - 2020-09-25 05:27:29 --> Helper loaded: file_helper
INFO - 2020-09-25 05:27:29 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:27:29 --> Helper loaded: form_helper
INFO - 2020-09-25 05:27:29 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:27:29 --> Controller Class Initialized
INFO - 2020-09-25 05:27:29 --> Model Class Initialized
INFO - 2020-09-25 05:27:29 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 05:27:29 --> File loaded: C:\xampp\htdocs\student_course\application\views\Course/CourseListing.php
INFO - 2020-09-25 05:27:29 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 05:27:29 --> Final output sent to browser
DEBUG - 2020-09-25 05:27:29 --> Total execution time: 0.1181
INFO - 2020-09-25 05:27:30 --> Config Class Initialized
INFO - 2020-09-25 05:27:30 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:27:30 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:27:30 --> Utf8 Class Initialized
INFO - 2020-09-25 05:27:30 --> URI Class Initialized
INFO - 2020-09-25 05:27:30 --> Router Class Initialized
INFO - 2020-09-25 05:27:30 --> Output Class Initialized
INFO - 2020-09-25 05:27:30 --> Security Class Initialized
DEBUG - 2020-09-25 05:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:27:30 --> Input Class Initialized
INFO - 2020-09-25 05:27:30 --> Language Class Initialized
INFO - 2020-09-25 05:27:30 --> Loader Class Initialized
INFO - 2020-09-25 05:27:30 --> Helper loaded: url_helper
INFO - 2020-09-25 05:27:30 --> Helper loaded: file_helper
INFO - 2020-09-25 05:27:30 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:27:30 --> Helper loaded: form_helper
INFO - 2020-09-25 05:27:30 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:27:30 --> Controller Class Initialized
INFO - 2020-09-25 05:27:30 --> Model Class Initialized
INFO - 2020-09-25 05:27:30 --> Final output sent to browser
DEBUG - 2020-09-25 05:27:30 --> Total execution time: 0.0912
INFO - 2020-09-25 05:28:54 --> Config Class Initialized
INFO - 2020-09-25 05:28:54 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:28:54 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:28:54 --> Utf8 Class Initialized
INFO - 2020-09-25 05:28:54 --> URI Class Initialized
INFO - 2020-09-25 05:28:54 --> Router Class Initialized
INFO - 2020-09-25 05:28:54 --> Output Class Initialized
INFO - 2020-09-25 05:28:54 --> Security Class Initialized
DEBUG - 2020-09-25 05:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:28:54 --> Input Class Initialized
INFO - 2020-09-25 05:28:54 --> Language Class Initialized
INFO - 2020-09-25 05:28:54 --> Loader Class Initialized
INFO - 2020-09-25 05:28:54 --> Helper loaded: url_helper
INFO - 2020-09-25 05:28:54 --> Helper loaded: file_helper
INFO - 2020-09-25 05:28:54 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:28:54 --> Helper loaded: form_helper
INFO - 2020-09-25 05:28:54 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:28:54 --> Controller Class Initialized
INFO - 2020-09-25 05:28:54 --> Model Class Initialized
INFO - 2020-09-25 05:28:54 --> Config Class Initialized
INFO - 2020-09-25 05:28:54 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:28:54 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:28:54 --> Utf8 Class Initialized
INFO - 2020-09-25 05:28:54 --> URI Class Initialized
INFO - 2020-09-25 05:28:54 --> Router Class Initialized
INFO - 2020-09-25 05:28:54 --> Output Class Initialized
INFO - 2020-09-25 05:28:54 --> Security Class Initialized
DEBUG - 2020-09-25 05:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:28:54 --> Input Class Initialized
INFO - 2020-09-25 05:28:54 --> Language Class Initialized
INFO - 2020-09-25 05:28:54 --> Loader Class Initialized
INFO - 2020-09-25 05:28:54 --> Helper loaded: url_helper
INFO - 2020-09-25 05:28:54 --> Helper loaded: file_helper
INFO - 2020-09-25 05:28:54 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:28:54 --> Helper loaded: form_helper
INFO - 2020-09-25 05:28:54 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:28:54 --> Controller Class Initialized
INFO - 2020-09-25 05:28:54 --> Model Class Initialized
INFO - 2020-09-25 05:28:54 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/login.php
INFO - 2020-09-25 05:28:54 --> Final output sent to browser
DEBUG - 2020-09-25 05:28:54 --> Total execution time: 0.0869
INFO - 2020-09-25 05:29:00 --> Config Class Initialized
INFO - 2020-09-25 05:29:00 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:29:00 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:29:00 --> Utf8 Class Initialized
INFO - 2020-09-25 05:29:00 --> URI Class Initialized
INFO - 2020-09-25 05:29:00 --> Router Class Initialized
INFO - 2020-09-25 05:29:00 --> Output Class Initialized
INFO - 2020-09-25 05:29:00 --> Security Class Initialized
DEBUG - 2020-09-25 05:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:29:00 --> Input Class Initialized
INFO - 2020-09-25 05:29:00 --> Language Class Initialized
INFO - 2020-09-25 05:29:01 --> Loader Class Initialized
INFO - 2020-09-25 05:29:01 --> Helper loaded: url_helper
INFO - 2020-09-25 05:29:01 --> Helper loaded: file_helper
INFO - 2020-09-25 05:29:01 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:29:01 --> Helper loaded: form_helper
INFO - 2020-09-25 05:29:01 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:29:01 --> Controller Class Initialized
INFO - 2020-09-25 05:29:01 --> Model Class Initialized
INFO - 2020-09-25 05:29:01 --> Form Validation Class Initialized
INFO - 2020-09-25 05:29:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-25 05:29:01 --> User Agent Class Initialized
INFO - 2020-09-25 05:29:01 --> Config Class Initialized
INFO - 2020-09-25 05:29:01 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:29:01 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:29:01 --> Utf8 Class Initialized
INFO - 2020-09-25 05:29:01 --> URI Class Initialized
INFO - 2020-09-25 05:29:01 --> Router Class Initialized
INFO - 2020-09-25 05:29:01 --> Output Class Initialized
INFO - 2020-09-25 05:29:01 --> Security Class Initialized
DEBUG - 2020-09-25 05:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:29:01 --> Input Class Initialized
INFO - 2020-09-25 05:29:01 --> Language Class Initialized
INFO - 2020-09-25 05:29:01 --> Loader Class Initialized
INFO - 2020-09-25 05:29:01 --> Helper loaded: url_helper
INFO - 2020-09-25 05:29:01 --> Helper loaded: file_helper
INFO - 2020-09-25 05:29:01 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:29:01 --> Helper loaded: form_helper
INFO - 2020-09-25 05:29:01 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:29:01 --> Controller Class Initialized
INFO - 2020-09-25 05:29:01 --> Model Class Initialized
INFO - 2020-09-25 05:29:01 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 05:29:01 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/dashboard.php
INFO - 2020-09-25 05:29:01 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 05:29:01 --> Final output sent to browser
DEBUG - 2020-09-25 05:29:01 --> Total execution time: 0.0985
INFO - 2020-09-25 05:29:05 --> Config Class Initialized
INFO - 2020-09-25 05:29:05 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:29:05 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:29:05 --> Utf8 Class Initialized
INFO - 2020-09-25 05:29:05 --> URI Class Initialized
INFO - 2020-09-25 05:29:05 --> Router Class Initialized
INFO - 2020-09-25 05:29:05 --> Output Class Initialized
INFO - 2020-09-25 05:29:05 --> Security Class Initialized
DEBUG - 2020-09-25 05:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:29:05 --> Input Class Initialized
INFO - 2020-09-25 05:29:05 --> Language Class Initialized
INFO - 2020-09-25 05:29:05 --> Loader Class Initialized
INFO - 2020-09-25 05:29:05 --> Helper loaded: url_helper
INFO - 2020-09-25 05:29:05 --> Helper loaded: file_helper
INFO - 2020-09-25 05:29:05 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:29:05 --> Helper loaded: form_helper
INFO - 2020-09-25 05:29:05 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:29:05 --> Controller Class Initialized
INFO - 2020-09-25 05:29:05 --> Model Class Initialized
INFO - 2020-09-25 05:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-09-25 05:29:05 --> Pagination Class Initialized
ERROR - 2020-09-25 05:29:05 --> Severity: error --> Exception: Call to undefined method User_model::userListingCount() C:\xampp\htdocs\student_course\application\controllers\User.php 50
INFO - 2020-09-25 05:30:14 --> Config Class Initialized
INFO - 2020-09-25 05:30:14 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:30:14 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:30:14 --> Utf8 Class Initialized
INFO - 2020-09-25 05:30:14 --> URI Class Initialized
INFO - 2020-09-25 05:30:14 --> Router Class Initialized
INFO - 2020-09-25 05:30:14 --> Output Class Initialized
INFO - 2020-09-25 05:30:14 --> Security Class Initialized
DEBUG - 2020-09-25 05:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:30:14 --> Input Class Initialized
INFO - 2020-09-25 05:30:14 --> Language Class Initialized
INFO - 2020-09-25 05:30:14 --> Loader Class Initialized
INFO - 2020-09-25 05:30:14 --> Helper loaded: url_helper
INFO - 2020-09-25 05:30:14 --> Helper loaded: file_helper
INFO - 2020-09-25 05:30:14 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:30:14 --> Helper loaded: form_helper
INFO - 2020-09-25 05:30:14 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:30:14 --> Controller Class Initialized
INFO - 2020-09-25 05:30:14 --> Model Class Initialized
INFO - 2020-09-25 05:30:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-09-25 05:30:14 --> Pagination Class Initialized
ERROR - 2020-09-25 05:30:14 --> Severity: error --> Exception: Call to undefined method User_model::userListingCount() C:\xampp\htdocs\student_course\application\controllers\User.php 50
INFO - 2020-09-25 05:33:13 --> Config Class Initialized
INFO - 2020-09-25 05:33:13 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:33:13 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:33:13 --> Utf8 Class Initialized
INFO - 2020-09-25 05:33:13 --> URI Class Initialized
INFO - 2020-09-25 05:33:13 --> Router Class Initialized
INFO - 2020-09-25 05:33:13 --> Output Class Initialized
INFO - 2020-09-25 05:33:13 --> Security Class Initialized
DEBUG - 2020-09-25 05:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:33:13 --> Input Class Initialized
INFO - 2020-09-25 05:33:13 --> Language Class Initialized
INFO - 2020-09-25 05:33:13 --> Loader Class Initialized
INFO - 2020-09-25 05:33:13 --> Helper loaded: url_helper
INFO - 2020-09-25 05:33:13 --> Helper loaded: file_helper
INFO - 2020-09-25 05:33:13 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:33:13 --> Helper loaded: form_helper
INFO - 2020-09-25 05:33:14 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:33:14 --> Controller Class Initialized
INFO - 2020-09-25 05:33:14 --> Model Class Initialized
INFO - 2020-09-25 05:33:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-09-25 05:33:14 --> Pagination Class Initialized
ERROR - 2020-09-25 05:33:14 --> Severity: error --> Exception: Call to undefined method User_model::userListingCount() C:\xampp\htdocs\student_course\application\controllers\User.php 50
INFO - 2020-09-25 05:33:16 --> Config Class Initialized
INFO - 2020-09-25 05:33:16 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:33:16 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:33:16 --> Utf8 Class Initialized
INFO - 2020-09-25 05:33:16 --> URI Class Initialized
INFO - 2020-09-25 05:33:16 --> Router Class Initialized
INFO - 2020-09-25 05:33:16 --> Output Class Initialized
INFO - 2020-09-25 05:33:16 --> Security Class Initialized
DEBUG - 2020-09-25 05:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:33:16 --> Input Class Initialized
INFO - 2020-09-25 05:33:16 --> Language Class Initialized
INFO - 2020-09-25 05:33:16 --> Loader Class Initialized
INFO - 2020-09-25 05:33:16 --> Helper loaded: url_helper
INFO - 2020-09-25 05:33:16 --> Helper loaded: file_helper
INFO - 2020-09-25 05:33:16 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:33:16 --> Helper loaded: form_helper
INFO - 2020-09-25 05:33:16 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:33:16 --> Controller Class Initialized
INFO - 2020-09-25 05:33:16 --> Model Class Initialized
INFO - 2020-09-25 05:33:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-09-25 05:33:16 --> Pagination Class Initialized
ERROR - 2020-09-25 05:33:16 --> Severity: error --> Exception: Call to undefined method User_model::userListingCount() C:\xampp\htdocs\student_course\application\controllers\User.php 50
INFO - 2020-09-25 05:33:57 --> Config Class Initialized
INFO - 2020-09-25 05:33:57 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:33:57 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:33:57 --> Utf8 Class Initialized
INFO - 2020-09-25 05:33:57 --> URI Class Initialized
INFO - 2020-09-25 05:33:57 --> Router Class Initialized
INFO - 2020-09-25 05:33:57 --> Output Class Initialized
INFO - 2020-09-25 05:33:57 --> Security Class Initialized
DEBUG - 2020-09-25 05:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:33:57 --> Input Class Initialized
INFO - 2020-09-25 05:33:57 --> Language Class Initialized
INFO - 2020-09-25 05:33:57 --> Loader Class Initialized
INFO - 2020-09-25 05:33:57 --> Helper loaded: url_helper
INFO - 2020-09-25 05:33:57 --> Helper loaded: file_helper
INFO - 2020-09-25 05:33:57 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:33:57 --> Helper loaded: form_helper
INFO - 2020-09-25 05:33:57 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:33:57 --> Controller Class Initialized
INFO - 2020-09-25 05:33:57 --> Model Class Initialized
INFO - 2020-09-25 05:33:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-09-25 05:33:57 --> Pagination Class Initialized
DEBUG - 2020-09-25 05:33:57 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2020-09-25 05:33:57 --> Query error: Table 'student_course.tbl_center_master' doesn't exist - Invalid query: SELECT `BaseTbl`.`userId`, `BaseTbl`.`email`, `BaseTbl`.`name`, `BaseTbl`.`mobile`, `BaseTbl`.`createdDtm`, `Role`.`role`, `Center`.`district`
FROM `tbl_users` as `BaseTbl`
LEFT JOIN `tbl_roles` as `Role` ON `Role`.`roleId` = `BaseTbl`.`roleId`
LEFT JOIN `tbl_center_master` as `Center` ON `Center`.`center_id` = `BaseTbl`.`center_id`
WHERE `BaseTbl`.`isDeleted` =0
AND `BaseTbl`.`roleId` != 1
ORDER BY `BaseTbl`.`userId` DESC
 LIMIT 5
INFO - 2020-09-25 05:33:57 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-25 05:34:37 --> Config Class Initialized
INFO - 2020-09-25 05:34:37 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:34:37 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:34:37 --> Utf8 Class Initialized
INFO - 2020-09-25 05:34:37 --> URI Class Initialized
INFO - 2020-09-25 05:34:37 --> Router Class Initialized
INFO - 2020-09-25 05:34:37 --> Output Class Initialized
INFO - 2020-09-25 05:34:37 --> Security Class Initialized
DEBUG - 2020-09-25 05:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:34:37 --> Input Class Initialized
INFO - 2020-09-25 05:34:37 --> Language Class Initialized
INFO - 2020-09-25 05:34:37 --> Loader Class Initialized
INFO - 2020-09-25 05:34:37 --> Helper loaded: url_helper
INFO - 2020-09-25 05:34:37 --> Helper loaded: file_helper
INFO - 2020-09-25 05:34:37 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:34:37 --> Helper loaded: form_helper
INFO - 2020-09-25 05:34:37 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:34:37 --> Controller Class Initialized
INFO - 2020-09-25 05:34:37 --> Model Class Initialized
INFO - 2020-09-25 05:34:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-09-25 05:34:37 --> Pagination Class Initialized
DEBUG - 2020-09-25 05:34:37 --> Pagination class already loaded. Second attempt ignored.
INFO - 2020-09-25 05:34:37 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
ERROR - 2020-09-25 05:34:37 --> Severity: Notice --> Undefined property: stdClass::$district C:\xampp\htdocs\student_course\application\views\User\users.php 55
INFO - 2020-09-25 05:34:37 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/users.php
INFO - 2020-09-25 05:34:37 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 05:34:37 --> Final output sent to browser
DEBUG - 2020-09-25 05:34:37 --> Total execution time: 0.2331
INFO - 2020-09-25 05:34:37 --> Config Class Initialized
INFO - 2020-09-25 05:34:37 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:34:37 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:34:37 --> Utf8 Class Initialized
INFO - 2020-09-25 05:34:38 --> URI Class Initialized
INFO - 2020-09-25 05:34:38 --> Router Class Initialized
INFO - 2020-09-25 05:34:38 --> Output Class Initialized
INFO - 2020-09-25 05:34:38 --> Security Class Initialized
DEBUG - 2020-09-25 05:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:34:38 --> Input Class Initialized
INFO - 2020-09-25 05:34:38 --> Language Class Initialized
ERROR - 2020-09-25 05:34:38 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 05:34:58 --> Config Class Initialized
INFO - 2020-09-25 05:34:58 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:34:58 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:34:58 --> Utf8 Class Initialized
INFO - 2020-09-25 05:34:58 --> URI Class Initialized
INFO - 2020-09-25 05:34:58 --> Router Class Initialized
INFO - 2020-09-25 05:34:58 --> Output Class Initialized
INFO - 2020-09-25 05:34:58 --> Security Class Initialized
DEBUG - 2020-09-25 05:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:34:58 --> Input Class Initialized
INFO - 2020-09-25 05:34:58 --> Language Class Initialized
INFO - 2020-09-25 05:34:58 --> Loader Class Initialized
INFO - 2020-09-25 05:34:58 --> Helper loaded: url_helper
INFO - 2020-09-25 05:34:58 --> Helper loaded: file_helper
INFO - 2020-09-25 05:34:58 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:34:58 --> Helper loaded: form_helper
INFO - 2020-09-25 05:34:58 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:34:58 --> Controller Class Initialized
INFO - 2020-09-25 05:34:58 --> Model Class Initialized
INFO - 2020-09-25 05:34:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-09-25 05:34:58 --> Pagination Class Initialized
DEBUG - 2020-09-25 05:34:58 --> Pagination class already loaded. Second attempt ignored.
INFO - 2020-09-25 05:34:58 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
ERROR - 2020-09-25 05:34:58 --> Severity: Notice --> Undefined property: stdClass::$district C:\xampp\htdocs\student_course\application\views\User\users.php 55
INFO - 2020-09-25 05:34:58 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/users.php
INFO - 2020-09-25 05:34:58 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 05:34:58 --> Final output sent to browser
DEBUG - 2020-09-25 05:34:58 --> Total execution time: 0.1894
INFO - 2020-09-25 05:35:00 --> Config Class Initialized
INFO - 2020-09-25 05:35:00 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:35:00 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:35:00 --> Utf8 Class Initialized
INFO - 2020-09-25 05:35:00 --> URI Class Initialized
INFO - 2020-09-25 05:35:00 --> Router Class Initialized
INFO - 2020-09-25 05:35:00 --> Output Class Initialized
INFO - 2020-09-25 05:35:00 --> Security Class Initialized
DEBUG - 2020-09-25 05:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:35:00 --> Input Class Initialized
INFO - 2020-09-25 05:35:00 --> Language Class Initialized
ERROR - 2020-09-25 05:35:00 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 05:35:24 --> Config Class Initialized
INFO - 2020-09-25 05:35:24 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:35:24 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:35:24 --> Utf8 Class Initialized
INFO - 2020-09-25 05:35:24 --> URI Class Initialized
INFO - 2020-09-25 05:35:24 --> Router Class Initialized
INFO - 2020-09-25 05:35:24 --> Output Class Initialized
INFO - 2020-09-25 05:35:24 --> Security Class Initialized
DEBUG - 2020-09-25 05:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:35:24 --> Input Class Initialized
INFO - 2020-09-25 05:35:24 --> Language Class Initialized
INFO - 2020-09-25 05:35:24 --> Loader Class Initialized
INFO - 2020-09-25 05:35:24 --> Helper loaded: url_helper
INFO - 2020-09-25 05:35:24 --> Helper loaded: file_helper
INFO - 2020-09-25 05:35:24 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:35:24 --> Helper loaded: form_helper
INFO - 2020-09-25 05:35:24 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:35:24 --> Controller Class Initialized
INFO - 2020-09-25 05:35:24 --> Model Class Initialized
INFO - 2020-09-25 05:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-09-25 05:35:24 --> Pagination Class Initialized
DEBUG - 2020-09-25 05:35:24 --> Pagination class already loaded. Second attempt ignored.
INFO - 2020-09-25 05:35:24 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
ERROR - 2020-09-25 05:35:24 --> Severity: Notice --> Undefined property: stdClass::$district C:\xampp\htdocs\student_course\application\views\User\users.php 55
INFO - 2020-09-25 05:35:24 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/users.php
INFO - 2020-09-25 05:35:24 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 05:35:24 --> Final output sent to browser
DEBUG - 2020-09-25 05:35:24 --> Total execution time: 0.1222
INFO - 2020-09-25 05:35:24 --> Config Class Initialized
INFO - 2020-09-25 05:35:24 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:35:24 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:35:24 --> Utf8 Class Initialized
INFO - 2020-09-25 05:35:24 --> URI Class Initialized
INFO - 2020-09-25 05:35:24 --> Router Class Initialized
INFO - 2020-09-25 05:35:24 --> Output Class Initialized
INFO - 2020-09-25 05:35:24 --> Security Class Initialized
DEBUG - 2020-09-25 05:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:35:24 --> Input Class Initialized
INFO - 2020-09-25 05:35:24 --> Language Class Initialized
ERROR - 2020-09-25 05:35:24 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 05:35:39 --> Config Class Initialized
INFO - 2020-09-25 05:35:39 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:35:39 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:35:39 --> Utf8 Class Initialized
INFO - 2020-09-25 05:35:39 --> URI Class Initialized
INFO - 2020-09-25 05:35:39 --> Router Class Initialized
INFO - 2020-09-25 05:35:39 --> Output Class Initialized
INFO - 2020-09-25 05:35:39 --> Security Class Initialized
DEBUG - 2020-09-25 05:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:35:39 --> Input Class Initialized
INFO - 2020-09-25 05:35:39 --> Language Class Initialized
ERROR - 2020-09-25 05:35:39 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 05:36:03 --> Config Class Initialized
INFO - 2020-09-25 05:36:03 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:36:03 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:36:03 --> Utf8 Class Initialized
INFO - 2020-09-25 05:36:03 --> URI Class Initialized
INFO - 2020-09-25 05:36:03 --> Router Class Initialized
INFO - 2020-09-25 05:36:03 --> Output Class Initialized
INFO - 2020-09-25 05:36:03 --> Security Class Initialized
DEBUG - 2020-09-25 05:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:36:03 --> Input Class Initialized
INFO - 2020-09-25 05:36:03 --> Language Class Initialized
INFO - 2020-09-25 05:36:03 --> Loader Class Initialized
INFO - 2020-09-25 05:36:03 --> Helper loaded: url_helper
INFO - 2020-09-25 05:36:03 --> Helper loaded: file_helper
INFO - 2020-09-25 05:36:03 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:36:03 --> Helper loaded: form_helper
INFO - 2020-09-25 05:36:03 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:36:03 --> Controller Class Initialized
INFO - 2020-09-25 05:36:03 --> Model Class Initialized
INFO - 2020-09-25 05:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-09-25 05:36:03 --> Pagination Class Initialized
DEBUG - 2020-09-25 05:36:03 --> Pagination class already loaded. Second attempt ignored.
INFO - 2020-09-25 05:36:03 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
ERROR - 2020-09-25 05:36:03 --> Severity: Notice --> Undefined property: stdClass::$district C:\xampp\htdocs\student_course\application\views\User\users.php 55
INFO - 2020-09-25 05:36:03 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/users.php
INFO - 2020-09-25 05:36:03 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 05:36:03 --> Final output sent to browser
DEBUG - 2020-09-25 05:36:03 --> Total execution time: 0.1285
INFO - 2020-09-25 05:36:03 --> Config Class Initialized
INFO - 2020-09-25 05:36:03 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:36:03 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:36:03 --> Utf8 Class Initialized
INFO - 2020-09-25 05:36:03 --> URI Class Initialized
INFO - 2020-09-25 05:36:03 --> Router Class Initialized
INFO - 2020-09-25 05:36:03 --> Output Class Initialized
INFO - 2020-09-25 05:36:03 --> Security Class Initialized
DEBUG - 2020-09-25 05:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:36:03 --> Input Class Initialized
INFO - 2020-09-25 05:36:03 --> Language Class Initialized
ERROR - 2020-09-25 05:36:03 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 05:36:16 --> Config Class Initialized
INFO - 2020-09-25 05:36:16 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:36:16 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:36:16 --> Utf8 Class Initialized
INFO - 2020-09-25 05:36:16 --> URI Class Initialized
INFO - 2020-09-25 05:36:16 --> Router Class Initialized
INFO - 2020-09-25 05:36:16 --> Output Class Initialized
INFO - 2020-09-25 05:36:16 --> Security Class Initialized
DEBUG - 2020-09-25 05:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:36:16 --> Input Class Initialized
INFO - 2020-09-25 05:36:16 --> Language Class Initialized
ERROR - 2020-09-25 05:36:16 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 05:37:28 --> Config Class Initialized
INFO - 2020-09-25 05:37:28 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:37:28 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:37:28 --> Utf8 Class Initialized
INFO - 2020-09-25 05:37:28 --> URI Class Initialized
INFO - 2020-09-25 05:37:28 --> Router Class Initialized
INFO - 2020-09-25 05:37:28 --> Output Class Initialized
INFO - 2020-09-25 05:37:28 --> Security Class Initialized
DEBUG - 2020-09-25 05:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:37:28 --> Input Class Initialized
INFO - 2020-09-25 05:37:28 --> Language Class Initialized
INFO - 2020-09-25 05:37:28 --> Loader Class Initialized
INFO - 2020-09-25 05:37:28 --> Helper loaded: url_helper
INFO - 2020-09-25 05:37:28 --> Helper loaded: file_helper
INFO - 2020-09-25 05:37:28 --> Helper loaded: cias_helper
INFO - 2020-09-25 05:37:28 --> Helper loaded: form_helper
INFO - 2020-09-25 05:37:28 --> Database Driver Class Initialized
DEBUG - 2020-09-25 05:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 05:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 05:37:28 --> Controller Class Initialized
INFO - 2020-09-25 05:37:28 --> Model Class Initialized
INFO - 2020-09-25 05:37:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-09-25 05:37:28 --> Pagination Class Initialized
DEBUG - 2020-09-25 05:37:28 --> Pagination class already loaded. Second attempt ignored.
INFO - 2020-09-25 05:37:28 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 05:37:28 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/users.php
INFO - 2020-09-25 05:37:28 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 05:37:28 --> Final output sent to browser
DEBUG - 2020-09-25 05:37:28 --> Total execution time: 0.1183
INFO - 2020-09-25 05:37:29 --> Config Class Initialized
INFO - 2020-09-25 05:37:29 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:37:29 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:37:29 --> Utf8 Class Initialized
INFO - 2020-09-25 05:37:29 --> URI Class Initialized
INFO - 2020-09-25 05:37:29 --> Router Class Initialized
INFO - 2020-09-25 05:37:29 --> Output Class Initialized
INFO - 2020-09-25 05:37:29 --> Security Class Initialized
DEBUG - 2020-09-25 05:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:37:29 --> Input Class Initialized
INFO - 2020-09-25 05:37:29 --> Language Class Initialized
ERROR - 2020-09-25 05:37:29 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 05:37:37 --> Config Class Initialized
INFO - 2020-09-25 05:37:37 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:37:37 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:37:37 --> Utf8 Class Initialized
INFO - 2020-09-25 05:37:37 --> URI Class Initialized
INFO - 2020-09-25 05:37:37 --> Router Class Initialized
INFO - 2020-09-25 05:37:37 --> Output Class Initialized
INFO - 2020-09-25 05:37:37 --> Security Class Initialized
DEBUG - 2020-09-25 05:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:37:37 --> Input Class Initialized
INFO - 2020-09-25 05:37:37 --> Language Class Initialized
ERROR - 2020-09-25 05:37:37 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 05:37:49 --> Config Class Initialized
INFO - 2020-09-25 05:37:49 --> Hooks Class Initialized
DEBUG - 2020-09-25 05:37:49 --> UTF-8 Support Enabled
INFO - 2020-09-25 05:37:49 --> Utf8 Class Initialized
INFO - 2020-09-25 05:37:49 --> URI Class Initialized
INFO - 2020-09-25 05:37:49 --> Router Class Initialized
INFO - 2020-09-25 05:37:49 --> Output Class Initialized
INFO - 2020-09-25 05:37:49 --> Security Class Initialized
DEBUG - 2020-09-25 05:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 05:37:49 --> Input Class Initialized
INFO - 2020-09-25 05:37:49 --> Language Class Initialized
ERROR - 2020-09-25 05:37:49 --> 404 Page Not Found: Access/index
INFO - 2020-09-25 06:02:23 --> Config Class Initialized
INFO - 2020-09-25 06:02:23 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:02:23 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:02:23 --> Utf8 Class Initialized
INFO - 2020-09-25 06:02:23 --> URI Class Initialized
INFO - 2020-09-25 06:02:23 --> Router Class Initialized
INFO - 2020-09-25 06:02:23 --> Output Class Initialized
INFO - 2020-09-25 06:02:23 --> Security Class Initialized
DEBUG - 2020-09-25 06:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:02:23 --> Input Class Initialized
INFO - 2020-09-25 06:02:23 --> Language Class Initialized
INFO - 2020-09-25 06:02:23 --> Loader Class Initialized
INFO - 2020-09-25 06:02:23 --> Helper loaded: url_helper
INFO - 2020-09-25 06:02:23 --> Helper loaded: file_helper
INFO - 2020-09-25 06:02:23 --> Helper loaded: cias_helper
INFO - 2020-09-25 06:02:23 --> Helper loaded: form_helper
INFO - 2020-09-25 06:02:23 --> Database Driver Class Initialized
DEBUG - 2020-09-25 06:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 06:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 06:02:23 --> Controller Class Initialized
INFO - 2020-09-25 06:02:23 --> Model Class Initialized
INFO - 2020-09-25 06:02:23 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
ERROR - 2020-09-25 06:02:23 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\student_course\application\views\User\access.php 57
INFO - 2020-09-25 06:02:58 --> Config Class Initialized
INFO - 2020-09-25 06:02:58 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:02:58 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:02:58 --> Utf8 Class Initialized
INFO - 2020-09-25 06:02:58 --> URI Class Initialized
INFO - 2020-09-25 06:02:58 --> Router Class Initialized
INFO - 2020-09-25 06:02:58 --> Output Class Initialized
INFO - 2020-09-25 06:02:58 --> Security Class Initialized
DEBUG - 2020-09-25 06:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:02:58 --> Input Class Initialized
INFO - 2020-09-25 06:02:58 --> Language Class Initialized
INFO - 2020-09-25 06:02:58 --> Loader Class Initialized
INFO - 2020-09-25 06:02:58 --> Helper loaded: url_helper
INFO - 2020-09-25 06:02:58 --> Helper loaded: file_helper
INFO - 2020-09-25 06:02:58 --> Helper loaded: cias_helper
INFO - 2020-09-25 06:02:58 --> Helper loaded: form_helper
INFO - 2020-09-25 06:02:58 --> Database Driver Class Initialized
DEBUG - 2020-09-25 06:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 06:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 06:02:58 --> Controller Class Initialized
INFO - 2020-09-25 06:02:58 --> Model Class Initialized
INFO - 2020-09-25 06:02:58 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
ERROR - 2020-09-25 06:02:58 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\student_course\application\views\User\access.php 57
INFO - 2020-09-25 06:04:01 --> Config Class Initialized
INFO - 2020-09-25 06:04:01 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:04:01 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:04:01 --> Utf8 Class Initialized
INFO - 2020-09-25 06:04:01 --> URI Class Initialized
INFO - 2020-09-25 06:04:01 --> Router Class Initialized
INFO - 2020-09-25 06:04:01 --> Output Class Initialized
INFO - 2020-09-25 06:04:01 --> Security Class Initialized
DEBUG - 2020-09-25 06:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:04:01 --> Input Class Initialized
INFO - 2020-09-25 06:04:01 --> Language Class Initialized
INFO - 2020-09-25 06:04:01 --> Loader Class Initialized
INFO - 2020-09-25 06:04:01 --> Helper loaded: url_helper
INFO - 2020-09-25 06:04:01 --> Helper loaded: file_helper
INFO - 2020-09-25 06:04:01 --> Helper loaded: cias_helper
INFO - 2020-09-25 06:04:01 --> Helper loaded: form_helper
INFO - 2020-09-25 06:04:01 --> Database Driver Class Initialized
DEBUG - 2020-09-25 06:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 06:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 06:04:01 --> Controller Class Initialized
INFO - 2020-09-25 06:04:01 --> Model Class Initialized
INFO - 2020-09-25 06:04:01 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 06:04:01 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 06:04:01 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 06:04:01 --> Final output sent to browser
DEBUG - 2020-09-25 06:04:01 --> Total execution time: 0.1190
INFO - 2020-09-25 06:04:02 --> Config Class Initialized
INFO - 2020-09-25 06:04:02 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:04:02 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:04:02 --> Utf8 Class Initialized
INFO - 2020-09-25 06:04:02 --> URI Class Initialized
INFO - 2020-09-25 06:04:02 --> Router Class Initialized
INFO - 2020-09-25 06:04:02 --> Output Class Initialized
INFO - 2020-09-25 06:04:02 --> Security Class Initialized
DEBUG - 2020-09-25 06:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:04:02 --> Input Class Initialized
INFO - 2020-09-25 06:04:02 --> Language Class Initialized
ERROR - 2020-09-25 06:04:02 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 06:04:14 --> Config Class Initialized
INFO - 2020-09-25 06:04:14 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:04:14 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:04:14 --> Utf8 Class Initialized
INFO - 2020-09-25 06:04:14 --> URI Class Initialized
INFO - 2020-09-25 06:04:14 --> Router Class Initialized
INFO - 2020-09-25 06:04:14 --> Output Class Initialized
INFO - 2020-09-25 06:04:14 --> Security Class Initialized
DEBUG - 2020-09-25 06:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:04:14 --> Input Class Initialized
INFO - 2020-09-25 06:04:14 --> Language Class Initialized
ERROR - 2020-09-25 06:04:14 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 06:05:07 --> Config Class Initialized
INFO - 2020-09-25 06:05:07 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:05:07 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:05:07 --> Utf8 Class Initialized
INFO - 2020-09-25 06:05:07 --> URI Class Initialized
INFO - 2020-09-25 06:05:07 --> Router Class Initialized
INFO - 2020-09-25 06:05:07 --> Output Class Initialized
INFO - 2020-09-25 06:05:07 --> Security Class Initialized
DEBUG - 2020-09-25 06:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:05:07 --> Input Class Initialized
INFO - 2020-09-25 06:05:07 --> Language Class Initialized
INFO - 2020-09-25 06:05:07 --> Loader Class Initialized
INFO - 2020-09-25 06:05:07 --> Helper loaded: url_helper
INFO - 2020-09-25 06:05:07 --> Helper loaded: file_helper
INFO - 2020-09-25 06:05:07 --> Helper loaded: cias_helper
INFO - 2020-09-25 06:05:07 --> Helper loaded: form_helper
INFO - 2020-09-25 06:05:07 --> Database Driver Class Initialized
DEBUG - 2020-09-25 06:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 06:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 06:05:07 --> Controller Class Initialized
INFO - 2020-09-25 06:05:07 --> Model Class Initialized
INFO - 2020-09-25 06:05:07 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
ERROR - 2020-09-25 06:05:07 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\student_course\application\views\User\access.php 39
INFO - 2020-09-25 06:06:03 --> Config Class Initialized
INFO - 2020-09-25 06:06:03 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:06:03 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:06:03 --> Utf8 Class Initialized
INFO - 2020-09-25 06:06:03 --> URI Class Initialized
INFO - 2020-09-25 06:06:03 --> Router Class Initialized
INFO - 2020-09-25 06:06:03 --> Output Class Initialized
INFO - 2020-09-25 06:06:03 --> Security Class Initialized
DEBUG - 2020-09-25 06:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:06:03 --> Input Class Initialized
INFO - 2020-09-25 06:06:03 --> Language Class Initialized
INFO - 2020-09-25 06:06:03 --> Loader Class Initialized
INFO - 2020-09-25 06:06:03 --> Helper loaded: url_helper
INFO - 2020-09-25 06:06:03 --> Helper loaded: file_helper
INFO - 2020-09-25 06:06:03 --> Helper loaded: cias_helper
INFO - 2020-09-25 06:06:03 --> Helper loaded: form_helper
INFO - 2020-09-25 06:06:03 --> Database Driver Class Initialized
DEBUG - 2020-09-25 06:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 06:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 06:06:03 --> Controller Class Initialized
INFO - 2020-09-25 06:06:03 --> Model Class Initialized
INFO - 2020-09-25 06:06:59 --> Config Class Initialized
INFO - 2020-09-25 06:06:59 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:06:59 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:06:59 --> Utf8 Class Initialized
INFO - 2020-09-25 06:06:59 --> URI Class Initialized
INFO - 2020-09-25 06:06:59 --> Router Class Initialized
INFO - 2020-09-25 06:06:59 --> Output Class Initialized
INFO - 2020-09-25 06:06:59 --> Security Class Initialized
DEBUG - 2020-09-25 06:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:06:59 --> Input Class Initialized
INFO - 2020-09-25 06:06:59 --> Language Class Initialized
INFO - 2020-09-25 06:07:00 --> Loader Class Initialized
INFO - 2020-09-25 06:07:00 --> Helper loaded: url_helper
INFO - 2020-09-25 06:07:00 --> Helper loaded: file_helper
INFO - 2020-09-25 06:07:00 --> Helper loaded: cias_helper
INFO - 2020-09-25 06:07:00 --> Helper loaded: form_helper
INFO - 2020-09-25 06:07:00 --> Database Driver Class Initialized
DEBUG - 2020-09-25 06:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 06:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 06:07:00 --> Controller Class Initialized
INFO - 2020-09-25 06:07:00 --> Model Class Initialized
INFO - 2020-09-25 06:07:00 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 06:07:00 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 06:07:00 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 06:07:00 --> Final output sent to browser
DEBUG - 2020-09-25 06:07:00 --> Total execution time: 0.1112
INFO - 2020-09-25 06:07:00 --> Config Class Initialized
INFO - 2020-09-25 06:07:00 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:07:00 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:07:00 --> Utf8 Class Initialized
INFO - 2020-09-25 06:07:00 --> URI Class Initialized
INFO - 2020-09-25 06:07:00 --> Router Class Initialized
INFO - 2020-09-25 06:07:00 --> Output Class Initialized
INFO - 2020-09-25 06:07:00 --> Security Class Initialized
DEBUG - 2020-09-25 06:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:07:00 --> Input Class Initialized
INFO - 2020-09-25 06:07:00 --> Language Class Initialized
ERROR - 2020-09-25 06:07:00 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 06:07:06 --> Config Class Initialized
INFO - 2020-09-25 06:07:06 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:07:06 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:07:06 --> Utf8 Class Initialized
INFO - 2020-09-25 06:07:06 --> URI Class Initialized
INFO - 2020-09-25 06:07:06 --> Router Class Initialized
INFO - 2020-09-25 06:07:06 --> Output Class Initialized
INFO - 2020-09-25 06:07:06 --> Security Class Initialized
DEBUG - 2020-09-25 06:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:07:06 --> Input Class Initialized
INFO - 2020-09-25 06:07:06 --> Language Class Initialized
ERROR - 2020-09-25 06:07:06 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 06:07:57 --> Config Class Initialized
INFO - 2020-09-25 06:07:57 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:07:57 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:07:57 --> Utf8 Class Initialized
INFO - 2020-09-25 06:07:57 --> URI Class Initialized
INFO - 2020-09-25 06:07:57 --> Router Class Initialized
INFO - 2020-09-25 06:07:57 --> Output Class Initialized
INFO - 2020-09-25 06:07:57 --> Security Class Initialized
DEBUG - 2020-09-25 06:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:07:57 --> Input Class Initialized
INFO - 2020-09-25 06:07:57 --> Language Class Initialized
INFO - 2020-09-25 06:07:57 --> Loader Class Initialized
INFO - 2020-09-25 06:07:57 --> Helper loaded: url_helper
INFO - 2020-09-25 06:07:57 --> Helper loaded: file_helper
INFO - 2020-09-25 06:07:57 --> Helper loaded: cias_helper
INFO - 2020-09-25 06:07:57 --> Helper loaded: form_helper
INFO - 2020-09-25 06:07:57 --> Database Driver Class Initialized
DEBUG - 2020-09-25 06:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 06:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 06:07:57 --> Controller Class Initialized
INFO - 2020-09-25 06:07:57 --> Model Class Initialized
INFO - 2020-09-25 06:07:57 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
ERROR - 2020-09-25 06:07:57 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\student_course\application\views\User\access.php 77
INFO - 2020-09-25 06:08:28 --> Config Class Initialized
INFO - 2020-09-25 06:08:28 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:08:28 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:08:28 --> Utf8 Class Initialized
INFO - 2020-09-25 06:08:28 --> URI Class Initialized
INFO - 2020-09-25 06:08:28 --> Router Class Initialized
INFO - 2020-09-25 06:08:28 --> Output Class Initialized
INFO - 2020-09-25 06:08:28 --> Security Class Initialized
DEBUG - 2020-09-25 06:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:08:28 --> Input Class Initialized
INFO - 2020-09-25 06:08:28 --> Language Class Initialized
INFO - 2020-09-25 06:08:28 --> Loader Class Initialized
INFO - 2020-09-25 06:08:28 --> Helper loaded: url_helper
INFO - 2020-09-25 06:08:28 --> Helper loaded: file_helper
INFO - 2020-09-25 06:08:28 --> Helper loaded: cias_helper
INFO - 2020-09-25 06:08:28 --> Helper loaded: form_helper
INFO - 2020-09-25 06:08:28 --> Database Driver Class Initialized
DEBUG - 2020-09-25 06:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 06:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 06:08:28 --> Controller Class Initialized
INFO - 2020-09-25 06:08:28 --> Model Class Initialized
INFO - 2020-09-25 06:08:28 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 06:08:28 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 06:08:28 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 06:08:28 --> Final output sent to browser
DEBUG - 2020-09-25 06:08:28 --> Total execution time: 0.1171
INFO - 2020-09-25 06:08:29 --> Config Class Initialized
INFO - 2020-09-25 06:08:29 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:08:29 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:08:29 --> Utf8 Class Initialized
INFO - 2020-09-25 06:08:29 --> URI Class Initialized
INFO - 2020-09-25 06:08:29 --> Router Class Initialized
INFO - 2020-09-25 06:08:29 --> Output Class Initialized
INFO - 2020-09-25 06:08:29 --> Security Class Initialized
DEBUG - 2020-09-25 06:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:08:29 --> Input Class Initialized
INFO - 2020-09-25 06:08:29 --> Language Class Initialized
ERROR - 2020-09-25 06:08:29 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 06:08:37 --> Config Class Initialized
INFO - 2020-09-25 06:08:37 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:08:37 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:08:37 --> Utf8 Class Initialized
INFO - 2020-09-25 06:08:37 --> URI Class Initialized
INFO - 2020-09-25 06:08:37 --> Router Class Initialized
INFO - 2020-09-25 06:08:37 --> Output Class Initialized
INFO - 2020-09-25 06:08:37 --> Security Class Initialized
DEBUG - 2020-09-25 06:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:08:37 --> Input Class Initialized
INFO - 2020-09-25 06:08:37 --> Language Class Initialized
ERROR - 2020-09-25 06:08:37 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 06:09:35 --> Config Class Initialized
INFO - 2020-09-25 06:09:35 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:09:35 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:09:35 --> Utf8 Class Initialized
INFO - 2020-09-25 06:09:35 --> URI Class Initialized
INFO - 2020-09-25 06:09:35 --> Router Class Initialized
INFO - 2020-09-25 06:09:35 --> Output Class Initialized
INFO - 2020-09-25 06:09:35 --> Security Class Initialized
DEBUG - 2020-09-25 06:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:09:35 --> Input Class Initialized
INFO - 2020-09-25 06:09:35 --> Language Class Initialized
INFO - 2020-09-25 06:09:35 --> Loader Class Initialized
INFO - 2020-09-25 06:09:35 --> Helper loaded: url_helper
INFO - 2020-09-25 06:09:35 --> Helper loaded: file_helper
INFO - 2020-09-25 06:09:35 --> Helper loaded: cias_helper
INFO - 2020-09-25 06:09:35 --> Helper loaded: form_helper
INFO - 2020-09-25 06:09:35 --> Database Driver Class Initialized
DEBUG - 2020-09-25 06:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 06:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 06:09:35 --> Controller Class Initialized
INFO - 2020-09-25 06:09:35 --> Model Class Initialized
INFO - 2020-09-25 06:09:35 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 06:09:35 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 06:09:35 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 06:09:35 --> Final output sent to browser
DEBUG - 2020-09-25 06:09:35 --> Total execution time: 0.1444
INFO - 2020-09-25 06:09:36 --> Config Class Initialized
INFO - 2020-09-25 06:09:36 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:09:36 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:09:36 --> Utf8 Class Initialized
INFO - 2020-09-25 06:09:36 --> URI Class Initialized
INFO - 2020-09-25 06:09:36 --> Router Class Initialized
INFO - 2020-09-25 06:09:36 --> Output Class Initialized
INFO - 2020-09-25 06:09:36 --> Security Class Initialized
DEBUG - 2020-09-25 06:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:09:36 --> Input Class Initialized
INFO - 2020-09-25 06:09:36 --> Language Class Initialized
ERROR - 2020-09-25 06:09:36 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 06:09:45 --> Config Class Initialized
INFO - 2020-09-25 06:09:45 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:09:45 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:09:45 --> Utf8 Class Initialized
INFO - 2020-09-25 06:09:45 --> URI Class Initialized
INFO - 2020-09-25 06:09:45 --> Router Class Initialized
INFO - 2020-09-25 06:09:45 --> Output Class Initialized
INFO - 2020-09-25 06:09:45 --> Security Class Initialized
DEBUG - 2020-09-25 06:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:09:45 --> Input Class Initialized
INFO - 2020-09-25 06:09:45 --> Language Class Initialized
ERROR - 2020-09-25 06:09:45 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 06:10:31 --> Config Class Initialized
INFO - 2020-09-25 06:10:31 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:10:31 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:10:31 --> Utf8 Class Initialized
INFO - 2020-09-25 06:10:31 --> URI Class Initialized
INFO - 2020-09-25 06:10:31 --> Router Class Initialized
INFO - 2020-09-25 06:10:31 --> Output Class Initialized
INFO - 2020-09-25 06:10:31 --> Security Class Initialized
DEBUG - 2020-09-25 06:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:10:31 --> Input Class Initialized
INFO - 2020-09-25 06:10:31 --> Language Class Initialized
INFO - 2020-09-25 06:10:31 --> Loader Class Initialized
INFO - 2020-09-25 06:10:31 --> Helper loaded: url_helper
INFO - 2020-09-25 06:10:31 --> Helper loaded: file_helper
INFO - 2020-09-25 06:10:31 --> Helper loaded: cias_helper
INFO - 2020-09-25 06:10:31 --> Helper loaded: form_helper
INFO - 2020-09-25 06:10:31 --> Database Driver Class Initialized
DEBUG - 2020-09-25 06:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 06:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 06:10:31 --> Controller Class Initialized
INFO - 2020-09-25 06:10:31 --> Model Class Initialized
INFO - 2020-09-25 06:10:31 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
ERROR - 2020-09-25 06:10:31 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\student_course\application\views\User\access.php 58
INFO - 2020-09-25 06:12:40 --> Config Class Initialized
INFO - 2020-09-25 06:12:40 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:12:40 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:12:40 --> Utf8 Class Initialized
INFO - 2020-09-25 06:12:40 --> URI Class Initialized
INFO - 2020-09-25 06:12:40 --> Router Class Initialized
INFO - 2020-09-25 06:12:40 --> Output Class Initialized
INFO - 2020-09-25 06:12:40 --> Security Class Initialized
DEBUG - 2020-09-25 06:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:12:40 --> Input Class Initialized
INFO - 2020-09-25 06:12:40 --> Language Class Initialized
INFO - 2020-09-25 06:12:40 --> Loader Class Initialized
INFO - 2020-09-25 06:12:40 --> Helper loaded: url_helper
INFO - 2020-09-25 06:12:40 --> Helper loaded: file_helper
INFO - 2020-09-25 06:12:40 --> Helper loaded: cias_helper
INFO - 2020-09-25 06:12:40 --> Helper loaded: form_helper
INFO - 2020-09-25 06:12:40 --> Database Driver Class Initialized
DEBUG - 2020-09-25 06:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 06:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 06:12:40 --> Controller Class Initialized
INFO - 2020-09-25 06:12:40 --> Model Class Initialized
INFO - 2020-09-25 06:12:40 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 06:12:40 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 06:12:40 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 06:12:40 --> Final output sent to browser
DEBUG - 2020-09-25 06:12:40 --> Total execution time: 0.1072
INFO - 2020-09-25 06:12:41 --> Config Class Initialized
INFO - 2020-09-25 06:12:41 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:12:41 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:12:41 --> Utf8 Class Initialized
INFO - 2020-09-25 06:12:41 --> URI Class Initialized
INFO - 2020-09-25 06:12:41 --> Router Class Initialized
INFO - 2020-09-25 06:12:41 --> Output Class Initialized
INFO - 2020-09-25 06:12:41 --> Security Class Initialized
DEBUG - 2020-09-25 06:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:12:41 --> Input Class Initialized
INFO - 2020-09-25 06:12:41 --> Language Class Initialized
ERROR - 2020-09-25 06:12:41 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 06:12:50 --> Config Class Initialized
INFO - 2020-09-25 06:12:50 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:12:50 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:12:50 --> Utf8 Class Initialized
INFO - 2020-09-25 06:12:50 --> URI Class Initialized
INFO - 2020-09-25 06:12:50 --> Router Class Initialized
INFO - 2020-09-25 06:12:50 --> Output Class Initialized
INFO - 2020-09-25 06:12:50 --> Security Class Initialized
DEBUG - 2020-09-25 06:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:12:50 --> Input Class Initialized
INFO - 2020-09-25 06:12:50 --> Language Class Initialized
ERROR - 2020-09-25 06:12:50 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 06:13:12 --> Config Class Initialized
INFO - 2020-09-25 06:13:12 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:13:12 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:13:12 --> Utf8 Class Initialized
INFO - 2020-09-25 06:13:12 --> URI Class Initialized
INFO - 2020-09-25 06:13:12 --> Router Class Initialized
INFO - 2020-09-25 06:13:12 --> Output Class Initialized
INFO - 2020-09-25 06:13:12 --> Security Class Initialized
DEBUG - 2020-09-25 06:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:13:12 --> Input Class Initialized
INFO - 2020-09-25 06:13:12 --> Language Class Initialized
INFO - 2020-09-25 06:13:12 --> Loader Class Initialized
INFO - 2020-09-25 06:13:12 --> Helper loaded: url_helper
INFO - 2020-09-25 06:13:12 --> Helper loaded: file_helper
INFO - 2020-09-25 06:13:12 --> Helper loaded: cias_helper
INFO - 2020-09-25 06:13:12 --> Helper loaded: form_helper
INFO - 2020-09-25 06:13:12 --> Database Driver Class Initialized
DEBUG - 2020-09-25 06:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 06:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 06:13:12 --> Controller Class Initialized
INFO - 2020-09-25 06:13:12 --> Model Class Initialized
INFO - 2020-09-25 06:13:12 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 06:13:12 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 06:13:12 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 06:13:12 --> Final output sent to browser
DEBUG - 2020-09-25 06:13:12 --> Total execution time: 0.1330
INFO - 2020-09-25 06:13:13 --> Config Class Initialized
INFO - 2020-09-25 06:13:13 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:13:13 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:13:13 --> Utf8 Class Initialized
INFO - 2020-09-25 06:13:13 --> URI Class Initialized
INFO - 2020-09-25 06:13:13 --> Router Class Initialized
INFO - 2020-09-25 06:13:13 --> Output Class Initialized
INFO - 2020-09-25 06:13:13 --> Security Class Initialized
DEBUG - 2020-09-25 06:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:13:13 --> Input Class Initialized
INFO - 2020-09-25 06:13:13 --> Language Class Initialized
ERROR - 2020-09-25 06:13:13 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 06:13:26 --> Config Class Initialized
INFO - 2020-09-25 06:13:26 --> Hooks Class Initialized
DEBUG - 2020-09-25 06:13:26 --> UTF-8 Support Enabled
INFO - 2020-09-25 06:13:26 --> Utf8 Class Initialized
INFO - 2020-09-25 06:13:26 --> URI Class Initialized
INFO - 2020-09-25 06:13:26 --> Router Class Initialized
INFO - 2020-09-25 06:13:26 --> Output Class Initialized
INFO - 2020-09-25 06:13:26 --> Security Class Initialized
DEBUG - 2020-09-25 06:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 06:13:26 --> Input Class Initialized
INFO - 2020-09-25 06:13:26 --> Language Class Initialized
ERROR - 2020-09-25 06:13:26 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:06:15 --> Config Class Initialized
INFO - 2020-09-25 08:06:15 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:06:15 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:06:15 --> Utf8 Class Initialized
INFO - 2020-09-25 08:06:15 --> URI Class Initialized
INFO - 2020-09-25 08:06:15 --> Router Class Initialized
INFO - 2020-09-25 08:06:15 --> Output Class Initialized
INFO - 2020-09-25 08:06:15 --> Security Class Initialized
DEBUG - 2020-09-25 08:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:06:15 --> Input Class Initialized
INFO - 2020-09-25 08:06:15 --> Language Class Initialized
ERROR - 2020-09-25 08:06:15 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\student_course\application\controllers\User.php 461
INFO - 2020-09-25 08:06:35 --> Config Class Initialized
INFO - 2020-09-25 08:06:35 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:06:35 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:06:35 --> Utf8 Class Initialized
INFO - 2020-09-25 08:06:35 --> URI Class Initialized
INFO - 2020-09-25 08:06:35 --> Router Class Initialized
INFO - 2020-09-25 08:06:35 --> Output Class Initialized
INFO - 2020-09-25 08:06:35 --> Security Class Initialized
DEBUG - 2020-09-25 08:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:06:35 --> Input Class Initialized
INFO - 2020-09-25 08:06:35 --> Language Class Initialized
ERROR - 2020-09-25 08:06:35 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\student_course\application\controllers\User.php 461
INFO - 2020-09-25 08:06:43 --> Config Class Initialized
INFO - 2020-09-25 08:06:43 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:06:43 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:06:43 --> Utf8 Class Initialized
INFO - 2020-09-25 08:06:43 --> URI Class Initialized
INFO - 2020-09-25 08:06:43 --> Router Class Initialized
INFO - 2020-09-25 08:06:43 --> Output Class Initialized
INFO - 2020-09-25 08:06:43 --> Security Class Initialized
DEBUG - 2020-09-25 08:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:06:43 --> Input Class Initialized
INFO - 2020-09-25 08:06:43 --> Language Class Initialized
INFO - 2020-09-25 08:06:43 --> Loader Class Initialized
INFO - 2020-09-25 08:06:43 --> Helper loaded: url_helper
INFO - 2020-09-25 08:06:43 --> Helper loaded: file_helper
INFO - 2020-09-25 08:06:43 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:06:43 --> Helper loaded: form_helper
INFO - 2020-09-25 08:06:43 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:06:43 --> Controller Class Initialized
INFO - 2020-09-25 08:06:43 --> Model Class Initialized
INFO - 2020-09-25 08:06:43 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
ERROR - 2020-09-25 08:06:43 --> Severity: Notice --> Trying to get property 'Access_ID' of non-object C:\xampp\htdocs\student_course\application\views\User\access.php 59
ERROR - 2020-09-25 08:06:43 --> Severity: Notice --> Trying to get property 'Access_Name' of non-object C:\xampp\htdocs\student_course\application\views\User\access.php 59
ERROR - 2020-09-25 08:06:43 --> Severity: Notice --> Trying to get property 'Access_ID' of non-object C:\xampp\htdocs\student_course\application\views\User\access.php 59
ERROR - 2020-09-25 08:06:43 --> Severity: Notice --> Trying to get property 'Access_Name' of non-object C:\xampp\htdocs\student_course\application\views\User\access.php 59
ERROR - 2020-09-25 08:06:43 --> Severity: Notice --> Trying to get property 'Access_ID' of non-object C:\xampp\htdocs\student_course\application\views\User\access.php 59
ERROR - 2020-09-25 08:06:43 --> Severity: Notice --> Trying to get property 'Access_Name' of non-object C:\xampp\htdocs\student_course\application\views\User\access.php 59
ERROR - 2020-09-25 08:06:43 --> Severity: Notice --> Trying to get property 'Access_ID' of non-object C:\xampp\htdocs\student_course\application\views\User\access.php 59
ERROR - 2020-09-25 08:06:43 --> Severity: Notice --> Trying to get property 'Access_Name' of non-object C:\xampp\htdocs\student_course\application\views\User\access.php 59
ERROR - 2020-09-25 08:06:43 --> Severity: Notice --> Trying to get property 'Access_ID' of non-object C:\xampp\htdocs\student_course\application\views\User\access.php 59
ERROR - 2020-09-25 08:06:43 --> Severity: Notice --> Trying to get property 'Access_Name' of non-object C:\xampp\htdocs\student_course\application\views\User\access.php 59
INFO - 2020-09-25 08:06:43 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 08:06:43 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:06:43 --> Final output sent to browser
DEBUG - 2020-09-25 08:06:43 --> Total execution time: 0.2757
INFO - 2020-09-25 08:07:49 --> Config Class Initialized
INFO - 2020-09-25 08:07:49 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:07:49 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:07:49 --> Utf8 Class Initialized
INFO - 2020-09-25 08:07:49 --> URI Class Initialized
INFO - 2020-09-25 08:07:49 --> Router Class Initialized
INFO - 2020-09-25 08:07:49 --> Output Class Initialized
INFO - 2020-09-25 08:07:49 --> Security Class Initialized
DEBUG - 2020-09-25 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:07:49 --> Input Class Initialized
INFO - 2020-09-25 08:07:49 --> Language Class Initialized
INFO - 2020-09-25 08:07:49 --> Loader Class Initialized
INFO - 2020-09-25 08:07:49 --> Helper loaded: url_helper
INFO - 2020-09-25 08:07:49 --> Helper loaded: file_helper
INFO - 2020-09-25 08:07:49 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:07:49 --> Helper loaded: form_helper
INFO - 2020-09-25 08:07:49 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:07:49 --> Controller Class Initialized
INFO - 2020-09-25 08:07:49 --> Model Class Initialized
INFO - 2020-09-25 08:07:49 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:07:49 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 08:07:49 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:07:49 --> Final output sent to browser
DEBUG - 2020-09-25 08:07:49 --> Total execution time: 0.1311
INFO - 2020-09-25 08:08:21 --> Config Class Initialized
INFO - 2020-09-25 08:08:21 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:08:21 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:08:21 --> Utf8 Class Initialized
INFO - 2020-09-25 08:08:21 --> URI Class Initialized
INFO - 2020-09-25 08:08:21 --> Router Class Initialized
INFO - 2020-09-25 08:08:21 --> Output Class Initialized
INFO - 2020-09-25 08:08:21 --> Security Class Initialized
DEBUG - 2020-09-25 08:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:08:21 --> Input Class Initialized
INFO - 2020-09-25 08:08:21 --> Language Class Initialized
ERROR - 2020-09-25 08:08:21 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:08:21 --> Config Class Initialized
INFO - 2020-09-25 08:08:21 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:08:21 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:08:21 --> Config Class Initialized
INFO - 2020-09-25 08:08:21 --> Utf8 Class Initialized
INFO - 2020-09-25 08:08:21 --> Hooks Class Initialized
INFO - 2020-09-25 08:08:21 --> URI Class Initialized
DEBUG - 2020-09-25 08:08:21 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:08:21 --> Utf8 Class Initialized
INFO - 2020-09-25 08:08:21 --> Router Class Initialized
INFO - 2020-09-25 08:08:21 --> URI Class Initialized
INFO - 2020-09-25 08:08:21 --> Output Class Initialized
INFO - 2020-09-25 08:08:21 --> Router Class Initialized
INFO - 2020-09-25 08:08:21 --> Security Class Initialized
INFO - 2020-09-25 08:08:21 --> Output Class Initialized
DEBUG - 2020-09-25 08:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:08:21 --> Security Class Initialized
INFO - 2020-09-25 08:08:21 --> Input Class Initialized
INFO - 2020-09-25 08:08:21 --> Language Class Initialized
DEBUG - 2020-09-25 08:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:08:21 --> Input Class Initialized
ERROR - 2020-09-25 08:08:21 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:08:21 --> Language Class Initialized
ERROR - 2020-09-25 08:08:21 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:10:19 --> Config Class Initialized
INFO - 2020-09-25 08:10:19 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:10:19 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:10:19 --> Utf8 Class Initialized
INFO - 2020-09-25 08:10:19 --> URI Class Initialized
INFO - 2020-09-25 08:10:19 --> Router Class Initialized
INFO - 2020-09-25 08:10:19 --> Output Class Initialized
INFO - 2020-09-25 08:10:19 --> Security Class Initialized
DEBUG - 2020-09-25 08:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:10:19 --> Input Class Initialized
INFO - 2020-09-25 08:10:19 --> Language Class Initialized
INFO - 2020-09-25 08:10:19 --> Loader Class Initialized
INFO - 2020-09-25 08:10:19 --> Helper loaded: url_helper
INFO - 2020-09-25 08:10:19 --> Helper loaded: file_helper
INFO - 2020-09-25 08:10:19 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:10:19 --> Helper loaded: form_helper
INFO - 2020-09-25 08:10:19 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:10:19 --> Controller Class Initialized
INFO - 2020-09-25 08:10:19 --> Model Class Initialized
INFO - 2020-09-25 08:10:19 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:10:19 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 08:10:19 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:10:19 --> Final output sent to browser
DEBUG - 2020-09-25 08:10:19 --> Total execution time: 0.1285
INFO - 2020-09-25 08:10:22 --> Config Class Initialized
INFO - 2020-09-25 08:10:22 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:10:22 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:10:22 --> Utf8 Class Initialized
INFO - 2020-09-25 08:10:22 --> URI Class Initialized
INFO - 2020-09-25 08:10:22 --> Router Class Initialized
INFO - 2020-09-25 08:10:22 --> Output Class Initialized
INFO - 2020-09-25 08:10:22 --> Security Class Initialized
DEBUG - 2020-09-25 08:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:10:22 --> Input Class Initialized
INFO - 2020-09-25 08:10:22 --> Language Class Initialized
ERROR - 2020-09-25 08:10:22 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:10:23 --> Config Class Initialized
INFO - 2020-09-25 08:10:23 --> Hooks Class Initialized
INFO - 2020-09-25 08:10:23 --> Config Class Initialized
INFO - 2020-09-25 08:10:23 --> Hooks Class Initialized
INFO - 2020-09-25 08:10:23 --> Config Class Initialized
INFO - 2020-09-25 08:10:23 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:10:23 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:10:23 --> Utf8 Class Initialized
DEBUG - 2020-09-25 08:10:23 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:10:23 --> Utf8 Class Initialized
INFO - 2020-09-25 08:10:23 --> URI Class Initialized
INFO - 2020-09-25 08:10:23 --> URI Class Initialized
DEBUG - 2020-09-25 08:10:23 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:10:23 --> Utf8 Class Initialized
INFO - 2020-09-25 08:10:23 --> Router Class Initialized
INFO - 2020-09-25 08:10:23 --> Router Class Initialized
INFO - 2020-09-25 08:10:23 --> URI Class Initialized
INFO - 2020-09-25 08:10:23 --> Output Class Initialized
INFO - 2020-09-25 08:10:23 --> Output Class Initialized
INFO - 2020-09-25 08:10:23 --> Router Class Initialized
INFO - 2020-09-25 08:10:23 --> Security Class Initialized
INFO - 2020-09-25 08:10:23 --> Security Class Initialized
INFO - 2020-09-25 08:10:23 --> Output Class Initialized
DEBUG - 2020-09-25 08:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-25 08:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:10:23 --> Input Class Initialized
INFO - 2020-09-25 08:10:23 --> Input Class Initialized
INFO - 2020-09-25 08:10:23 --> Security Class Initialized
INFO - 2020-09-25 08:10:23 --> Language Class Initialized
INFO - 2020-09-25 08:10:23 --> Language Class Initialized
DEBUG - 2020-09-25 08:10:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-25 08:10:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-25 08:10:23 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:10:23 --> Input Class Initialized
INFO - 2020-09-25 08:10:23 --> Language Class Initialized
ERROR - 2020-09-25 08:10:23 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:10:27 --> Config Class Initialized
INFO - 2020-09-25 08:10:27 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:10:27 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:10:27 --> Utf8 Class Initialized
INFO - 2020-09-25 08:10:27 --> URI Class Initialized
INFO - 2020-09-25 08:10:27 --> Router Class Initialized
INFO - 2020-09-25 08:10:27 --> Output Class Initialized
INFO - 2020-09-25 08:10:27 --> Security Class Initialized
DEBUG - 2020-09-25 08:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:10:27 --> Input Class Initialized
INFO - 2020-09-25 08:10:27 --> Language Class Initialized
INFO - 2020-09-25 08:10:27 --> Loader Class Initialized
INFO - 2020-09-25 08:10:27 --> Helper loaded: url_helper
INFO - 2020-09-25 08:10:27 --> Helper loaded: file_helper
INFO - 2020-09-25 08:10:27 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:10:27 --> Helper loaded: form_helper
INFO - 2020-09-25 08:10:27 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:10:27 --> Controller Class Initialized
INFO - 2020-09-25 08:10:27 --> Model Class Initialized
ERROR - 2020-09-25 08:10:27 --> Severity: error --> Exception: Call to undefined method User_model::getSelectedMenu() C:\xampp\htdocs\student_course\application\controllers\User.php 443
INFO - 2020-09-25 08:11:13 --> Config Class Initialized
INFO - 2020-09-25 08:11:13 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:11:13 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:11:13 --> Utf8 Class Initialized
INFO - 2020-09-25 08:11:13 --> URI Class Initialized
INFO - 2020-09-25 08:11:13 --> Router Class Initialized
INFO - 2020-09-25 08:11:13 --> Output Class Initialized
INFO - 2020-09-25 08:11:13 --> Security Class Initialized
DEBUG - 2020-09-25 08:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:11:13 --> Input Class Initialized
INFO - 2020-09-25 08:11:13 --> Language Class Initialized
INFO - 2020-09-25 08:11:13 --> Loader Class Initialized
INFO - 2020-09-25 08:11:13 --> Helper loaded: url_helper
INFO - 2020-09-25 08:11:13 --> Helper loaded: file_helper
INFO - 2020-09-25 08:11:13 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:11:13 --> Helper loaded: form_helper
INFO - 2020-09-25 08:11:13 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:11:13 --> Controller Class Initialized
INFO - 2020-09-25 08:11:13 --> Model Class Initialized
INFO - 2020-09-25 08:11:13 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:11:13 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 08:11:13 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:11:13 --> Final output sent to browser
DEBUG - 2020-09-25 08:11:13 --> Total execution time: 0.1397
INFO - 2020-09-25 08:11:15 --> Config Class Initialized
INFO - 2020-09-25 08:11:15 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:11:15 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:11:15 --> Utf8 Class Initialized
INFO - 2020-09-25 08:11:15 --> URI Class Initialized
INFO - 2020-09-25 08:11:15 --> Router Class Initialized
INFO - 2020-09-25 08:11:15 --> Output Class Initialized
INFO - 2020-09-25 08:11:15 --> Security Class Initialized
DEBUG - 2020-09-25 08:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:11:15 --> Input Class Initialized
INFO - 2020-09-25 08:11:15 --> Language Class Initialized
ERROR - 2020-09-25 08:11:15 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:11:16 --> Config Class Initialized
INFO - 2020-09-25 08:11:16 --> Hooks Class Initialized
INFO - 2020-09-25 08:11:16 --> Config Class Initialized
INFO - 2020-09-25 08:11:16 --> Hooks Class Initialized
INFO - 2020-09-25 08:11:16 --> Config Class Initialized
INFO - 2020-09-25 08:11:16 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:11:16 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:11:16 --> Utf8 Class Initialized
DEBUG - 2020-09-25 08:11:16 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:11:16 --> Utf8 Class Initialized
INFO - 2020-09-25 08:11:16 --> URI Class Initialized
DEBUG - 2020-09-25 08:11:16 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:11:16 --> URI Class Initialized
INFO - 2020-09-25 08:11:16 --> Utf8 Class Initialized
INFO - 2020-09-25 08:11:16 --> Router Class Initialized
INFO - 2020-09-25 08:11:16 --> URI Class Initialized
INFO - 2020-09-25 08:11:16 --> Router Class Initialized
INFO - 2020-09-25 08:11:16 --> Router Class Initialized
INFO - 2020-09-25 08:11:16 --> Output Class Initialized
INFO - 2020-09-25 08:11:16 --> Output Class Initialized
INFO - 2020-09-25 08:11:16 --> Security Class Initialized
INFO - 2020-09-25 08:11:16 --> Output Class Initialized
INFO - 2020-09-25 08:11:16 --> Security Class Initialized
DEBUG - 2020-09-25 08:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:11:16 --> Input Class Initialized
DEBUG - 2020-09-25 08:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:11:16 --> Security Class Initialized
INFO - 2020-09-25 08:11:16 --> Input Class Initialized
INFO - 2020-09-25 08:11:16 --> Language Class Initialized
INFO - 2020-09-25 08:11:16 --> Language Class Initialized
DEBUG - 2020-09-25 08:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-09-25 08:11:16 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:11:16 --> Input Class Initialized
ERROR - 2020-09-25 08:11:16 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:11:16 --> Language Class Initialized
ERROR - 2020-09-25 08:11:16 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:11:18 --> Config Class Initialized
INFO - 2020-09-25 08:11:18 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:11:18 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:11:18 --> Utf8 Class Initialized
INFO - 2020-09-25 08:11:18 --> URI Class Initialized
INFO - 2020-09-25 08:11:18 --> Router Class Initialized
INFO - 2020-09-25 08:11:18 --> Output Class Initialized
INFO - 2020-09-25 08:11:18 --> Security Class Initialized
DEBUG - 2020-09-25 08:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:11:18 --> Input Class Initialized
INFO - 2020-09-25 08:11:18 --> Language Class Initialized
INFO - 2020-09-25 08:11:18 --> Loader Class Initialized
INFO - 2020-09-25 08:11:18 --> Helper loaded: url_helper
INFO - 2020-09-25 08:11:18 --> Helper loaded: file_helper
INFO - 2020-09-25 08:11:18 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:11:18 --> Helper loaded: form_helper
INFO - 2020-09-25 08:11:19 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:11:19 --> Controller Class Initialized
INFO - 2020-09-25 08:11:19 --> Model Class Initialized
ERROR - 2020-09-25 08:11:19 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\student_course\application\controllers\User.php 456
INFO - 2020-09-25 08:12:30 --> Config Class Initialized
INFO - 2020-09-25 08:12:30 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:12:30 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:12:30 --> Utf8 Class Initialized
INFO - 2020-09-25 08:12:30 --> URI Class Initialized
INFO - 2020-09-25 08:12:30 --> Router Class Initialized
INFO - 2020-09-25 08:12:30 --> Output Class Initialized
INFO - 2020-09-25 08:12:30 --> Security Class Initialized
DEBUG - 2020-09-25 08:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:12:30 --> Input Class Initialized
INFO - 2020-09-25 08:12:30 --> Language Class Initialized
INFO - 2020-09-25 08:12:30 --> Loader Class Initialized
INFO - 2020-09-25 08:12:30 --> Helper loaded: url_helper
INFO - 2020-09-25 08:12:30 --> Helper loaded: file_helper
INFO - 2020-09-25 08:12:30 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:12:30 --> Helper loaded: form_helper
INFO - 2020-09-25 08:12:30 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:12:30 --> Controller Class Initialized
INFO - 2020-09-25 08:12:30 --> Model Class Initialized
INFO - 2020-09-25 08:12:30 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:12:30 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 08:12:30 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:12:30 --> Final output sent to browser
DEBUG - 2020-09-25 08:12:30 --> Total execution time: 0.1410
INFO - 2020-09-25 08:12:31 --> Config Class Initialized
INFO - 2020-09-25 08:12:31 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:12:31 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:12:31 --> Utf8 Class Initialized
INFO - 2020-09-25 08:12:31 --> URI Class Initialized
INFO - 2020-09-25 08:12:31 --> Router Class Initialized
INFO - 2020-09-25 08:12:31 --> Output Class Initialized
INFO - 2020-09-25 08:12:31 --> Security Class Initialized
DEBUG - 2020-09-25 08:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:12:31 --> Input Class Initialized
INFO - 2020-09-25 08:12:31 --> Language Class Initialized
ERROR - 2020-09-25 08:12:31 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:12:32 --> Config Class Initialized
INFO - 2020-09-25 08:12:32 --> Hooks Class Initialized
INFO - 2020-09-25 08:12:32 --> Config Class Initialized
INFO - 2020-09-25 08:12:32 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:12:32 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:12:32 --> Utf8 Class Initialized
DEBUG - 2020-09-25 08:12:32 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:12:32 --> Utf8 Class Initialized
INFO - 2020-09-25 08:12:32 --> URI Class Initialized
INFO - 2020-09-25 08:12:32 --> URI Class Initialized
INFO - 2020-09-25 08:12:32 --> Router Class Initialized
INFO - 2020-09-25 08:12:32 --> Router Class Initialized
INFO - 2020-09-25 08:12:32 --> Config Class Initialized
INFO - 2020-09-25 08:12:32 --> Hooks Class Initialized
INFO - 2020-09-25 08:12:32 --> Output Class Initialized
INFO - 2020-09-25 08:12:32 --> Output Class Initialized
INFO - 2020-09-25 08:12:32 --> Security Class Initialized
DEBUG - 2020-09-25 08:12:32 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:12:32 --> Utf8 Class Initialized
INFO - 2020-09-25 08:12:32 --> Security Class Initialized
DEBUG - 2020-09-25 08:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:12:32 --> Input Class Initialized
INFO - 2020-09-25 08:12:32 --> URI Class Initialized
INFO - 2020-09-25 08:12:32 --> Language Class Initialized
DEBUG - 2020-09-25 08:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:12:32 --> Input Class Initialized
INFO - 2020-09-25 08:12:32 --> Router Class Initialized
INFO - 2020-09-25 08:12:32 --> Language Class Initialized
ERROR - 2020-09-25 08:12:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-25 08:12:32 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:12:32 --> Output Class Initialized
INFO - 2020-09-25 08:12:32 --> Security Class Initialized
DEBUG - 2020-09-25 08:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:12:32 --> Input Class Initialized
INFO - 2020-09-25 08:12:32 --> Language Class Initialized
ERROR - 2020-09-25 08:12:32 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:12:44 --> Config Class Initialized
INFO - 2020-09-25 08:12:44 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:12:44 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:12:44 --> Utf8 Class Initialized
INFO - 2020-09-25 08:12:44 --> URI Class Initialized
INFO - 2020-09-25 08:12:44 --> Router Class Initialized
INFO - 2020-09-25 08:12:44 --> Output Class Initialized
INFO - 2020-09-25 08:12:44 --> Security Class Initialized
DEBUG - 2020-09-25 08:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:12:44 --> Input Class Initialized
INFO - 2020-09-25 08:12:44 --> Language Class Initialized
INFO - 2020-09-25 08:12:44 --> Loader Class Initialized
INFO - 2020-09-25 08:12:44 --> Helper loaded: url_helper
INFO - 2020-09-25 08:12:44 --> Helper loaded: file_helper
INFO - 2020-09-25 08:12:44 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:12:44 --> Helper loaded: form_helper
INFO - 2020-09-25 08:12:44 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:12:44 --> Controller Class Initialized
INFO - 2020-09-25 08:12:44 --> Model Class Initialized
INFO - 2020-09-25 08:13:14 --> Config Class Initialized
INFO - 2020-09-25 08:13:14 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:13:14 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:13:14 --> Utf8 Class Initialized
INFO - 2020-09-25 08:13:14 --> URI Class Initialized
INFO - 2020-09-25 08:13:14 --> Router Class Initialized
INFO - 2020-09-25 08:13:14 --> Output Class Initialized
INFO - 2020-09-25 08:13:14 --> Security Class Initialized
DEBUG - 2020-09-25 08:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:13:14 --> Input Class Initialized
INFO - 2020-09-25 08:13:14 --> Language Class Initialized
INFO - 2020-09-25 08:13:14 --> Loader Class Initialized
INFO - 2020-09-25 08:13:14 --> Helper loaded: url_helper
INFO - 2020-09-25 08:13:14 --> Helper loaded: file_helper
INFO - 2020-09-25 08:13:14 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:13:15 --> Helper loaded: form_helper
INFO - 2020-09-25 08:13:15 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:13:15 --> Controller Class Initialized
INFO - 2020-09-25 08:13:15 --> Model Class Initialized
INFO - 2020-09-25 08:13:15 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:13:15 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 08:13:15 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:13:15 --> Final output sent to browser
DEBUG - 2020-09-25 08:13:15 --> Total execution time: 0.1746
INFO - 2020-09-25 08:13:16 --> Config Class Initialized
INFO - 2020-09-25 08:13:16 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:13:16 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:13:16 --> Utf8 Class Initialized
INFO - 2020-09-25 08:13:16 --> URI Class Initialized
INFO - 2020-09-25 08:13:16 --> Router Class Initialized
INFO - 2020-09-25 08:13:16 --> Output Class Initialized
INFO - 2020-09-25 08:13:16 --> Security Class Initialized
DEBUG - 2020-09-25 08:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:13:16 --> Input Class Initialized
INFO - 2020-09-25 08:13:16 --> Language Class Initialized
ERROR - 2020-09-25 08:13:16 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:13:17 --> Config Class Initialized
INFO - 2020-09-25 08:13:17 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:13:17 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:13:17 --> Utf8 Class Initialized
INFO - 2020-09-25 08:13:17 --> URI Class Initialized
INFO - 2020-09-25 08:13:17 --> Router Class Initialized
INFO - 2020-09-25 08:13:17 --> Config Class Initialized
INFO - 2020-09-25 08:13:17 --> Hooks Class Initialized
INFO - 2020-09-25 08:13:17 --> Output Class Initialized
INFO - 2020-09-25 08:13:17 --> Config Class Initialized
INFO - 2020-09-25 08:13:17 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:13:17 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:13:17 --> Utf8 Class Initialized
INFO - 2020-09-25 08:13:17 --> Security Class Initialized
INFO - 2020-09-25 08:13:17 --> URI Class Initialized
DEBUG - 2020-09-25 08:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:13:17 --> Input Class Initialized
DEBUG - 2020-09-25 08:13:17 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:13:17 --> Language Class Initialized
INFO - 2020-09-25 08:13:17 --> Utf8 Class Initialized
INFO - 2020-09-25 08:13:17 --> Router Class Initialized
INFO - 2020-09-25 08:13:17 --> URI Class Initialized
ERROR - 2020-09-25 08:13:17 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:13:17 --> Output Class Initialized
INFO - 2020-09-25 08:13:17 --> Router Class Initialized
INFO - 2020-09-25 08:13:17 --> Security Class Initialized
INFO - 2020-09-25 08:13:17 --> Output Class Initialized
DEBUG - 2020-09-25 08:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:13:17 --> Input Class Initialized
INFO - 2020-09-25 08:13:17 --> Language Class Initialized
INFO - 2020-09-25 08:13:17 --> Security Class Initialized
DEBUG - 2020-09-25 08:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:13:17 --> Input Class Initialized
INFO - 2020-09-25 08:13:17 --> Language Class Initialized
ERROR - 2020-09-25 08:13:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-25 08:13:17 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:13:20 --> Config Class Initialized
INFO - 2020-09-25 08:13:20 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:13:20 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:13:20 --> Utf8 Class Initialized
INFO - 2020-09-25 08:13:20 --> URI Class Initialized
INFO - 2020-09-25 08:13:20 --> Router Class Initialized
INFO - 2020-09-25 08:13:20 --> Output Class Initialized
INFO - 2020-09-25 08:13:20 --> Security Class Initialized
DEBUG - 2020-09-25 08:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:13:20 --> Input Class Initialized
INFO - 2020-09-25 08:13:20 --> Language Class Initialized
INFO - 2020-09-25 08:13:20 --> Loader Class Initialized
INFO - 2020-09-25 08:13:20 --> Helper loaded: url_helper
INFO - 2020-09-25 08:13:20 --> Helper loaded: file_helper
INFO - 2020-09-25 08:13:20 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:13:20 --> Helper loaded: form_helper
INFO - 2020-09-25 08:13:20 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:13:20 --> Controller Class Initialized
INFO - 2020-09-25 08:13:20 --> Model Class Initialized
INFO - 2020-09-25 08:16:20 --> Config Class Initialized
INFO - 2020-09-25 08:16:20 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:16:20 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:16:20 --> Utf8 Class Initialized
INFO - 2020-09-25 08:16:20 --> URI Class Initialized
INFO - 2020-09-25 08:16:20 --> Router Class Initialized
INFO - 2020-09-25 08:16:20 --> Output Class Initialized
INFO - 2020-09-25 08:16:20 --> Security Class Initialized
DEBUG - 2020-09-25 08:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:16:20 --> Input Class Initialized
INFO - 2020-09-25 08:16:20 --> Language Class Initialized
INFO - 2020-09-25 08:16:20 --> Loader Class Initialized
INFO - 2020-09-25 08:16:20 --> Helper loaded: url_helper
INFO - 2020-09-25 08:16:20 --> Helper loaded: file_helper
INFO - 2020-09-25 08:16:20 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:16:20 --> Helper loaded: form_helper
INFO - 2020-09-25 08:16:20 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:16:20 --> Controller Class Initialized
INFO - 2020-09-25 08:16:20 --> Model Class Initialized
INFO - 2020-09-25 08:16:20 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:16:20 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 08:16:20 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:16:20 --> Final output sent to browser
DEBUG - 2020-09-25 08:16:20 --> Total execution time: 0.1384
INFO - 2020-09-25 08:16:21 --> Config Class Initialized
INFO - 2020-09-25 08:16:21 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:16:21 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:16:21 --> Utf8 Class Initialized
INFO - 2020-09-25 08:16:21 --> URI Class Initialized
INFO - 2020-09-25 08:16:21 --> Router Class Initialized
INFO - 2020-09-25 08:16:21 --> Output Class Initialized
INFO - 2020-09-25 08:16:22 --> Security Class Initialized
DEBUG - 2020-09-25 08:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:16:22 --> Input Class Initialized
INFO - 2020-09-25 08:16:22 --> Language Class Initialized
ERROR - 2020-09-25 08:16:22 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:16:22 --> Config Class Initialized
INFO - 2020-09-25 08:16:22 --> Config Class Initialized
INFO - 2020-09-25 08:16:22 --> Hooks Class Initialized
INFO - 2020-09-25 08:16:22 --> Hooks Class Initialized
INFO - 2020-09-25 08:16:22 --> Config Class Initialized
INFO - 2020-09-25 08:16:22 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:16:22 --> UTF-8 Support Enabled
DEBUG - 2020-09-25 08:16:22 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:16:22 --> Utf8 Class Initialized
INFO - 2020-09-25 08:16:22 --> Utf8 Class Initialized
INFO - 2020-09-25 08:16:22 --> URI Class Initialized
INFO - 2020-09-25 08:16:22 --> URI Class Initialized
INFO - 2020-09-25 08:16:22 --> Router Class Initialized
INFO - 2020-09-25 08:16:22 --> Router Class Initialized
INFO - 2020-09-25 08:16:22 --> Output Class Initialized
INFO - 2020-09-25 08:16:22 --> Output Class Initialized
INFO - 2020-09-25 08:16:22 --> Security Class Initialized
INFO - 2020-09-25 08:16:22 --> Security Class Initialized
DEBUG - 2020-09-25 08:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-25 08:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:16:22 --> Input Class Initialized
INFO - 2020-09-25 08:16:22 --> Input Class Initialized
INFO - 2020-09-25 08:16:22 --> Language Class Initialized
INFO - 2020-09-25 08:16:22 --> Language Class Initialized
ERROR - 2020-09-25 08:16:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-25 08:16:22 --> 404 Page Not Found: Assets/js
DEBUG - 2020-09-25 08:16:22 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:16:22 --> Utf8 Class Initialized
INFO - 2020-09-25 08:16:22 --> URI Class Initialized
INFO - 2020-09-25 08:16:22 --> Router Class Initialized
INFO - 2020-09-25 08:16:22 --> Output Class Initialized
INFO - 2020-09-25 08:16:22 --> Security Class Initialized
DEBUG - 2020-09-25 08:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:16:22 --> Input Class Initialized
INFO - 2020-09-25 08:16:22 --> Language Class Initialized
ERROR - 2020-09-25 08:16:22 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:16:31 --> Config Class Initialized
INFO - 2020-09-25 08:16:31 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:16:31 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:16:31 --> Utf8 Class Initialized
INFO - 2020-09-25 08:16:31 --> URI Class Initialized
INFO - 2020-09-25 08:16:31 --> Router Class Initialized
INFO - 2020-09-25 08:16:31 --> Output Class Initialized
INFO - 2020-09-25 08:16:31 --> Security Class Initialized
DEBUG - 2020-09-25 08:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:16:31 --> Input Class Initialized
INFO - 2020-09-25 08:16:31 --> Language Class Initialized
INFO - 2020-09-25 08:16:31 --> Loader Class Initialized
INFO - 2020-09-25 08:16:31 --> Helper loaded: url_helper
INFO - 2020-09-25 08:16:31 --> Helper loaded: file_helper
INFO - 2020-09-25 08:16:31 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:16:31 --> Helper loaded: form_helper
INFO - 2020-09-25 08:16:31 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:16:31 --> Controller Class Initialized
INFO - 2020-09-25 08:16:31 --> Model Class Initialized
INFO - 2020-09-25 08:16:31 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:16:31 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 08:16:31 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:16:31 --> Final output sent to browser
DEBUG - 2020-09-25 08:16:31 --> Total execution time: 0.1483
INFO - 2020-09-25 08:16:32 --> Config Class Initialized
INFO - 2020-09-25 08:16:32 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:16:32 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:16:32 --> Utf8 Class Initialized
INFO - 2020-09-25 08:16:32 --> URI Class Initialized
INFO - 2020-09-25 08:16:32 --> Router Class Initialized
INFO - 2020-09-25 08:16:32 --> Output Class Initialized
INFO - 2020-09-25 08:16:32 --> Security Class Initialized
DEBUG - 2020-09-25 08:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:16:32 --> Input Class Initialized
INFO - 2020-09-25 08:16:32 --> Language Class Initialized
ERROR - 2020-09-25 08:16:33 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:16:33 --> Config Class Initialized
INFO - 2020-09-25 08:16:33 --> Hooks Class Initialized
INFO - 2020-09-25 08:16:33 --> Config Class Initialized
INFO - 2020-09-25 08:16:33 --> Config Class Initialized
INFO - 2020-09-25 08:16:33 --> Hooks Class Initialized
INFO - 2020-09-25 08:16:33 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:16:33 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:16:33 --> Utf8 Class Initialized
DEBUG - 2020-09-25 08:16:33 --> UTF-8 Support Enabled
DEBUG - 2020-09-25 08:16:33 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:16:33 --> Utf8 Class Initialized
INFO - 2020-09-25 08:16:33 --> Utf8 Class Initialized
INFO - 2020-09-25 08:16:33 --> URI Class Initialized
INFO - 2020-09-25 08:16:33 --> URI Class Initialized
INFO - 2020-09-25 08:16:33 --> URI Class Initialized
INFO - 2020-09-25 08:16:33 --> Router Class Initialized
INFO - 2020-09-25 08:16:33 --> Router Class Initialized
INFO - 2020-09-25 08:16:33 --> Router Class Initialized
INFO - 2020-09-25 08:16:33 --> Output Class Initialized
INFO - 2020-09-25 08:16:33 --> Output Class Initialized
INFO - 2020-09-25 08:16:33 --> Output Class Initialized
INFO - 2020-09-25 08:16:33 --> Security Class Initialized
INFO - 2020-09-25 08:16:33 --> Security Class Initialized
INFO - 2020-09-25 08:16:33 --> Security Class Initialized
DEBUG - 2020-09-25 08:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:16:33 --> Input Class Initialized
DEBUG - 2020-09-25 08:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-25 08:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:16:33 --> Language Class Initialized
INFO - 2020-09-25 08:16:33 --> Input Class Initialized
INFO - 2020-09-25 08:16:33 --> Input Class Initialized
INFO - 2020-09-25 08:16:33 --> Language Class Initialized
INFO - 2020-09-25 08:16:33 --> Language Class Initialized
ERROR - 2020-09-25 08:16:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-25 08:16:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-25 08:16:33 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:16:35 --> Config Class Initialized
INFO - 2020-09-25 08:16:35 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:16:35 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:16:35 --> Utf8 Class Initialized
INFO - 2020-09-25 08:16:35 --> URI Class Initialized
INFO - 2020-09-25 08:16:35 --> Router Class Initialized
INFO - 2020-09-25 08:16:35 --> Output Class Initialized
INFO - 2020-09-25 08:16:35 --> Security Class Initialized
DEBUG - 2020-09-25 08:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:16:35 --> Input Class Initialized
INFO - 2020-09-25 08:16:35 --> Language Class Initialized
INFO - 2020-09-25 08:16:35 --> Loader Class Initialized
INFO - 2020-09-25 08:16:35 --> Helper loaded: url_helper
INFO - 2020-09-25 08:16:35 --> Helper loaded: file_helper
INFO - 2020-09-25 08:16:35 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:16:35 --> Helper loaded: form_helper
INFO - 2020-09-25 08:16:35 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:16:35 --> Controller Class Initialized
INFO - 2020-09-25 08:16:35 --> Model Class Initialized
INFO - 2020-09-25 08:16:38 --> Config Class Initialized
INFO - 2020-09-25 08:16:38 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:16:38 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:16:38 --> Utf8 Class Initialized
INFO - 2020-09-25 08:16:38 --> URI Class Initialized
INFO - 2020-09-25 08:16:38 --> Router Class Initialized
INFO - 2020-09-25 08:16:38 --> Output Class Initialized
INFO - 2020-09-25 08:16:38 --> Security Class Initialized
DEBUG - 2020-09-25 08:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:16:38 --> Input Class Initialized
INFO - 2020-09-25 08:16:38 --> Language Class Initialized
INFO - 2020-09-25 08:16:38 --> Loader Class Initialized
INFO - 2020-09-25 08:16:38 --> Helper loaded: url_helper
INFO - 2020-09-25 08:16:38 --> Helper loaded: file_helper
INFO - 2020-09-25 08:16:38 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:16:38 --> Helper loaded: form_helper
INFO - 2020-09-25 08:16:38 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:16:38 --> Controller Class Initialized
INFO - 2020-09-25 08:16:38 --> Model Class Initialized
INFO - 2020-09-25 08:17:19 --> Config Class Initialized
INFO - 2020-09-25 08:17:19 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:17:19 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:19 --> Utf8 Class Initialized
INFO - 2020-09-25 08:17:19 --> URI Class Initialized
INFO - 2020-09-25 08:17:19 --> Router Class Initialized
INFO - 2020-09-25 08:17:19 --> Output Class Initialized
INFO - 2020-09-25 08:17:19 --> Security Class Initialized
DEBUG - 2020-09-25 08:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:19 --> Input Class Initialized
INFO - 2020-09-25 08:17:19 --> Language Class Initialized
INFO - 2020-09-25 08:17:19 --> Loader Class Initialized
INFO - 2020-09-25 08:17:19 --> Helper loaded: url_helper
INFO - 2020-09-25 08:17:19 --> Helper loaded: file_helper
INFO - 2020-09-25 08:17:19 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:17:19 --> Helper loaded: form_helper
INFO - 2020-09-25 08:17:19 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:17:19 --> Controller Class Initialized
INFO - 2020-09-25 08:17:19 --> Model Class Initialized
INFO - 2020-09-25 08:17:19 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:17:19 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 08:17:19 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:17:19 --> Final output sent to browser
DEBUG - 2020-09-25 08:17:19 --> Total execution time: 0.1259
INFO - 2020-09-25 08:17:20 --> Config Class Initialized
INFO - 2020-09-25 08:17:20 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:17:20 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:20 --> Utf8 Class Initialized
INFO - 2020-09-25 08:17:20 --> URI Class Initialized
INFO - 2020-09-25 08:17:20 --> Router Class Initialized
INFO - 2020-09-25 08:17:21 --> Output Class Initialized
INFO - 2020-09-25 08:17:21 --> Security Class Initialized
DEBUG - 2020-09-25 08:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:21 --> Input Class Initialized
INFO - 2020-09-25 08:17:21 --> Language Class Initialized
ERROR - 2020-09-25 08:17:21 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:17:21 --> Config Class Initialized
INFO - 2020-09-25 08:17:21 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:17:21 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:21 --> Utf8 Class Initialized
INFO - 2020-09-25 08:17:21 --> URI Class Initialized
INFO - 2020-09-25 08:17:21 --> Router Class Initialized
INFO - 2020-09-25 08:17:21 --> Output Class Initialized
INFO - 2020-09-25 08:17:21 --> Security Class Initialized
INFO - 2020-09-25 08:17:21 --> Config Class Initialized
DEBUG - 2020-09-25 08:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:21 --> Hooks Class Initialized
INFO - 2020-09-25 08:17:21 --> Input Class Initialized
INFO - 2020-09-25 08:17:21 --> Language Class Initialized
ERROR - 2020-09-25 08:17:21 --> 404 Page Not Found: Assets/js
DEBUG - 2020-09-25 08:17:21 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:21 --> Utf8 Class Initialized
INFO - 2020-09-25 08:17:21 --> URI Class Initialized
INFO - 2020-09-25 08:17:21 --> Router Class Initialized
INFO - 2020-09-25 08:17:21 --> Config Class Initialized
INFO - 2020-09-25 08:17:21 --> Hooks Class Initialized
INFO - 2020-09-25 08:17:21 --> Output Class Initialized
INFO - 2020-09-25 08:17:21 --> Security Class Initialized
DEBUG - 2020-09-25 08:17:21 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:21 --> Utf8 Class Initialized
DEBUG - 2020-09-25 08:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:21 --> Input Class Initialized
INFO - 2020-09-25 08:17:21 --> URI Class Initialized
INFO - 2020-09-25 08:17:21 --> Language Class Initialized
ERROR - 2020-09-25 08:17:21 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:17:21 --> Router Class Initialized
INFO - 2020-09-25 08:17:21 --> Output Class Initialized
INFO - 2020-09-25 08:17:21 --> Security Class Initialized
DEBUG - 2020-09-25 08:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:21 --> Input Class Initialized
INFO - 2020-09-25 08:17:21 --> Language Class Initialized
ERROR - 2020-09-25 08:17:21 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:17:24 --> Config Class Initialized
INFO - 2020-09-25 08:17:24 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:17:24 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:24 --> Utf8 Class Initialized
INFO - 2020-09-25 08:17:24 --> URI Class Initialized
INFO - 2020-09-25 08:17:24 --> Router Class Initialized
INFO - 2020-09-25 08:17:24 --> Output Class Initialized
INFO - 2020-09-25 08:17:24 --> Security Class Initialized
DEBUG - 2020-09-25 08:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:24 --> Input Class Initialized
INFO - 2020-09-25 08:17:24 --> Language Class Initialized
INFO - 2020-09-25 08:17:24 --> Loader Class Initialized
INFO - 2020-09-25 08:17:24 --> Helper loaded: url_helper
INFO - 2020-09-25 08:17:24 --> Helper loaded: file_helper
INFO - 2020-09-25 08:17:24 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:17:24 --> Helper loaded: form_helper
INFO - 2020-09-25 08:17:24 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:17:24 --> Controller Class Initialized
INFO - 2020-09-25 08:17:24 --> Model Class Initialized
INFO - 2020-09-25 08:17:26 --> Config Class Initialized
INFO - 2020-09-25 08:17:26 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:17:26 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:26 --> Utf8 Class Initialized
INFO - 2020-09-25 08:17:26 --> URI Class Initialized
INFO - 2020-09-25 08:17:26 --> Router Class Initialized
INFO - 2020-09-25 08:17:26 --> Output Class Initialized
INFO - 2020-09-25 08:17:26 --> Security Class Initialized
DEBUG - 2020-09-25 08:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:26 --> Input Class Initialized
INFO - 2020-09-25 08:17:26 --> Language Class Initialized
INFO - 2020-09-25 08:17:26 --> Loader Class Initialized
INFO - 2020-09-25 08:17:26 --> Helper loaded: url_helper
INFO - 2020-09-25 08:17:26 --> Helper loaded: file_helper
INFO - 2020-09-25 08:17:26 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:17:26 --> Helper loaded: form_helper
INFO - 2020-09-25 08:17:26 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:17:26 --> Controller Class Initialized
INFO - 2020-09-25 08:17:26 --> Model Class Initialized
INFO - 2020-09-25 08:17:30 --> Config Class Initialized
INFO - 2020-09-25 08:17:30 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:17:30 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:30 --> Utf8 Class Initialized
INFO - 2020-09-25 08:17:30 --> URI Class Initialized
INFO - 2020-09-25 08:17:30 --> Router Class Initialized
INFO - 2020-09-25 08:17:30 --> Output Class Initialized
INFO - 2020-09-25 08:17:30 --> Security Class Initialized
DEBUG - 2020-09-25 08:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:30 --> Input Class Initialized
INFO - 2020-09-25 08:17:30 --> Language Class Initialized
INFO - 2020-09-25 08:17:30 --> Loader Class Initialized
INFO - 2020-09-25 08:17:30 --> Helper loaded: url_helper
INFO - 2020-09-25 08:17:30 --> Helper loaded: file_helper
INFO - 2020-09-25 08:17:30 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:17:30 --> Helper loaded: form_helper
INFO - 2020-09-25 08:17:30 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:17:30 --> Controller Class Initialized
INFO - 2020-09-25 08:17:30 --> Model Class Initialized
INFO - 2020-09-25 08:17:48 --> Config Class Initialized
INFO - 2020-09-25 08:17:48 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:17:48 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:48 --> Utf8 Class Initialized
INFO - 2020-09-25 08:17:48 --> URI Class Initialized
INFO - 2020-09-25 08:17:48 --> Router Class Initialized
INFO - 2020-09-25 08:17:48 --> Output Class Initialized
INFO - 2020-09-25 08:17:48 --> Security Class Initialized
DEBUG - 2020-09-25 08:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:48 --> Input Class Initialized
INFO - 2020-09-25 08:17:48 --> Language Class Initialized
INFO - 2020-09-25 08:17:48 --> Loader Class Initialized
INFO - 2020-09-25 08:17:48 --> Helper loaded: url_helper
INFO - 2020-09-25 08:17:48 --> Helper loaded: file_helper
INFO - 2020-09-25 08:17:48 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:17:48 --> Helper loaded: form_helper
INFO - 2020-09-25 08:17:48 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:17:48 --> Controller Class Initialized
INFO - 2020-09-25 08:17:48 --> Model Class Initialized
INFO - 2020-09-25 08:17:48 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:17:48 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 08:17:48 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:17:48 --> Final output sent to browser
DEBUG - 2020-09-25 08:17:48 --> Total execution time: 0.1590
INFO - 2020-09-25 08:17:50 --> Config Class Initialized
INFO - 2020-09-25 08:17:50 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:17:50 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:50 --> Utf8 Class Initialized
INFO - 2020-09-25 08:17:50 --> URI Class Initialized
INFO - 2020-09-25 08:17:50 --> Router Class Initialized
INFO - 2020-09-25 08:17:50 --> Output Class Initialized
INFO - 2020-09-25 08:17:50 --> Security Class Initialized
DEBUG - 2020-09-25 08:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:50 --> Input Class Initialized
INFO - 2020-09-25 08:17:50 --> Language Class Initialized
ERROR - 2020-09-25 08:17:50 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:17:50 --> Config Class Initialized
INFO - 2020-09-25 08:17:50 --> Hooks Class Initialized
INFO - 2020-09-25 08:17:50 --> Config Class Initialized
INFO - 2020-09-25 08:17:50 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:17:50 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:50 --> Utf8 Class Initialized
DEBUG - 2020-09-25 08:17:50 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:50 --> Utf8 Class Initialized
INFO - 2020-09-25 08:17:50 --> Config Class Initialized
INFO - 2020-09-25 08:17:50 --> Hooks Class Initialized
INFO - 2020-09-25 08:17:50 --> URI Class Initialized
INFO - 2020-09-25 08:17:50 --> URI Class Initialized
INFO - 2020-09-25 08:17:50 --> Router Class Initialized
INFO - 2020-09-25 08:17:50 --> Router Class Initialized
DEBUG - 2020-09-25 08:17:50 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:50 --> Utf8 Class Initialized
INFO - 2020-09-25 08:17:50 --> URI Class Initialized
INFO - 2020-09-25 08:17:50 --> Output Class Initialized
INFO - 2020-09-25 08:17:50 --> Output Class Initialized
INFO - 2020-09-25 08:17:50 --> Security Class Initialized
INFO - 2020-09-25 08:17:50 --> Security Class Initialized
DEBUG - 2020-09-25 08:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-25 08:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:50 --> Input Class Initialized
INFO - 2020-09-25 08:17:50 --> Input Class Initialized
INFO - 2020-09-25 08:17:50 --> Language Class Initialized
INFO - 2020-09-25 08:17:50 --> Language Class Initialized
ERROR - 2020-09-25 08:17:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-25 08:17:50 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:17:50 --> Router Class Initialized
INFO - 2020-09-25 08:17:50 --> Output Class Initialized
INFO - 2020-09-25 08:17:50 --> Security Class Initialized
DEBUG - 2020-09-25 08:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:50 --> Input Class Initialized
INFO - 2020-09-25 08:17:50 --> Language Class Initialized
ERROR - 2020-09-25 08:17:50 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:17:52 --> Config Class Initialized
INFO - 2020-09-25 08:17:52 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:17:52 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:52 --> Utf8 Class Initialized
INFO - 2020-09-25 08:17:52 --> URI Class Initialized
INFO - 2020-09-25 08:17:52 --> Router Class Initialized
INFO - 2020-09-25 08:17:52 --> Output Class Initialized
INFO - 2020-09-25 08:17:52 --> Security Class Initialized
DEBUG - 2020-09-25 08:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:52 --> Input Class Initialized
INFO - 2020-09-25 08:17:52 --> Language Class Initialized
INFO - 2020-09-25 08:17:52 --> Loader Class Initialized
INFO - 2020-09-25 08:17:52 --> Helper loaded: url_helper
INFO - 2020-09-25 08:17:52 --> Helper loaded: file_helper
INFO - 2020-09-25 08:17:52 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:17:52 --> Helper loaded: form_helper
INFO - 2020-09-25 08:17:52 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:17:52 --> Controller Class Initialized
INFO - 2020-09-25 08:17:52 --> Model Class Initialized
INFO - 2020-09-25 08:17:54 --> Config Class Initialized
INFO - 2020-09-25 08:17:54 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:17:55 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:55 --> Utf8 Class Initialized
INFO - 2020-09-25 08:17:55 --> URI Class Initialized
INFO - 2020-09-25 08:17:55 --> Router Class Initialized
INFO - 2020-09-25 08:17:55 --> Output Class Initialized
INFO - 2020-09-25 08:17:55 --> Security Class Initialized
DEBUG - 2020-09-25 08:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:55 --> Input Class Initialized
INFO - 2020-09-25 08:17:55 --> Language Class Initialized
INFO - 2020-09-25 08:17:55 --> Loader Class Initialized
INFO - 2020-09-25 08:17:55 --> Helper loaded: url_helper
INFO - 2020-09-25 08:17:55 --> Helper loaded: file_helper
INFO - 2020-09-25 08:17:55 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:17:55 --> Helper loaded: form_helper
INFO - 2020-09-25 08:17:55 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:17:55 --> Controller Class Initialized
INFO - 2020-09-25 08:17:55 --> Model Class Initialized
INFO - 2020-09-25 08:17:57 --> Config Class Initialized
INFO - 2020-09-25 08:17:57 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:17:57 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:17:57 --> Utf8 Class Initialized
INFO - 2020-09-25 08:17:57 --> URI Class Initialized
INFO - 2020-09-25 08:17:57 --> Router Class Initialized
INFO - 2020-09-25 08:17:57 --> Output Class Initialized
INFO - 2020-09-25 08:17:57 --> Security Class Initialized
DEBUG - 2020-09-25 08:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:17:57 --> Input Class Initialized
INFO - 2020-09-25 08:17:57 --> Language Class Initialized
INFO - 2020-09-25 08:17:57 --> Loader Class Initialized
INFO - 2020-09-25 08:17:57 --> Helper loaded: url_helper
INFO - 2020-09-25 08:17:57 --> Helper loaded: file_helper
INFO - 2020-09-25 08:17:58 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:17:58 --> Helper loaded: form_helper
INFO - 2020-09-25 08:17:58 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:17:58 --> Controller Class Initialized
INFO - 2020-09-25 08:17:58 --> Model Class Initialized
INFO - 2020-09-25 08:21:16 --> Config Class Initialized
INFO - 2020-09-25 08:21:16 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:21:16 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:21:16 --> Utf8 Class Initialized
INFO - 2020-09-25 08:21:16 --> URI Class Initialized
INFO - 2020-09-25 08:21:16 --> Router Class Initialized
INFO - 2020-09-25 08:21:16 --> Output Class Initialized
INFO - 2020-09-25 08:21:16 --> Security Class Initialized
DEBUG - 2020-09-25 08:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:21:16 --> Input Class Initialized
INFO - 2020-09-25 08:21:16 --> Language Class Initialized
ERROR - 2020-09-25 08:21:16 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\student_course\application\controllers\User.php 478
INFO - 2020-09-25 08:21:27 --> Config Class Initialized
INFO - 2020-09-25 08:21:27 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:21:27 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:21:27 --> Utf8 Class Initialized
INFO - 2020-09-25 08:21:27 --> URI Class Initialized
INFO - 2020-09-25 08:21:27 --> Router Class Initialized
INFO - 2020-09-25 08:21:27 --> Output Class Initialized
INFO - 2020-09-25 08:21:27 --> Security Class Initialized
DEBUG - 2020-09-25 08:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:21:27 --> Input Class Initialized
INFO - 2020-09-25 08:21:27 --> Language Class Initialized
INFO - 2020-09-25 08:21:27 --> Loader Class Initialized
INFO - 2020-09-25 08:21:27 --> Helper loaded: url_helper
INFO - 2020-09-25 08:21:27 --> Helper loaded: file_helper
INFO - 2020-09-25 08:21:27 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:21:27 --> Helper loaded: form_helper
INFO - 2020-09-25 08:21:27 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:21:27 --> Controller Class Initialized
INFO - 2020-09-25 08:21:27 --> Model Class Initialized
INFO - 2020-09-25 08:21:27 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:21:27 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/access.php
INFO - 2020-09-25 08:21:27 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:21:27 --> Final output sent to browser
DEBUG - 2020-09-25 08:21:27 --> Total execution time: 0.1549
INFO - 2020-09-25 08:21:28 --> Config Class Initialized
INFO - 2020-09-25 08:21:28 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:21:28 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:21:28 --> Utf8 Class Initialized
INFO - 2020-09-25 08:21:28 --> URI Class Initialized
INFO - 2020-09-25 08:21:28 --> Router Class Initialized
INFO - 2020-09-25 08:21:28 --> Output Class Initialized
INFO - 2020-09-25 08:21:28 --> Security Class Initialized
DEBUG - 2020-09-25 08:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:21:28 --> Input Class Initialized
INFO - 2020-09-25 08:21:28 --> Language Class Initialized
ERROR - 2020-09-25 08:21:28 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:21:33 --> Config Class Initialized
INFO - 2020-09-25 08:21:33 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:21:33 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:21:33 --> Utf8 Class Initialized
INFO - 2020-09-25 08:21:33 --> URI Class Initialized
INFO - 2020-09-25 08:21:33 --> Router Class Initialized
INFO - 2020-09-25 08:21:33 --> Output Class Initialized
INFO - 2020-09-25 08:21:33 --> Security Class Initialized
DEBUG - 2020-09-25 08:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:21:33 --> Input Class Initialized
INFO - 2020-09-25 08:21:33 --> Language Class Initialized
INFO - 2020-09-25 08:21:33 --> Config Class Initialized
INFO - 2020-09-25 08:21:33 --> Hooks Class Initialized
ERROR - 2020-09-25 08:21:33 --> 404 Page Not Found: Assets/js
DEBUG - 2020-09-25 08:21:33 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:21:33 --> Utf8 Class Initialized
INFO - 2020-09-25 08:21:33 --> URI Class Initialized
INFO - 2020-09-25 08:21:33 --> Config Class Initialized
INFO - 2020-09-25 08:21:33 --> Hooks Class Initialized
INFO - 2020-09-25 08:21:33 --> Router Class Initialized
DEBUG - 2020-09-25 08:21:33 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:21:33 --> Output Class Initialized
INFO - 2020-09-25 08:21:33 --> Utf8 Class Initialized
INFO - 2020-09-25 08:21:33 --> URI Class Initialized
INFO - 2020-09-25 08:21:33 --> Security Class Initialized
INFO - 2020-09-25 08:21:33 --> Router Class Initialized
DEBUG - 2020-09-25 08:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:21:33 --> Input Class Initialized
INFO - 2020-09-25 08:21:33 --> Language Class Initialized
INFO - 2020-09-25 08:21:33 --> Output Class Initialized
ERROR - 2020-09-25 08:21:33 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:21:33 --> Security Class Initialized
DEBUG - 2020-09-25 08:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:21:33 --> Input Class Initialized
INFO - 2020-09-25 08:21:33 --> Language Class Initialized
ERROR - 2020-09-25 08:21:33 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:21:51 --> Config Class Initialized
INFO - 2020-09-25 08:21:51 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:21:51 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:21:51 --> Utf8 Class Initialized
INFO - 2020-09-25 08:21:51 --> URI Class Initialized
INFO - 2020-09-25 08:21:51 --> Router Class Initialized
INFO - 2020-09-25 08:21:51 --> Output Class Initialized
INFO - 2020-09-25 08:21:51 --> Security Class Initialized
DEBUG - 2020-09-25 08:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:21:51 --> Input Class Initialized
INFO - 2020-09-25 08:21:51 --> Language Class Initialized
INFO - 2020-09-25 08:21:51 --> Loader Class Initialized
INFO - 2020-09-25 08:21:51 --> Helper loaded: url_helper
INFO - 2020-09-25 08:21:51 --> Helper loaded: file_helper
INFO - 2020-09-25 08:21:51 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:21:51 --> Helper loaded: form_helper
INFO - 2020-09-25 08:21:51 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:21:51 --> Controller Class Initialized
INFO - 2020-09-25 08:21:51 --> Model Class Initialized
INFO - 2020-09-25 08:21:58 --> Config Class Initialized
INFO - 2020-09-25 08:21:58 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:21:58 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:21:58 --> Utf8 Class Initialized
INFO - 2020-09-25 08:21:58 --> URI Class Initialized
INFO - 2020-09-25 08:21:58 --> Router Class Initialized
INFO - 2020-09-25 08:21:58 --> Output Class Initialized
INFO - 2020-09-25 08:21:58 --> Security Class Initialized
DEBUG - 2020-09-25 08:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:21:58 --> Input Class Initialized
INFO - 2020-09-25 08:21:58 --> Language Class Initialized
INFO - 2020-09-25 08:21:58 --> Loader Class Initialized
INFO - 2020-09-25 08:21:58 --> Helper loaded: url_helper
INFO - 2020-09-25 08:21:58 --> Helper loaded: file_helper
INFO - 2020-09-25 08:21:58 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:21:58 --> Helper loaded: form_helper
INFO - 2020-09-25 08:21:58 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:21:58 --> Controller Class Initialized
INFO - 2020-09-25 08:21:58 --> Model Class Initialized
INFO - 2020-09-25 08:49:48 --> Config Class Initialized
INFO - 2020-09-25 08:49:48 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:49:48 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:49:48 --> Utf8 Class Initialized
INFO - 2020-09-25 08:49:48 --> URI Class Initialized
INFO - 2020-09-25 08:49:48 --> Router Class Initialized
INFO - 2020-09-25 08:49:48 --> Output Class Initialized
INFO - 2020-09-25 08:49:48 --> Security Class Initialized
DEBUG - 2020-09-25 08:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:49:48 --> Input Class Initialized
INFO - 2020-09-25 08:49:48 --> Language Class Initialized
INFO - 2020-09-25 08:49:48 --> Loader Class Initialized
INFO - 2020-09-25 08:49:48 --> Helper loaded: url_helper
INFO - 2020-09-25 08:49:48 --> Helper loaded: file_helper
INFO - 2020-09-25 08:49:48 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:49:48 --> Helper loaded: form_helper
INFO - 2020-09-25 08:49:48 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:49:48 --> Controller Class Initialized
ERROR - 2020-09-25 08:49:48 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\student_course\application\models\Student_model.php 115
INFO - 2020-09-25 08:50:02 --> Config Class Initialized
INFO - 2020-09-25 08:50:02 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:50:02 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:50:02 --> Utf8 Class Initialized
INFO - 2020-09-25 08:50:02 --> URI Class Initialized
INFO - 2020-09-25 08:50:02 --> Router Class Initialized
INFO - 2020-09-25 08:50:02 --> Output Class Initialized
INFO - 2020-09-25 08:50:02 --> Security Class Initialized
DEBUG - 2020-09-25 08:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:50:02 --> Input Class Initialized
INFO - 2020-09-25 08:50:02 --> Language Class Initialized
INFO - 2020-09-25 08:50:02 --> Loader Class Initialized
INFO - 2020-09-25 08:50:02 --> Helper loaded: url_helper
INFO - 2020-09-25 08:50:02 --> Helper loaded: file_helper
INFO - 2020-09-25 08:50:02 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:50:02 --> Helper loaded: form_helper
INFO - 2020-09-25 08:50:02 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:50:02 --> Controller Class Initialized
ERROR - 2020-09-25 08:50:02 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' C:\xampp\htdocs\student_course\application\models\Student_model.php 117
INFO - 2020-09-25 08:50:09 --> Config Class Initialized
INFO - 2020-09-25 08:50:09 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:50:09 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:50:09 --> Utf8 Class Initialized
INFO - 2020-09-25 08:50:09 --> URI Class Initialized
INFO - 2020-09-25 08:50:09 --> Router Class Initialized
INFO - 2020-09-25 08:50:09 --> Output Class Initialized
INFO - 2020-09-25 08:50:09 --> Security Class Initialized
DEBUG - 2020-09-25 08:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:50:09 --> Input Class Initialized
INFO - 2020-09-25 08:50:09 --> Language Class Initialized
INFO - 2020-09-25 08:50:09 --> Loader Class Initialized
INFO - 2020-09-25 08:50:09 --> Helper loaded: url_helper
INFO - 2020-09-25 08:50:09 --> Helper loaded: file_helper
INFO - 2020-09-25 08:50:09 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:50:09 --> Helper loaded: form_helper
INFO - 2020-09-25 08:50:09 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:50:09 --> Controller Class Initialized
INFO - 2020-09-25 08:50:09 --> Model Class Initialized
INFO - 2020-09-25 08:50:09 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:50:09 --> File loaded: C:\xampp\htdocs\student_course\application\views\Student/studentListing.php
INFO - 2020-09-25 08:50:09 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:50:09 --> Final output sent to browser
DEBUG - 2020-09-25 08:50:09 --> Total execution time: 0.1043
INFO - 2020-09-25 08:50:13 --> Config Class Initialized
INFO - 2020-09-25 08:50:13 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:50:13 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:50:13 --> Utf8 Class Initialized
INFO - 2020-09-25 08:50:13 --> URI Class Initialized
INFO - 2020-09-25 08:50:13 --> Router Class Initialized
INFO - 2020-09-25 08:50:13 --> Output Class Initialized
INFO - 2020-09-25 08:50:13 --> Security Class Initialized
DEBUG - 2020-09-25 08:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:50:13 --> Input Class Initialized
INFO - 2020-09-25 08:50:13 --> Language Class Initialized
INFO - 2020-09-25 08:50:13 --> Loader Class Initialized
INFO - 2020-09-25 08:50:13 --> Helper loaded: url_helper
INFO - 2020-09-25 08:50:13 --> Helper loaded: file_helper
INFO - 2020-09-25 08:50:13 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:50:13 --> Helper loaded: form_helper
INFO - 2020-09-25 08:50:13 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:50:13 --> Controller Class Initialized
INFO - 2020-09-25 08:50:13 --> Model Class Initialized
INFO - 2020-09-25 08:50:13 --> Final output sent to browser
DEBUG - 2020-09-25 08:50:13 --> Total execution time: 0.1454
INFO - 2020-09-25 08:50:48 --> Config Class Initialized
INFO - 2020-09-25 08:50:48 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:50:48 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:50:48 --> Utf8 Class Initialized
INFO - 2020-09-25 08:50:48 --> URI Class Initialized
INFO - 2020-09-25 08:50:48 --> Router Class Initialized
INFO - 2020-09-25 08:50:48 --> Output Class Initialized
INFO - 2020-09-25 08:50:48 --> Security Class Initialized
DEBUG - 2020-09-25 08:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:50:48 --> Input Class Initialized
INFO - 2020-09-25 08:50:48 --> Language Class Initialized
ERROR - 2020-09-25 08:50:48 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\student_course\application\controllers\User.php 506
INFO - 2020-09-25 08:51:12 --> Config Class Initialized
INFO - 2020-09-25 08:51:12 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:51:12 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:51:12 --> Utf8 Class Initialized
INFO - 2020-09-25 08:51:12 --> URI Class Initialized
INFO - 2020-09-25 08:51:12 --> Router Class Initialized
INFO - 2020-09-25 08:51:12 --> Output Class Initialized
INFO - 2020-09-25 08:51:12 --> Security Class Initialized
DEBUG - 2020-09-25 08:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:51:12 --> Input Class Initialized
INFO - 2020-09-25 08:51:12 --> Language Class Initialized
INFO - 2020-09-25 08:51:12 --> Loader Class Initialized
INFO - 2020-09-25 08:51:12 --> Helper loaded: url_helper
INFO - 2020-09-25 08:51:12 --> Helper loaded: file_helper
INFO - 2020-09-25 08:51:12 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:51:12 --> Helper loaded: form_helper
INFO - 2020-09-25 08:51:12 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:51:12 --> Controller Class Initialized
ERROR - 2020-09-25 08:51:12 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\student_course\application\models\User_model.php 262
INFO - 2020-09-25 08:51:41 --> Config Class Initialized
INFO - 2020-09-25 08:51:41 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:51:41 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:51:41 --> Utf8 Class Initialized
INFO - 2020-09-25 08:51:41 --> URI Class Initialized
INFO - 2020-09-25 08:51:41 --> Router Class Initialized
INFO - 2020-09-25 08:51:41 --> Output Class Initialized
INFO - 2020-09-25 08:51:41 --> Security Class Initialized
DEBUG - 2020-09-25 08:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:51:41 --> Input Class Initialized
INFO - 2020-09-25 08:51:41 --> Language Class Initialized
INFO - 2020-09-25 08:51:41 --> Loader Class Initialized
INFO - 2020-09-25 08:51:41 --> Helper loaded: url_helper
INFO - 2020-09-25 08:51:41 --> Helper loaded: file_helper
INFO - 2020-09-25 08:51:41 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:51:41 --> Helper loaded: form_helper
INFO - 2020-09-25 08:51:41 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:51:41 --> Controller Class Initialized
ERROR - 2020-09-25 08:51:41 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\student_course\application\models\User_model.php 262
INFO - 2020-09-25 08:51:57 --> Config Class Initialized
INFO - 2020-09-25 08:51:57 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:51:57 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:51:57 --> Utf8 Class Initialized
INFO - 2020-09-25 08:51:57 --> URI Class Initialized
INFO - 2020-09-25 08:51:57 --> Router Class Initialized
INFO - 2020-09-25 08:51:57 --> Output Class Initialized
INFO - 2020-09-25 08:51:57 --> Security Class Initialized
DEBUG - 2020-09-25 08:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:51:57 --> Input Class Initialized
INFO - 2020-09-25 08:51:57 --> Language Class Initialized
INFO - 2020-09-25 08:51:57 --> Loader Class Initialized
INFO - 2020-09-25 08:51:57 --> Helper loaded: url_helper
INFO - 2020-09-25 08:51:57 --> Helper loaded: file_helper
INFO - 2020-09-25 08:51:57 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:51:57 --> Helper loaded: form_helper
INFO - 2020-09-25 08:51:57 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:51:57 --> Controller Class Initialized
ERROR - 2020-09-25 08:51:57 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\student_course\application\models\User_model.php 262
INFO - 2020-09-25 08:52:10 --> Config Class Initialized
INFO - 2020-09-25 08:52:10 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:52:10 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:52:10 --> Utf8 Class Initialized
INFO - 2020-09-25 08:52:10 --> URI Class Initialized
INFO - 2020-09-25 08:52:10 --> Router Class Initialized
INFO - 2020-09-25 08:52:10 --> Output Class Initialized
INFO - 2020-09-25 08:52:11 --> Security Class Initialized
DEBUG - 2020-09-25 08:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:52:11 --> Input Class Initialized
INFO - 2020-09-25 08:52:11 --> Language Class Initialized
INFO - 2020-09-25 08:52:11 --> Loader Class Initialized
INFO - 2020-09-25 08:52:11 --> Helper loaded: url_helper
INFO - 2020-09-25 08:52:11 --> Helper loaded: file_helper
INFO - 2020-09-25 08:52:11 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:52:11 --> Helper loaded: form_helper
INFO - 2020-09-25 08:52:11 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:52:11 --> Controller Class Initialized
INFO - 2020-09-25 08:52:11 --> Model Class Initialized
INFO - 2020-09-25 08:52:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-09-25 08:52:11 --> Pagination Class Initialized
DEBUG - 2020-09-25 08:52:11 --> Pagination class already loaded. Second attempt ignored.
INFO - 2020-09-25 08:52:11 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:52:11 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/users.php
INFO - 2020-09-25 08:52:11 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:52:11 --> Final output sent to browser
DEBUG - 2020-09-25 08:52:11 --> Total execution time: 0.2987
INFO - 2020-09-25 08:52:11 --> Config Class Initialized
INFO - 2020-09-25 08:52:11 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:52:11 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:52:11 --> Utf8 Class Initialized
INFO - 2020-09-25 08:52:11 --> URI Class Initialized
INFO - 2020-09-25 08:52:11 --> Router Class Initialized
INFO - 2020-09-25 08:52:11 --> Output Class Initialized
INFO - 2020-09-25 08:52:11 --> Security Class Initialized
DEBUG - 2020-09-25 08:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:52:11 --> Input Class Initialized
INFO - 2020-09-25 08:52:11 --> Language Class Initialized
ERROR - 2020-09-25 08:52:11 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:52:30 --> Config Class Initialized
INFO - 2020-09-25 08:52:30 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:52:30 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:52:30 --> Utf8 Class Initialized
INFO - 2020-09-25 08:52:30 --> URI Class Initialized
INFO - 2020-09-25 08:52:30 --> Router Class Initialized
INFO - 2020-09-25 08:52:30 --> Output Class Initialized
INFO - 2020-09-25 08:52:30 --> Security Class Initialized
DEBUG - 2020-09-25 08:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:52:30 --> Input Class Initialized
INFO - 2020-09-25 08:52:30 --> Language Class Initialized
ERROR - 2020-09-25 08:52:30 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:53:01 --> Config Class Initialized
INFO - 2020-09-25 08:53:01 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:53:01 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:53:01 --> Utf8 Class Initialized
INFO - 2020-09-25 08:53:01 --> URI Class Initialized
INFO - 2020-09-25 08:53:01 --> Router Class Initialized
INFO - 2020-09-25 08:53:01 --> Output Class Initialized
INFO - 2020-09-25 08:53:01 --> Security Class Initialized
DEBUG - 2020-09-25 08:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:53:01 --> Input Class Initialized
INFO - 2020-09-25 08:53:01 --> Language Class Initialized
INFO - 2020-09-25 08:53:01 --> Loader Class Initialized
INFO - 2020-09-25 08:53:01 --> Helper loaded: url_helper
INFO - 2020-09-25 08:53:01 --> Helper loaded: file_helper
INFO - 2020-09-25 08:53:01 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:53:01 --> Helper loaded: form_helper
INFO - 2020-09-25 08:53:01 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:53:01 --> Controller Class Initialized
INFO - 2020-09-25 08:53:01 --> Model Class Initialized
INFO - 2020-09-25 08:53:01 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:53:01 --> File loaded: C:\xampp\htdocs\student_course\application\views\Student/studentListing.php
INFO - 2020-09-25 08:53:01 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:53:01 --> Final output sent to browser
DEBUG - 2020-09-25 08:53:01 --> Total execution time: 0.0929
INFO - 2020-09-25 08:53:02 --> Config Class Initialized
INFO - 2020-09-25 08:53:02 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:53:02 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:53:02 --> Utf8 Class Initialized
INFO - 2020-09-25 08:53:02 --> URI Class Initialized
INFO - 2020-09-25 08:53:02 --> Router Class Initialized
INFO - 2020-09-25 08:53:02 --> Output Class Initialized
INFO - 2020-09-25 08:53:02 --> Security Class Initialized
DEBUG - 2020-09-25 08:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:53:02 --> Input Class Initialized
INFO - 2020-09-25 08:53:02 --> Language Class Initialized
INFO - 2020-09-25 08:53:02 --> Loader Class Initialized
INFO - 2020-09-25 08:53:02 --> Helper loaded: url_helper
INFO - 2020-09-25 08:53:02 --> Helper loaded: file_helper
INFO - 2020-09-25 08:53:02 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:53:02 --> Helper loaded: form_helper
INFO - 2020-09-25 08:53:02 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:53:03 --> Controller Class Initialized
INFO - 2020-09-25 08:53:03 --> Model Class Initialized
INFO - 2020-09-25 08:53:03 --> Final output sent to browser
DEBUG - 2020-09-25 08:53:03 --> Total execution time: 0.1302
INFO - 2020-09-25 08:53:12 --> Config Class Initialized
INFO - 2020-09-25 08:53:12 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:53:12 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:53:12 --> Utf8 Class Initialized
INFO - 2020-09-25 08:53:12 --> URI Class Initialized
INFO - 2020-09-25 08:53:12 --> Router Class Initialized
INFO - 2020-09-25 08:53:13 --> Output Class Initialized
INFO - 2020-09-25 08:53:13 --> Security Class Initialized
DEBUG - 2020-09-25 08:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:53:13 --> Input Class Initialized
INFO - 2020-09-25 08:53:13 --> Language Class Initialized
INFO - 2020-09-25 08:53:13 --> Loader Class Initialized
INFO - 2020-09-25 08:53:13 --> Helper loaded: url_helper
INFO - 2020-09-25 08:53:13 --> Helper loaded: file_helper
INFO - 2020-09-25 08:53:13 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:53:13 --> Helper loaded: form_helper
INFO - 2020-09-25 08:53:13 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:53:13 --> Controller Class Initialized
INFO - 2020-09-25 08:53:13 --> Model Class Initialized
INFO - 2020-09-25 08:53:13 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:53:13 --> File loaded: C:\xampp\htdocs\student_course\application\views\Student/studentListing.php
INFO - 2020-09-25 08:53:13 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:53:13 --> Final output sent to browser
DEBUG - 2020-09-25 08:53:13 --> Total execution time: 0.1408
INFO - 2020-09-25 08:53:30 --> Config Class Initialized
INFO - 2020-09-25 08:53:30 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:53:30 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:53:30 --> Utf8 Class Initialized
INFO - 2020-09-25 08:53:30 --> URI Class Initialized
INFO - 2020-09-25 08:53:30 --> Router Class Initialized
INFO - 2020-09-25 08:53:30 --> Output Class Initialized
INFO - 2020-09-25 08:53:30 --> Security Class Initialized
DEBUG - 2020-09-25 08:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:53:30 --> Input Class Initialized
INFO - 2020-09-25 08:53:30 --> Language Class Initialized
INFO - 2020-09-25 08:53:30 --> Loader Class Initialized
INFO - 2020-09-25 08:53:30 --> Helper loaded: url_helper
INFO - 2020-09-25 08:53:30 --> Helper loaded: file_helper
INFO - 2020-09-25 08:53:30 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:53:30 --> Helper loaded: form_helper
INFO - 2020-09-25 08:53:30 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:53:30 --> Controller Class Initialized
INFO - 2020-09-25 08:53:30 --> Model Class Initialized
INFO - 2020-09-25 08:53:30 --> Final output sent to browser
DEBUG - 2020-09-25 08:53:30 --> Total execution time: 0.1512
INFO - 2020-09-25 08:54:21 --> Config Class Initialized
INFO - 2020-09-25 08:54:21 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:54:21 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:54:21 --> Utf8 Class Initialized
INFO - 2020-09-25 08:54:21 --> URI Class Initialized
INFO - 2020-09-25 08:54:21 --> Router Class Initialized
INFO - 2020-09-25 08:54:21 --> Output Class Initialized
INFO - 2020-09-25 08:54:21 --> Security Class Initialized
DEBUG - 2020-09-25 08:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:54:21 --> Input Class Initialized
INFO - 2020-09-25 08:54:21 --> Language Class Initialized
INFO - 2020-09-25 08:54:21 --> Loader Class Initialized
INFO - 2020-09-25 08:54:21 --> Helper loaded: url_helper
INFO - 2020-09-25 08:54:21 --> Helper loaded: file_helper
INFO - 2020-09-25 08:54:21 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:54:21 --> Helper loaded: form_helper
INFO - 2020-09-25 08:54:21 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:54:21 --> Controller Class Initialized
INFO - 2020-09-25 08:54:21 --> Model Class Initialized
INFO - 2020-09-25 08:54:21 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:54:21 --> File loaded: C:\xampp\htdocs\student_course\application\views\Student/studentListing.php
INFO - 2020-09-25 08:54:21 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:54:21 --> Final output sent to browser
DEBUG - 2020-09-25 08:54:21 --> Total execution time: 0.1138
INFO - 2020-09-25 08:54:29 --> Config Class Initialized
INFO - 2020-09-25 08:54:29 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:54:29 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:54:29 --> Utf8 Class Initialized
INFO - 2020-09-25 08:54:29 --> URI Class Initialized
INFO - 2020-09-25 08:54:29 --> Router Class Initialized
INFO - 2020-09-25 08:54:29 --> Output Class Initialized
INFO - 2020-09-25 08:54:29 --> Security Class Initialized
DEBUG - 2020-09-25 08:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:54:29 --> Input Class Initialized
INFO - 2020-09-25 08:54:29 --> Language Class Initialized
INFO - 2020-09-25 08:54:29 --> Loader Class Initialized
INFO - 2020-09-25 08:54:29 --> Helper loaded: url_helper
INFO - 2020-09-25 08:54:29 --> Helper loaded: file_helper
INFO - 2020-09-25 08:54:29 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:54:29 --> Helper loaded: form_helper
INFO - 2020-09-25 08:54:29 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:54:29 --> Controller Class Initialized
INFO - 2020-09-25 08:54:29 --> Model Class Initialized
INFO - 2020-09-25 08:54:29 --> Final output sent to browser
DEBUG - 2020-09-25 08:54:29 --> Total execution time: 0.1327
INFO - 2020-09-25 08:54:47 --> Config Class Initialized
INFO - 2020-09-25 08:54:47 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:54:47 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:54:47 --> Utf8 Class Initialized
INFO - 2020-09-25 08:54:47 --> URI Class Initialized
INFO - 2020-09-25 08:54:47 --> Router Class Initialized
INFO - 2020-09-25 08:54:47 --> Output Class Initialized
INFO - 2020-09-25 08:54:47 --> Security Class Initialized
DEBUG - 2020-09-25 08:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:54:47 --> Input Class Initialized
INFO - 2020-09-25 08:54:47 --> Language Class Initialized
INFO - 2020-09-25 08:54:47 --> Loader Class Initialized
INFO - 2020-09-25 08:54:47 --> Helper loaded: url_helper
INFO - 2020-09-25 08:54:47 --> Helper loaded: file_helper
INFO - 2020-09-25 08:54:47 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:54:47 --> Helper loaded: form_helper
INFO - 2020-09-25 08:54:47 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:54:47 --> Controller Class Initialized
INFO - 2020-09-25 08:54:47 --> Model Class Initialized
INFO - 2020-09-25 08:54:47 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:54:47 --> File loaded: C:\xampp\htdocs\student_course\application\views\Student/studentListing.php
INFO - 2020-09-25 08:54:47 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:54:47 --> Final output sent to browser
DEBUG - 2020-09-25 08:54:47 --> Total execution time: 0.1152
INFO - 2020-09-25 08:54:51 --> Config Class Initialized
INFO - 2020-09-25 08:54:51 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:54:51 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:54:51 --> Utf8 Class Initialized
INFO - 2020-09-25 08:54:52 --> URI Class Initialized
INFO - 2020-09-25 08:54:52 --> Router Class Initialized
INFO - 2020-09-25 08:54:52 --> Output Class Initialized
INFO - 2020-09-25 08:54:52 --> Security Class Initialized
DEBUG - 2020-09-25 08:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:54:52 --> Input Class Initialized
INFO - 2020-09-25 08:54:52 --> Language Class Initialized
INFO - 2020-09-25 08:54:52 --> Loader Class Initialized
INFO - 2020-09-25 08:54:52 --> Helper loaded: url_helper
INFO - 2020-09-25 08:54:52 --> Helper loaded: file_helper
INFO - 2020-09-25 08:54:52 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:54:52 --> Helper loaded: form_helper
INFO - 2020-09-25 08:54:52 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:54:52 --> Controller Class Initialized
INFO - 2020-09-25 08:54:52 --> Model Class Initialized
INFO - 2020-09-25 08:54:52 --> Final output sent to browser
DEBUG - 2020-09-25 08:54:52 --> Total execution time: 0.1319
INFO - 2020-09-25 08:54:58 --> Config Class Initialized
INFO - 2020-09-25 08:54:58 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:54:58 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:54:58 --> Utf8 Class Initialized
INFO - 2020-09-25 08:54:58 --> URI Class Initialized
INFO - 2020-09-25 08:54:58 --> Router Class Initialized
INFO - 2020-09-25 08:54:58 --> Output Class Initialized
INFO - 2020-09-25 08:54:58 --> Security Class Initialized
DEBUG - 2020-09-25 08:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:54:58 --> Input Class Initialized
INFO - 2020-09-25 08:54:58 --> Language Class Initialized
INFO - 2020-09-25 08:54:58 --> Loader Class Initialized
INFO - 2020-09-25 08:54:58 --> Helper loaded: url_helper
INFO - 2020-09-25 08:54:58 --> Helper loaded: file_helper
INFO - 2020-09-25 08:54:58 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:54:58 --> Helper loaded: form_helper
INFO - 2020-09-25 08:54:58 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:54:58 --> Controller Class Initialized
INFO - 2020-09-25 08:54:58 --> Model Class Initialized
INFO - 2020-09-25 08:54:58 --> Config Class Initialized
INFO - 2020-09-25 08:54:58 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:54:58 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:54:58 --> Utf8 Class Initialized
INFO - 2020-09-25 08:54:58 --> URI Class Initialized
INFO - 2020-09-25 08:54:58 --> Router Class Initialized
INFO - 2020-09-25 08:54:58 --> Output Class Initialized
INFO - 2020-09-25 08:54:58 --> Security Class Initialized
DEBUG - 2020-09-25 08:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:54:58 --> Input Class Initialized
INFO - 2020-09-25 08:54:58 --> Language Class Initialized
INFO - 2020-09-25 08:54:58 --> Loader Class Initialized
INFO - 2020-09-25 08:54:58 --> Helper loaded: url_helper
INFO - 2020-09-25 08:54:58 --> Helper loaded: file_helper
INFO - 2020-09-25 08:54:58 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:54:58 --> Helper loaded: form_helper
INFO - 2020-09-25 08:54:58 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:54:58 --> Controller Class Initialized
INFO - 2020-09-25 08:54:58 --> Model Class Initialized
INFO - 2020-09-25 08:54:58 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:54:58 --> File loaded: C:\xampp\htdocs\student_course\application\views\Student/studentListing.php
INFO - 2020-09-25 08:54:58 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:54:58 --> Final output sent to browser
DEBUG - 2020-09-25 08:54:58 --> Total execution time: 0.0913
INFO - 2020-09-25 08:55:00 --> Config Class Initialized
INFO - 2020-09-25 08:55:00 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:55:00 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:55:00 --> Utf8 Class Initialized
INFO - 2020-09-25 08:55:00 --> URI Class Initialized
INFO - 2020-09-25 08:55:00 --> Router Class Initialized
INFO - 2020-09-25 08:55:00 --> Output Class Initialized
INFO - 2020-09-25 08:55:00 --> Security Class Initialized
DEBUG - 2020-09-25 08:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:55:00 --> Input Class Initialized
INFO - 2020-09-25 08:55:00 --> Language Class Initialized
INFO - 2020-09-25 08:55:00 --> Loader Class Initialized
INFO - 2020-09-25 08:55:00 --> Helper loaded: url_helper
INFO - 2020-09-25 08:55:00 --> Helper loaded: file_helper
INFO - 2020-09-25 08:55:00 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:55:00 --> Helper loaded: form_helper
INFO - 2020-09-25 08:55:00 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:55:00 --> Controller Class Initialized
INFO - 2020-09-25 08:55:00 --> Model Class Initialized
INFO - 2020-09-25 08:55:00 --> Final output sent to browser
DEBUG - 2020-09-25 08:55:00 --> Total execution time: 0.1344
INFO - 2020-09-25 08:58:40 --> Config Class Initialized
INFO - 2020-09-25 08:58:40 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:58:40 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:58:40 --> Utf8 Class Initialized
INFO - 2020-09-25 08:58:40 --> URI Class Initialized
INFO - 2020-09-25 08:58:40 --> Router Class Initialized
INFO - 2020-09-25 08:58:40 --> Output Class Initialized
INFO - 2020-09-25 08:58:40 --> Security Class Initialized
DEBUG - 2020-09-25 08:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:58:40 --> Input Class Initialized
INFO - 2020-09-25 08:58:40 --> Language Class Initialized
INFO - 2020-09-25 08:58:40 --> Loader Class Initialized
INFO - 2020-09-25 08:58:40 --> Helper loaded: url_helper
INFO - 2020-09-25 08:58:40 --> Helper loaded: file_helper
INFO - 2020-09-25 08:58:40 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:58:40 --> Helper loaded: form_helper
INFO - 2020-09-25 08:58:40 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:58:40 --> Controller Class Initialized
INFO - 2020-09-25 08:58:40 --> Model Class Initialized
INFO - 2020-09-25 08:58:40 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:58:40 --> File loaded: C:\xampp\htdocs\student_course\application\views\Course/CourseListing.php
INFO - 2020-09-25 08:58:40 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:58:40 --> Final output sent to browser
DEBUG - 2020-09-25 08:58:40 --> Total execution time: 0.1132
INFO - 2020-09-25 08:58:41 --> Config Class Initialized
INFO - 2020-09-25 08:58:41 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:58:41 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:58:41 --> Utf8 Class Initialized
INFO - 2020-09-25 08:58:41 --> URI Class Initialized
INFO - 2020-09-25 08:58:41 --> Router Class Initialized
INFO - 2020-09-25 08:58:41 --> Output Class Initialized
INFO - 2020-09-25 08:58:41 --> Security Class Initialized
DEBUG - 2020-09-25 08:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:58:41 --> Input Class Initialized
INFO - 2020-09-25 08:58:41 --> Language Class Initialized
INFO - 2020-09-25 08:58:41 --> Loader Class Initialized
INFO - 2020-09-25 08:58:41 --> Helper loaded: url_helper
INFO - 2020-09-25 08:58:41 --> Helper loaded: file_helper
INFO - 2020-09-25 08:58:41 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:58:41 --> Helper loaded: form_helper
INFO - 2020-09-25 08:58:41 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:58:41 --> Controller Class Initialized
INFO - 2020-09-25 08:58:41 --> Model Class Initialized
INFO - 2020-09-25 08:58:41 --> Final output sent to browser
DEBUG - 2020-09-25 08:58:41 --> Total execution time: 0.2194
INFO - 2020-09-25 08:58:44 --> Config Class Initialized
INFO - 2020-09-25 08:58:44 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:58:44 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:58:44 --> Utf8 Class Initialized
INFO - 2020-09-25 08:58:44 --> URI Class Initialized
INFO - 2020-09-25 08:58:44 --> Router Class Initialized
INFO - 2020-09-25 08:58:44 --> Output Class Initialized
INFO - 2020-09-25 08:58:44 --> Security Class Initialized
DEBUG - 2020-09-25 08:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:58:44 --> Input Class Initialized
INFO - 2020-09-25 08:58:44 --> Language Class Initialized
INFO - 2020-09-25 08:58:44 --> Loader Class Initialized
INFO - 2020-09-25 08:58:44 --> Helper loaded: url_helper
INFO - 2020-09-25 08:58:44 --> Helper loaded: file_helper
INFO - 2020-09-25 08:58:44 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:58:44 --> Helper loaded: form_helper
INFO - 2020-09-25 08:58:44 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:58:44 --> Controller Class Initialized
INFO - 2020-09-25 08:58:44 --> Model Class Initialized
INFO - 2020-09-25 08:58:44 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:58:44 --> File loaded: C:\xampp\htdocs\student_course\application\views\Course/editCourseDetails.php
INFO - 2020-09-25 08:58:44 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:58:44 --> Final output sent to browser
DEBUG - 2020-09-25 08:58:44 --> Total execution time: 0.2434
INFO - 2020-09-25 08:58:47 --> Config Class Initialized
INFO - 2020-09-25 08:58:47 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:58:47 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:58:47 --> Utf8 Class Initialized
INFO - 2020-09-25 08:58:47 --> URI Class Initialized
INFO - 2020-09-25 08:58:47 --> Router Class Initialized
INFO - 2020-09-25 08:58:47 --> Output Class Initialized
INFO - 2020-09-25 08:58:47 --> Security Class Initialized
DEBUG - 2020-09-25 08:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:58:47 --> Input Class Initialized
INFO - 2020-09-25 08:58:47 --> Language Class Initialized
INFO - 2020-09-25 08:58:47 --> Loader Class Initialized
INFO - 2020-09-25 08:58:47 --> Helper loaded: url_helper
INFO - 2020-09-25 08:58:47 --> Helper loaded: file_helper
INFO - 2020-09-25 08:58:47 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:58:47 --> Helper loaded: form_helper
INFO - 2020-09-25 08:58:47 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:58:47 --> Controller Class Initialized
INFO - 2020-09-25 08:58:47 --> Model Class Initialized
INFO - 2020-09-25 08:58:47 --> Form Validation Class Initialized
INFO - 2020-09-25 08:58:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-09-25 08:58:47 --> Config Class Initialized
INFO - 2020-09-25 08:58:47 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:58:47 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:58:47 --> Utf8 Class Initialized
INFO - 2020-09-25 08:58:47 --> URI Class Initialized
INFO - 2020-09-25 08:58:47 --> Router Class Initialized
INFO - 2020-09-25 08:58:47 --> Output Class Initialized
INFO - 2020-09-25 08:58:47 --> Security Class Initialized
DEBUG - 2020-09-25 08:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:58:47 --> Input Class Initialized
INFO - 2020-09-25 08:58:47 --> Language Class Initialized
INFO - 2020-09-25 08:58:47 --> Loader Class Initialized
INFO - 2020-09-25 08:58:47 --> Helper loaded: url_helper
INFO - 2020-09-25 08:58:47 --> Helper loaded: file_helper
INFO - 2020-09-25 08:58:47 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:58:47 --> Helper loaded: form_helper
INFO - 2020-09-25 08:58:47 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:58:47 --> Controller Class Initialized
INFO - 2020-09-25 08:58:47 --> Model Class Initialized
INFO - 2020-09-25 08:58:47 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:58:47 --> File loaded: C:\xampp\htdocs\student_course\application\views\Course/editCourseDetails.php
INFO - 2020-09-25 08:58:47 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:58:47 --> Final output sent to browser
DEBUG - 2020-09-25 08:58:47 --> Total execution time: 0.0923
INFO - 2020-09-25 08:58:57 --> Config Class Initialized
INFO - 2020-09-25 08:58:57 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:58:57 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:58:57 --> Utf8 Class Initialized
INFO - 2020-09-25 08:58:57 --> URI Class Initialized
INFO - 2020-09-25 08:58:57 --> Router Class Initialized
INFO - 2020-09-25 08:58:57 --> Output Class Initialized
INFO - 2020-09-25 08:58:57 --> Security Class Initialized
DEBUG - 2020-09-25 08:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:58:57 --> Input Class Initialized
INFO - 2020-09-25 08:58:57 --> Language Class Initialized
INFO - 2020-09-25 08:58:57 --> Loader Class Initialized
INFO - 2020-09-25 08:58:57 --> Helper loaded: url_helper
INFO - 2020-09-25 08:58:57 --> Helper loaded: file_helper
INFO - 2020-09-25 08:58:57 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:58:57 --> Helper loaded: form_helper
INFO - 2020-09-25 08:58:58 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:58:58 --> Controller Class Initialized
INFO - 2020-09-25 08:58:58 --> Model Class Initialized
INFO - 2020-09-25 08:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-09-25 08:58:58 --> Pagination Class Initialized
DEBUG - 2020-09-25 08:58:58 --> Pagination class already loaded. Second attempt ignored.
INFO - 2020-09-25 08:58:58 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:58:58 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/users.php
INFO - 2020-09-25 08:58:58 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:58:58 --> Final output sent to browser
DEBUG - 2020-09-25 08:58:58 --> Total execution time: 0.1268
INFO - 2020-09-25 08:58:58 --> Config Class Initialized
INFO - 2020-09-25 08:58:58 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:58:58 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:58:58 --> Utf8 Class Initialized
INFO - 2020-09-25 08:58:58 --> URI Class Initialized
INFO - 2020-09-25 08:58:58 --> Router Class Initialized
INFO - 2020-09-25 08:58:58 --> Output Class Initialized
INFO - 2020-09-25 08:58:58 --> Security Class Initialized
DEBUG - 2020-09-25 08:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:58:58 --> Input Class Initialized
INFO - 2020-09-25 08:58:58 --> Language Class Initialized
ERROR - 2020-09-25 08:58:58 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:58:58 --> Config Class Initialized
INFO - 2020-09-25 08:58:58 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:58:58 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:58:58 --> Utf8 Class Initialized
INFO - 2020-09-25 08:58:58 --> URI Class Initialized
INFO - 2020-09-25 08:58:58 --> Router Class Initialized
INFO - 2020-09-25 08:58:58 --> Output Class Initialized
INFO - 2020-09-25 08:58:58 --> Security Class Initialized
DEBUG - 2020-09-25 08:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:58:58 --> Input Class Initialized
INFO - 2020-09-25 08:58:58 --> Language Class Initialized
ERROR - 2020-09-25 08:58:58 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:59:14 --> Config Class Initialized
INFO - 2020-09-25 08:59:14 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:59:14 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:59:14 --> Utf8 Class Initialized
INFO - 2020-09-25 08:59:14 --> URI Class Initialized
INFO - 2020-09-25 08:59:14 --> Router Class Initialized
INFO - 2020-09-25 08:59:14 --> Output Class Initialized
INFO - 2020-09-25 08:59:14 --> Security Class Initialized
DEBUG - 2020-09-25 08:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:59:14 --> Input Class Initialized
INFO - 2020-09-25 08:59:14 --> Language Class Initialized
INFO - 2020-09-25 08:59:14 --> Loader Class Initialized
INFO - 2020-09-25 08:59:14 --> Helper loaded: url_helper
INFO - 2020-09-25 08:59:14 --> Helper loaded: file_helper
INFO - 2020-09-25 08:59:14 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:59:14 --> Helper loaded: form_helper
INFO - 2020-09-25 08:59:15 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:59:15 --> Controller Class Initialized
INFO - 2020-09-25 08:59:15 --> Model Class Initialized
ERROR - 2020-09-25 08:59:15 --> Severity: error --> Exception: Call to undefined method User_model::getCenter() C:\xampp\htdocs\student_course\application\controllers\User.php 75
INFO - 2020-09-25 08:59:41 --> Config Class Initialized
INFO - 2020-09-25 08:59:41 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:59:41 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:59:41 --> Utf8 Class Initialized
INFO - 2020-09-25 08:59:41 --> URI Class Initialized
INFO - 2020-09-25 08:59:41 --> Router Class Initialized
INFO - 2020-09-25 08:59:41 --> Output Class Initialized
INFO - 2020-09-25 08:59:41 --> Security Class Initialized
DEBUG - 2020-09-25 08:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:59:41 --> Input Class Initialized
INFO - 2020-09-25 08:59:41 --> Language Class Initialized
INFO - 2020-09-25 08:59:41 --> Loader Class Initialized
INFO - 2020-09-25 08:59:41 --> Helper loaded: url_helper
INFO - 2020-09-25 08:59:41 --> Helper loaded: file_helper
INFO - 2020-09-25 08:59:41 --> Helper loaded: cias_helper
INFO - 2020-09-25 08:59:41 --> Helper loaded: form_helper
INFO - 2020-09-25 08:59:41 --> Database Driver Class Initialized
DEBUG - 2020-09-25 08:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 08:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 08:59:41 --> Controller Class Initialized
INFO - 2020-09-25 08:59:41 --> Model Class Initialized
INFO - 2020-09-25 08:59:41 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 08:59:41 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/addNew.php
INFO - 2020-09-25 08:59:41 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 08:59:41 --> Final output sent to browser
DEBUG - 2020-09-25 08:59:41 --> Total execution time: 0.1516
INFO - 2020-09-25 08:59:42 --> Config Class Initialized
INFO - 2020-09-25 08:59:42 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:59:42 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:59:42 --> Utf8 Class Initialized
INFO - 2020-09-25 08:59:42 --> URI Class Initialized
INFO - 2020-09-25 08:59:42 --> Router Class Initialized
INFO - 2020-09-25 08:59:42 --> Output Class Initialized
INFO - 2020-09-25 08:59:42 --> Security Class Initialized
DEBUG - 2020-09-25 08:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:59:42 --> Input Class Initialized
INFO - 2020-09-25 08:59:42 --> Language Class Initialized
ERROR - 2020-09-25 08:59:42 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 08:59:55 --> Config Class Initialized
INFO - 2020-09-25 08:59:55 --> Hooks Class Initialized
DEBUG - 2020-09-25 08:59:55 --> UTF-8 Support Enabled
INFO - 2020-09-25 08:59:55 --> Utf8 Class Initialized
INFO - 2020-09-25 08:59:55 --> URI Class Initialized
INFO - 2020-09-25 08:59:55 --> Router Class Initialized
INFO - 2020-09-25 08:59:55 --> Output Class Initialized
INFO - 2020-09-25 08:59:55 --> Security Class Initialized
DEBUG - 2020-09-25 08:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 08:59:55 --> Input Class Initialized
INFO - 2020-09-25 08:59:55 --> Language Class Initialized
ERROR - 2020-09-25 08:59:55 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 09:01:13 --> Config Class Initialized
INFO - 2020-09-25 09:01:13 --> Hooks Class Initialized
DEBUG - 2020-09-25 09:01:13 --> UTF-8 Support Enabled
INFO - 2020-09-25 09:01:13 --> Utf8 Class Initialized
INFO - 2020-09-25 09:01:13 --> URI Class Initialized
INFO - 2020-09-25 09:01:13 --> Router Class Initialized
INFO - 2020-09-25 09:01:13 --> Output Class Initialized
INFO - 2020-09-25 09:01:13 --> Security Class Initialized
DEBUG - 2020-09-25 09:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 09:01:13 --> Input Class Initialized
INFO - 2020-09-25 09:01:13 --> Language Class Initialized
INFO - 2020-09-25 09:01:13 --> Loader Class Initialized
INFO - 2020-09-25 09:01:13 --> Helper loaded: url_helper
INFO - 2020-09-25 09:01:13 --> Helper loaded: file_helper
INFO - 2020-09-25 09:01:13 --> Helper loaded: cias_helper
INFO - 2020-09-25 09:01:13 --> Helper loaded: form_helper
INFO - 2020-09-25 09:01:13 --> Database Driver Class Initialized
DEBUG - 2020-09-25 09:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 09:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 09:01:13 --> Controller Class Initialized
INFO - 2020-09-25 09:01:13 --> Model Class Initialized
INFO - 2020-09-25 09:01:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-09-25 09:01:13 --> Pagination Class Initialized
DEBUG - 2020-09-25 09:01:13 --> Pagination class already loaded. Second attempt ignored.
INFO - 2020-09-25 09:01:13 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 09:01:13 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/users.php
INFO - 2020-09-25 09:01:13 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 09:01:13 --> Final output sent to browser
DEBUG - 2020-09-25 09:01:13 --> Total execution time: 0.1113
INFO - 2020-09-25 09:01:13 --> Config Class Initialized
INFO - 2020-09-25 09:01:13 --> Hooks Class Initialized
DEBUG - 2020-09-25 09:01:13 --> UTF-8 Support Enabled
INFO - 2020-09-25 09:01:13 --> Utf8 Class Initialized
INFO - 2020-09-25 09:01:13 --> URI Class Initialized
INFO - 2020-09-25 09:01:13 --> Router Class Initialized
INFO - 2020-09-25 09:01:13 --> Output Class Initialized
INFO - 2020-09-25 09:01:13 --> Security Class Initialized
DEBUG - 2020-09-25 09:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 09:01:13 --> Input Class Initialized
INFO - 2020-09-25 09:01:13 --> Language Class Initialized
ERROR - 2020-09-25 09:01:13 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 09:01:15 --> Config Class Initialized
INFO - 2020-09-25 09:01:15 --> Hooks Class Initialized
DEBUG - 2020-09-25 09:01:15 --> UTF-8 Support Enabled
INFO - 2020-09-25 09:01:15 --> Utf8 Class Initialized
INFO - 2020-09-25 09:01:15 --> URI Class Initialized
INFO - 2020-09-25 09:01:15 --> Router Class Initialized
INFO - 2020-09-25 09:01:15 --> Output Class Initialized
INFO - 2020-09-25 09:01:15 --> Security Class Initialized
DEBUG - 2020-09-25 09:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 09:01:16 --> Input Class Initialized
INFO - 2020-09-25 09:01:16 --> Language Class Initialized
ERROR - 2020-09-25 09:01:16 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 09:01:17 --> Config Class Initialized
INFO - 2020-09-25 09:01:17 --> Hooks Class Initialized
DEBUG - 2020-09-25 09:01:17 --> UTF-8 Support Enabled
INFO - 2020-09-25 09:01:17 --> Utf8 Class Initialized
INFO - 2020-09-25 09:01:17 --> URI Class Initialized
INFO - 2020-09-25 09:01:17 --> Router Class Initialized
INFO - 2020-09-25 09:01:17 --> Output Class Initialized
INFO - 2020-09-25 09:01:17 --> Security Class Initialized
DEBUG - 2020-09-25 09:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 09:01:17 --> Input Class Initialized
INFO - 2020-09-25 09:01:17 --> Language Class Initialized
INFO - 2020-09-25 09:01:17 --> Loader Class Initialized
INFO - 2020-09-25 09:01:17 --> Helper loaded: url_helper
INFO - 2020-09-25 09:01:17 --> Helper loaded: file_helper
INFO - 2020-09-25 09:01:17 --> Helper loaded: cias_helper
INFO - 2020-09-25 09:01:17 --> Helper loaded: form_helper
INFO - 2020-09-25 09:01:17 --> Database Driver Class Initialized
DEBUG - 2020-09-25 09:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 09:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 09:01:17 --> Controller Class Initialized
INFO - 2020-09-25 09:01:17 --> Model Class Initialized
ERROR - 2020-09-25 09:01:17 --> Severity: error --> Exception: Call to undefined method User_model::getUserInfo() C:\xampp\htdocs\student_course\application\controllers\User.php 173
INFO - 2020-09-25 09:02:25 --> Config Class Initialized
INFO - 2020-09-25 09:02:25 --> Hooks Class Initialized
DEBUG - 2020-09-25 09:02:25 --> UTF-8 Support Enabled
INFO - 2020-09-25 09:02:25 --> Utf8 Class Initialized
INFO - 2020-09-25 09:02:25 --> URI Class Initialized
INFO - 2020-09-25 09:02:25 --> Router Class Initialized
INFO - 2020-09-25 09:02:25 --> Output Class Initialized
INFO - 2020-09-25 09:02:25 --> Security Class Initialized
DEBUG - 2020-09-25 09:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 09:02:25 --> Input Class Initialized
INFO - 2020-09-25 09:02:25 --> Language Class Initialized
INFO - 2020-09-25 09:02:25 --> Loader Class Initialized
INFO - 2020-09-25 09:02:25 --> Helper loaded: url_helper
INFO - 2020-09-25 09:02:25 --> Helper loaded: file_helper
INFO - 2020-09-25 09:02:25 --> Helper loaded: cias_helper
INFO - 2020-09-25 09:02:25 --> Helper loaded: form_helper
INFO - 2020-09-25 09:02:25 --> Database Driver Class Initialized
DEBUG - 2020-09-25 09:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-25 09:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-25 09:02:25 --> Controller Class Initialized
INFO - 2020-09-25 09:02:25 --> Model Class Initialized
INFO - 2020-09-25 09:02:25 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-25 09:02:25 --> File loaded: C:\xampp\htdocs\student_course\application\views\User/editOld.php
INFO - 2020-09-25 09:02:25 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-25 09:02:25 --> Final output sent to browser
DEBUG - 2020-09-25 09:02:25 --> Total execution time: 0.1357
INFO - 2020-09-25 09:02:26 --> Config Class Initialized
INFO - 2020-09-25 09:02:26 --> Hooks Class Initialized
DEBUG - 2020-09-25 09:02:26 --> UTF-8 Support Enabled
INFO - 2020-09-25 09:02:26 --> Utf8 Class Initialized
INFO - 2020-09-25 09:02:26 --> URI Class Initialized
INFO - 2020-09-25 09:02:26 --> Router Class Initialized
INFO - 2020-09-25 09:02:26 --> Output Class Initialized
INFO - 2020-09-25 09:02:26 --> Security Class Initialized
DEBUG - 2020-09-25 09:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 09:02:26 --> Input Class Initialized
INFO - 2020-09-25 09:02:26 --> Language Class Initialized
ERROR - 2020-09-25 09:02:26 --> 404 Page Not Found: Assets/js
INFO - 2020-09-25 09:02:39 --> Config Class Initialized
INFO - 2020-09-25 09:02:39 --> Hooks Class Initialized
DEBUG - 2020-09-25 09:02:39 --> UTF-8 Support Enabled
INFO - 2020-09-25 09:02:39 --> Utf8 Class Initialized
INFO - 2020-09-25 09:02:39 --> URI Class Initialized
INFO - 2020-09-25 09:02:39 --> Router Class Initialized
INFO - 2020-09-25 09:02:39 --> Output Class Initialized
INFO - 2020-09-25 09:02:39 --> Security Class Initialized
DEBUG - 2020-09-25 09:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-25 09:02:39 --> Input Class Initialized
INFO - 2020-09-25 09:02:39 --> Language Class Initialized
ERROR - 2020-09-25 09:02:39 --> 404 Page Not Found: Assets/js
