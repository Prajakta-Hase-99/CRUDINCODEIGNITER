<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-17 15:30:14 --> Config Class Initialized
INFO - 2020-09-17 15:30:14 --> Hooks Class Initialized
DEBUG - 2020-09-17 15:30:14 --> UTF-8 Support Enabled
INFO - 2020-09-17 15:30:14 --> Utf8 Class Initialized
INFO - 2020-09-17 15:30:14 --> URI Class Initialized
INFO - 2020-09-17 15:30:14 --> Router Class Initialized
INFO - 2020-09-17 15:30:14 --> Output Class Initialized
INFO - 2020-09-17 15:30:14 --> Security Class Initialized
DEBUG - 2020-09-17 15:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 15:30:14 --> Input Class Initialized
INFO - 2020-09-17 15:30:14 --> Language Class Initialized
INFO - 2020-09-17 15:30:14 --> Loader Class Initialized
INFO - 2020-09-17 15:30:14 --> Helper loaded: url_helper
INFO - 2020-09-17 15:30:14 --> Helper loaded: file_helper
INFO - 2020-09-17 15:30:14 --> Helper loaded: cias_helper
INFO - 2020-09-17 15:30:14 --> Helper loaded: form_helper
INFO - 2020-09-17 15:30:14 --> Database Driver Class Initialized
DEBUG - 2020-09-17 15:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-17 15:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 15:30:14 --> Controller Class Initialized
INFO - 2020-09-17 15:30:14 --> Model Class Initialized
INFO - 2020-09-17 15:30:14 --> Config Class Initialized
INFO - 2020-09-17 15:30:14 --> Hooks Class Initialized
DEBUG - 2020-09-17 15:30:14 --> UTF-8 Support Enabled
INFO - 2020-09-17 15:30:14 --> Utf8 Class Initialized
INFO - 2020-09-17 15:30:14 --> URI Class Initialized
INFO - 2020-09-17 15:30:14 --> Router Class Initialized
INFO - 2020-09-17 15:30:14 --> Output Class Initialized
INFO - 2020-09-17 15:30:14 --> Security Class Initialized
DEBUG - 2020-09-17 15:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 15:30:14 --> Input Class Initialized
INFO - 2020-09-17 15:30:14 --> Language Class Initialized
INFO - 2020-09-17 15:30:14 --> Loader Class Initialized
INFO - 2020-09-17 15:30:14 --> Helper loaded: url_helper
INFO - 2020-09-17 15:30:14 --> Helper loaded: file_helper
INFO - 2020-09-17 15:30:14 --> Helper loaded: cias_helper
INFO - 2020-09-17 15:30:14 --> Helper loaded: form_helper
INFO - 2020-09-17 15:30:14 --> Database Driver Class Initialized
DEBUG - 2020-09-17 15:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-17 15:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 15:30:14 --> Controller Class Initialized
INFO - 2020-09-17 15:30:14 --> Model Class Initialized
INFO - 2020-09-17 15:30:14 --> File loaded: C:\xampp\htdocs\student_course\application\views\login.php
INFO - 2020-09-17 15:30:14 --> Final output sent to browser
DEBUG - 2020-09-17 15:30:14 --> Total execution time: 0.0883
INFO - 2020-09-17 15:30:27 --> Config Class Initialized
INFO - 2020-09-17 15:30:27 --> Hooks Class Initialized
DEBUG - 2020-09-17 15:30:27 --> UTF-8 Support Enabled
INFO - 2020-09-17 15:30:27 --> Utf8 Class Initialized
INFO - 2020-09-17 15:30:27 --> URI Class Initialized
INFO - 2020-09-17 15:30:27 --> Router Class Initialized
INFO - 2020-09-17 15:30:27 --> Output Class Initialized
INFO - 2020-09-17 15:30:27 --> Security Class Initialized
DEBUG - 2020-09-17 15:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 15:30:27 --> Input Class Initialized
INFO - 2020-09-17 15:30:27 --> Language Class Initialized
INFO - 2020-09-17 15:30:27 --> Loader Class Initialized
INFO - 2020-09-17 15:30:27 --> Helper loaded: url_helper
INFO - 2020-09-17 15:30:27 --> Helper loaded: file_helper
INFO - 2020-09-17 15:30:27 --> Helper loaded: cias_helper
INFO - 2020-09-17 15:30:27 --> Helper loaded: form_helper
INFO - 2020-09-17 15:30:27 --> Database Driver Class Initialized
DEBUG - 2020-09-17 15:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-17 15:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 15:30:27 --> Controller Class Initialized
INFO - 2020-09-17 15:30:27 --> Model Class Initialized
INFO - 2020-09-17 15:30:27 --> Form Validation Class Initialized
INFO - 2020-09-17 15:30:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-09-17 15:30:27 --> Query error: Unknown column 'BaseTbl.center_id' in 'field list' - Invalid query: SELECT `BaseTbl`.`userId`, `BaseTbl`.`password`, `BaseTbl`.`name`, `BaseTbl`.`roleId`, `Roles`.`role`, `BaseTbl`.`center_id`
FROM `tbl_users` as `BaseTbl`
JOIN `tbl_roles` as `Roles` ON `Roles`.`roleId` = `BaseTbl`.`roleId`
WHERE `BaseTbl`.`email` = 'admin@gmail.com'
AND `BaseTbl`.`isDeleted` =0
INFO - 2020-09-17 15:30:27 --> Language file loaded: language/english/db_lang.php
INFO - 2020-09-17 15:30:54 --> Config Class Initialized
INFO - 2020-09-17 15:30:54 --> Hooks Class Initialized
DEBUG - 2020-09-17 15:30:54 --> UTF-8 Support Enabled
INFO - 2020-09-17 15:30:54 --> Utf8 Class Initialized
INFO - 2020-09-17 15:30:54 --> URI Class Initialized
INFO - 2020-09-17 15:30:54 --> Router Class Initialized
INFO - 2020-09-17 15:30:54 --> Output Class Initialized
INFO - 2020-09-17 15:30:54 --> Security Class Initialized
DEBUG - 2020-09-17 15:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 15:30:54 --> Input Class Initialized
INFO - 2020-09-17 15:30:54 --> Language Class Initialized
INFO - 2020-09-17 15:30:54 --> Loader Class Initialized
INFO - 2020-09-17 15:30:54 --> Helper loaded: url_helper
INFO - 2020-09-17 15:30:54 --> Helper loaded: file_helper
INFO - 2020-09-17 15:30:54 --> Helper loaded: cias_helper
INFO - 2020-09-17 15:30:54 --> Helper loaded: form_helper
INFO - 2020-09-17 15:30:54 --> Database Driver Class Initialized
DEBUG - 2020-09-17 15:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-17 15:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 15:30:54 --> Controller Class Initialized
INFO - 2020-09-17 15:30:54 --> Model Class Initialized
INFO - 2020-09-17 15:30:54 --> Form Validation Class Initialized
INFO - 2020-09-17 15:30:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-09-17 15:30:54 --> Severity: Notice --> Trying to get property 'createdDtm' of non-object C:\xampp\htdocs\student_course\application\controllers\Login.php 85
INFO - 2020-09-17 15:30:54 --> User Agent Class Initialized
INFO - 2020-09-17 15:30:54 --> Config Class Initialized
INFO - 2020-09-17 15:30:54 --> Hooks Class Initialized
DEBUG - 2020-09-17 15:30:54 --> UTF-8 Support Enabled
INFO - 2020-09-17 15:30:54 --> Utf8 Class Initialized
INFO - 2020-09-17 15:30:54 --> URI Class Initialized
INFO - 2020-09-17 15:30:54 --> Router Class Initialized
INFO - 2020-09-17 15:30:54 --> Output Class Initialized
INFO - 2020-09-17 15:30:54 --> Security Class Initialized
DEBUG - 2020-09-17 15:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 15:30:54 --> Input Class Initialized
INFO - 2020-09-17 15:30:54 --> Language Class Initialized
INFO - 2020-09-17 15:30:54 --> Loader Class Initialized
INFO - 2020-09-17 15:30:54 --> Helper loaded: url_helper
INFO - 2020-09-17 15:30:54 --> Helper loaded: file_helper
INFO - 2020-09-17 15:30:54 --> Helper loaded: cias_helper
INFO - 2020-09-17 15:30:54 --> Helper loaded: form_helper
INFO - 2020-09-17 15:30:54 --> Database Driver Class Initialized
DEBUG - 2020-09-17 15:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-17 15:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 15:30:54 --> Controller Class Initialized
INFO - 2020-09-17 15:30:54 --> Model Class Initialized
INFO - 2020-09-17 15:30:54 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-17 15:30:54 --> File loaded: C:\xampp\htdocs\student_course\application\views\dashboard.php
INFO - 2020-09-17 15:30:54 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-17 15:30:54 --> Final output sent to browser
DEBUG - 2020-09-17 15:30:54 --> Total execution time: 0.0955
INFO - 2020-09-17 15:32:19 --> Config Class Initialized
INFO - 2020-09-17 15:32:19 --> Hooks Class Initialized
DEBUG - 2020-09-17 15:32:19 --> UTF-8 Support Enabled
INFO - 2020-09-17 15:32:19 --> Utf8 Class Initialized
INFO - 2020-09-17 15:32:19 --> URI Class Initialized
INFO - 2020-09-17 15:32:19 --> Router Class Initialized
INFO - 2020-09-17 15:32:19 --> Output Class Initialized
INFO - 2020-09-17 15:32:19 --> Security Class Initialized
DEBUG - 2020-09-17 15:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 15:32:19 --> Input Class Initialized
INFO - 2020-09-17 15:32:19 --> Language Class Initialized
INFO - 2020-09-17 15:32:19 --> Loader Class Initialized
INFO - 2020-09-17 15:32:19 --> Helper loaded: url_helper
INFO - 2020-09-17 15:32:19 --> Helper loaded: file_helper
INFO - 2020-09-17 15:32:19 --> Helper loaded: cias_helper
INFO - 2020-09-17 15:32:19 --> Helper loaded: form_helper
INFO - 2020-09-17 15:32:19 --> Database Driver Class Initialized
DEBUG - 2020-09-17 15:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-17 15:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 15:32:19 --> Controller Class Initialized
INFO - 2020-09-17 15:32:19 --> Model Class Initialized
INFO - 2020-09-17 15:32:19 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-17 15:32:19 --> File loaded: C:\xampp\htdocs\student_course\application\views\dashboard.php
INFO - 2020-09-17 15:32:19 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-17 15:32:19 --> Final output sent to browser
DEBUG - 2020-09-17 15:32:20 --> Total execution time: 0.1124
INFO - 2020-09-17 15:33:10 --> Config Class Initialized
INFO - 2020-09-17 15:33:10 --> Hooks Class Initialized
DEBUG - 2020-09-17 15:33:10 --> UTF-8 Support Enabled
INFO - 2020-09-17 15:33:10 --> Utf8 Class Initialized
INFO - 2020-09-17 15:33:10 --> URI Class Initialized
INFO - 2020-09-17 15:33:10 --> Router Class Initialized
INFO - 2020-09-17 15:33:10 --> Output Class Initialized
INFO - 2020-09-17 15:33:10 --> Security Class Initialized
DEBUG - 2020-09-17 15:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-17 15:33:10 --> Input Class Initialized
INFO - 2020-09-17 15:33:10 --> Language Class Initialized
INFO - 2020-09-17 15:33:10 --> Loader Class Initialized
INFO - 2020-09-17 15:33:10 --> Helper loaded: url_helper
INFO - 2020-09-17 15:33:10 --> Helper loaded: file_helper
INFO - 2020-09-17 15:33:10 --> Helper loaded: cias_helper
INFO - 2020-09-17 15:33:10 --> Helper loaded: form_helper
INFO - 2020-09-17 15:33:10 --> Database Driver Class Initialized
DEBUG - 2020-09-17 15:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-17 15:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-17 15:33:10 --> Controller Class Initialized
INFO - 2020-09-17 15:33:10 --> Model Class Initialized
INFO - 2020-09-17 15:33:10 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/header.php
INFO - 2020-09-17 15:33:10 --> File loaded: C:\xampp\htdocs\student_course\application\views\dashboard.php
INFO - 2020-09-17 15:33:10 --> File loaded: C:\xampp\htdocs\student_course\application\views\includes/footer.php
INFO - 2020-09-17 15:33:10 --> Final output sent to browser
DEBUG - 2020-09-17 15:33:10 --> Total execution time: 0.1190
