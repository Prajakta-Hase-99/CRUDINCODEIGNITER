<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Login (LoginController)
 * Login class to control to authenticate user credentials and starts user's session.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class Login extends CI_Controller
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
       
        $this->load->model('Login_model');
    }

    /**
     * Index Page for this controller.
     */
    public function index()
    {
        // $this->load->view('home');
        $this->load->view('User/login');
        // $this->isLoggedIn();
    }

    public function login()
    {
       $this->load->view('User/header');
        $this->isLoggedIn();

    }
    
    /**
     * This function used to check the user is logged in or not
     */
    function isLoggedIn()
    {
        $isLoggedIn = $this->session->userdata('isLoggedIn');
        
        if(!isset($isLoggedIn) || $isLoggedIn != TRUE)
        {
            $this->load->view('User/login');
        }
        else
        {
            redirect('/dashboard');
        }
    }
    
    
    /**
     * This function used to logged in user
     */
    public function loginMe()
    {
        $this->load->library('form_validation');
        
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|max_length[128]|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|max_length[32]');
        
        if($this->form_validation->run() == FALSE)
        {
            $this->index();
        }
        else
        {
            $email = strtolower($this->security->xss_clean($this->input->post('email')));
            $password = $this->input->post('password');
            
            $result = $this->Login_model->loginMe($email, $password);
            if(!empty($result))
            {
                $lastLogin = $this->Login_model->lastLoginInfo($result->userId);

                $sessionArray = array('userId'=>$result->userId,                    
                                        'role'=>$result->roleId,
                                        'roleText'=>$result->role,
                                        'name'=>$result->name,
                                        'lastLogin'=> $lastLogin->createdDtm,
                                        'isLoggedIn' => TRUE
                                );

                $this->session->set_userdata($sessionArray);

                $_SESSION['mainMenuDetails'] = $this->Login_model->GetParentMenus($result->userId);
                // foreach ($mainMenuDetails as $key => $value) {
                //     $LoginUserRoleName[$value['Access_ID']] = $value;
                // }

            //     print_r($_SESSION['mainMenuDetails']);
            //     // die();

            //     foreach ($_SESSION['mainMenuDetails'] as $key => $access) {
            //     foreach ($_SESSION['mainMenuDetails'] as $k => $val) {
            // // print_r($val);
            // // die();
            // if($val['Parent_Access_ID'] == $access['Access_ID'])
            // {
            //     echo"<br>here<br>";
            //     print_r($access['Access_Label']);
            //       }
            //       else
            //       {
            //         // echo"<br>there</br>";
            //         continue;
            //       }
            //       }

            //     }
                // die();

                unset($sessionArray['userId'], $sessionArray['isLoggedIn'], $sessionArray['lastLogin']);

                $loginInfo = array("userId"=>$result->userId, "sessionData" => json_encode($sessionArray), "machineIp"=>$_SERVER['REMOTE_ADDR'], "userAgent"=>getBrowserAgent(), "agentString"=>$this->agent->agent_string(), "platform"=>$this->agent->platform());



                $this->Login_model->lastLogin($loginInfo);
                
                redirect('/dashboard');
            }
            else
            {
                $this->session->set_flashdata('error', 'Email or password mismatch');
                
                $this->login();
            }
        }
    }

    /**
     * This function used to load forgot password view
     */
    public function forgotPassword()
    {
        $isLoggedIn = $this->session->userdata('isLoggedIn');
        
        if(!isset($isLoggedIn) || $isLoggedIn != TRUE)
        {
			$this->load->view('User/header');
            $this->load->view('User/forgotPassword');
        }
        else
        {
            redirect('/dashboard');
        }
    }
    
    /**
     * This function used to generate reset password request link
     */
    function resetPasswordUser()
    {
        $status = '';
        
        $this->load->library('form_validation');
        
        $this->form_validation->set_rules('login_email','Email','trim|required|valid_email');
                
        if($this->form_validation->run() == FALSE)
        {
            $this->forgotPassword();
        }
        else 
        {
            $email = strtolower($this->security->xss_clean($this->input->post('login_email')));
            
            if($this->Login_model->checkEmailExist($email))
            {
                $encoded_email = urlencode($email);
                
                $this->load->helper('string');
                $data['email'] = $email;
                $data['activation_id'] = random_string('alnum',15);
                $data['createdDtm'] = date('Y-m-d H:i:s');
                $data['agent'] = getBrowserAgent();
                $data['client_ip'] = $this->input->ip_address();
                
                $save = $this->Login_model->resetPasswordUser($data);                
                
                if($save)
                {
                    $data1['reset_link'] = base_url() . "resetPasswordConfirmUser/" . $data['activation_id'] . "/" . $encoded_email;
                    $userInfo = $this->Login_model->getCustomerInfoByEmail($email);

                    if(!empty($userInfo)){
                        $data1["name"] = $userInfo->name;
                        $data1["email"] = $userInfo->email;
                        $data1["message"] = "Reset Your Password";
					}

					// echo APPPATH."third_party\phpmailer\PHPMailerAutoload.php";
					// die;
					$this->load->library('Phpmailer_library');
					$mail = $this->phpmailer_library->load();
 
					$response = false;
                   $subject = 'Reset Password ';
                   $message=base_url() . "resetPasswordConfirmUser/" . $data['activation_id'] . "/" . $encoded_email;
                   $body = "<html>\n"; 
                   $body .= "<body style=\"font-family:Verdana, Verdana, Geneva, sans-serif; font-size:12px; color:#666666;\">\n"; 
                   $body .= "Please click on the below link to reset your password\n"; 
                   $body .= $message; 
                   $email = $this->input->post('login_email');
                   $mail->CharSet = 'UTF-8';
                   $mail->setFrom('student4321@gmail.com','Student');

            //You could either add recepient name or just the email address.
                   $mail->AddAddress($email,"Recepient Name");
                   $mail->AddAddress($email);

            //Address to which recipient will reply
                   $mail->addReplyTo("student4321@gmail.com","Reply");

                   $mail->IsHTML(true);

                   $mail->Subject = $subject;
                   $mail->Body = $body;

            //Send email via SMTP
                   $mail->IsSMTP();
                   $mail->SMTPAuth   = true; 
            		$mail->SMTPSecure = "ssl";  //tls
            		$mail->Host       = "smtp.googlemail.com";
            		$mail->Port       = 465; //you could use port 25, 587, 465 for googlemail
            		$mail->Username   = "student4321@gmail.com";
            		$mail->Password   = "student@123";
            		$sendStatus=$mail->send()  ;

				//	$sendStatus = resetPasswordEmail($data1);
					


                    if($sendStatus){
                        $status = "send";
                        setFlashData($status, "Reset password link sent successfully, please check mails.");
                    } else {
                        $status = "notsend";
                        setFlashData($status, "Email has been failed, try again.");
                    }
                }
                else
                {
                    $status = 'unable';
                    setFlashData($status, "It seems an error while sending your details, try again.");
                }
            }
            else
            {
                $status = 'invalid';
                setFlashData($status, "This email is not registered with us.");
            }
            redirect('/forgotPassword');
        }
    }

    /**
     * This function used to reset the password 
     * @param string $activation_id : This is unique id
     * @param string $email : This is user email
     */
    function resetPasswordConfirmUser($activation_id, $email)
    {
        // Get email and activation code from URL values at index 3-4
        $email = urldecode($email);
        
        // Check activation id in database
        $is_correct = $this->Login_model->checkActivationDetails($email, $activation_id);
        
        $data['email'] = $email;
        $data['activation_code'] = $activation_id;
        
        if ($is_correct == 1)
        {
            $this->load->view('User/newPassword', $data);
        }
        else
        {
            redirect('/login');
        }
    }
    
    /**
     * This function used to create new password for user
     */
    function createPasswordUser()
    {
        $status = '';
        $message = '';
        $email = strtolower($this->input->post("email"));
        $activation_id = $this->input->post("activation_code");
        
        $this->load->library('form_validation');
        
        $this->form_validation->set_rules('password','Password','required|max_length[20]');
        $this->form_validation->set_rules('cpassword','Confirm Password','trim|required|matches[password]|max_length[20]');
        
        if($this->form_validation->run() == FALSE)
        {
            $this->resetPasswordConfirmUser($activation_id, urlencode($email));
        }
        else
        {
            $password = $this->input->post('password');
            $cpassword = $this->input->post('cpassword');
            
            // Check activation id in database
            $is_correct = $this->Login_model->checkActivationDetails($email, $activation_id);
            
            if($is_correct == 1)
            {                
                $this->Login_model->createPasswordUser($email, $password);
                
                $status = 'success';
                $message = 'Password reset successfully';
            }
            else
            {
                $status = 'error';
                $message = 'Password reset failed';
            }
            
            setFlashData($status, $message);

            redirect("/login");
        }
    }
}

?>