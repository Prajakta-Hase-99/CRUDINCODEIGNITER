
<!--css-->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/css/jquery-ui.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/css/bootstrap-select.min.css" />
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/eonasdan-bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.css"> -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/css/AdminLTE.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/css/skin-blue.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/css/jquery.dataTables.min.css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/css/responsive.dataTables.css" />

<!-- <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/css/kendo.common.min.css"/>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/css/kendo.rtl.min.css"/>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/css/kendo.default.min.css"/>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/css/kendo.mobile.all.min.css"/> -->
<link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/css/jquery.fancybox.min.css" media="screen" />
<!-- JS -->
<script src="<?php echo base_url();?>assets/js/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/js/bootstrap-select.min.js"></script>
<script src="<?php echo base_url();?>assets/js/js/jquery.mask.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/js/nicEdit-latest.js"></script>
<!-- <script type="text/javascript" src="<?php echo base_url();?>assets/js/js/kendo.all.min.js"></script> -->
<script src="https://kendo.cdn.telerik.com/2018.1.221/js/kendo.all.min.js" type="text/javascript"></script>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.12.0/moment.js"></script> -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/eonasdan-bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script> -->
<script src="<?php echo base_url();?>assets/js/js/jquery.validate.min.js"></script>
<script src="<?php echo base_url();?>assets/js/js/adminlte.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>assets/js/js/jquery-ui.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>assets/js/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets/js/js/dataTables.responsive.js"></script>
<!-- <script src="<?php echo base_url();?>assets/js/js/kendo.all.min.js" type="text/javascript"></script> -->
<script src="<?php echo base_url();?>assets/js/js/angular.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>assets/js/js/jszip.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>assets/js/js/jquery.fancybox.min.js"></script>
<!-- <script src="<?php echo base_url();?>assets/js/js/bootstrap.bundle.min.js"></script> -->
<!-- <script src="<?php echo base_url();?>assets/js/js/jquery-3.2.1.slim.min.js"></script> -->
<script src="<?php echo base_url();?>assets/js/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/js/popper.js"></script>


