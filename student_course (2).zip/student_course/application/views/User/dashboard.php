<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard
      <small>Control panel</small>
    </h1>
  </section>

  <section class="content">
    <div class="row">
      <div class="col-lg-3 col-xs-6" >
        <div class="small-box bg-red">
           <div class="inner">
          <div class="icon">
            <i class="ion ion-bag"></i>
          </div>
          <div class="row">
              <button type="button" class="btn btn-primary1">
                 <div class="center"><span class="badge">Student</span>
              <br><br>
                <table>
               </table><br><br><br>
             </button>
           </div>           
         </div>
             <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <label class="small-box-footer"></label>
          </div>
        </div>
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-green">
           <div class="inner">
          <div class="icon">
            <i class="ion ion-bag"></i>
          </div>
          <div class="row">
              <button type="button" class="btn btn-primary1">
                 <div class="center"><span class="badge">Notices</span>
              <br><br>
                <table>
               </table><br><br><br>
             </button>
           </div>           
         </div>
               <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <label class="small-box-footer"></label>
            </div>
          </div><!-- ./col -->
          <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-aqua">
              <div class="inner">
          <div class="icon">
            <i class="ion ion-bag"></i>
          </div>
          <div class="row">
              <button type="button" class="btn btn-primary1">
                 <div class="center"><span class="badge">Course</span>
              <br><br>
                <table>
               </table><br><br><br>
             </button>
           </div>           
         </div>
                 <div class="icon">
                  <i class="ion ion-stats-bars"></i>
                </div>
                <label class="small-box-footer"></label>
              </div>
            </div>
            <div class="col-lg-3 col-xs-6" >
              <div class="small-box bg-orange" >
                <div class="inner">
          <div class="icon">
            <i class="ion ion-bag"></i>
          </div>
          <div class="row">
              <button type="button" class="btn btn-primary1">
                 <div class="center"><span class="badge">Notices</span>
              <br><br>
                <table>
               </table><br><br><br>
             </button>
           </div>           
         </div>
                   <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                  <label class="small-box-footer"></label>
                </div>
              </div>
            </section>
          </div>

         