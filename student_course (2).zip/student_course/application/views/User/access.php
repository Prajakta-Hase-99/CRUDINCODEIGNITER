<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-users"></i> Role Management
        <small>Add / Edit Role</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Role Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addUser" action="<?php echo base_url() ?>insertAccess" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                     <div class="col-md-6">
                        <div class="form-group">
                            <label for="cmb_roles">Roles:</label>
                            <select class="form-control selectpicker" id="cmb_roles" name="cmb_roles"  data-live-search="true" data-actions-box="true">
                                 <option> select Roles </option>
                              
                                <?php
                                if(!empty($roles))
                                {
                                    foreach ($roles as $role)
                                        { ?>
                                            <option value="<?php echo $role->roleId; ?>" ><?php echo $role->role; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                      </div>
                            <div class="row">
                                <div class="col-md-6" id="getMultipleArticles">
                                    <div class="form-group">
                                        <?php
                            // $feature_len = sizeof($menu);
                            //print_r($feature_len);die;
                            foreach($menu as $menuaccess)
                            {
                            //$feature[$i] = str_replace("12345", " ", $feature[$i]);
                            ?>
                            <br>
                            <tr><td style="padding:5px 250px;"><input type="checkbox" name="chk_feature[]" id="chk_feature" value="<?php echo $menuaccess->Access_ID;  ?>" /> <?php echo $menuaccess->Access_Name;?>
                            </td></tr>
                            <?php
                            }
                            ?>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>
<script>
  $(document).ready(function(){

  $('#cmb_roles').change(function(){
      var role = $(this).val(); 
      var checkedData = new Array();
      $("input[name='chk_feature[]']").each(function (index, obj) {
        if(this.checked)
        {
          checkedData.push($(this).val());
        }
      });
    getRoleSelected(role);

   // $.ajax({  
   //  url:baseURL+'User/getSelectedMenu',
   //  method: 'post',
   //  data: { role: role  },
   //  dataType:'json',
   //  success: function(response){
   //    console.log(response);             
   //   $.each(response,function(index,data){
   //   }
   //                      },
   //                      error: function (xhr, ajaxOptions, thrownError) {
   //                        alert("error");
   //                      }
   //                    });
 });
  
});
  function getRoleSelected(role)
  {
    $.ajax({
    type: "POST",
    url: baseURL + "User/getAssingedRole",
    dataType: "json",
    data: {role:role},
    success: function (data)
    {
      if(data)
      {
        
        $("#getMultipleArticles").val();
        $("#getMultipleArticles").html(data);

      }
      else
      {
          $("#getMultipleArticles").val();
         $("#getMultipleArticles").text("No Data Found");
      }
       
    },
    error : function ()
    {
       $("#getMultipleArticles").text("No Data Found");
       
    }

  });
  }
</script>