<!DOCTYPE html>

<style>
.input-group-addonL
{
  border-radius: 10px;
  border-color: #121213;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  background-color: #eee;
  width: 50px;
  padding-top: 15px;
  margin-bottom: 0;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  color: #2d2e2f;
  text-align: center;
  border: 1px solid #ced4da;
}
</style>
<html>
<head>
  <meta charset="UTF-8">
  <title>BSSK | Admin System Log in</title>
  <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
  <link href="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url(); ?>assets/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url(); ?>assets/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <!-- Google Font -->
        <!--<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">-->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800|Sacramento" rel="stylesheet">

        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/animate.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/owl.carousel.min.css">

        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/fonts/ionicons/css/ionicons.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/fonts/fontawesome/css/font-awesome.min.css">

        <!-- <link rel="stylesheet" href="<?php echo base_url(); ?>assets/fonts/flaticon/font/flaticon.css"> -->

        <!-- Theme Style -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
      </head>


    </head>
    <body>
      <section class="section bg-light">
        <!--<section class="hold-transition login-page">-->
        <div class="login-box">
          <div class="login-logo">
            <a href="#"><b></b><br><br></a>
          </div><!-- /.login-logo -->
          <div class="login-box-body">
            <p class="login-box-msg">Sign In</p>
            <?php $this->load->helper('form'); ?>
            <div class="row">
              <div class="col-md-12">
                <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
              </div>
            </div>
            <?php
            $this->load->helper('form');
            $error = $this->session->flashdata('error');
            if($error)
            {
              ?>
              <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error; ?>                    
              </div>
              <?php }
              $success = $this->session->flashdata('success');
              if($success)
              {
                ?>
                <div class="alert alert-success alert-dismissable">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <?php echo $success; ?>                    
                </div>
                <?php } ?>
                <form action="<?php echo base_url(); ?>loginMe" method="post">

                  <div class="form-group input-group margin-bottom-sm">
                    <span class="input-group-addonL"><i class="fa fa-envelope-o fa-fw fa-2x "></i></span>
                    <input class="form-control" type="text" placeholder="Email address" name="email" required/>
                  </div>

                  <div class=" form-group input-group">
                    <span class="input-group-addonL"><i class="fa fa-key fa-fw  fa-2x"></i></span>
                    <input class="form-control" type="password" placeholder="Password" name="password" required/ >
                  </div>
          <!-- <div class="form-group has-feedback">
            <input type="email" class="form-control" placeholder="Email" name="email" required />
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
             <span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
            <input type="password" class="form-control" placeholder="Password" name="password" required />
            <!-- <span class="glyphicon glyphicon-lock form-control-feedback"></span> -->
            <!--</div> -->
            <div class="row">
              <div class="col-xs-8">    
              <!-- <div class="checkbox icheck">
                <label>
                  <input type="checkbox"> Remember Me
                </label>
              </div>  -->                       
            </div><!-- /.col -->
            <div class="col-xs-4">
              <input type="submit" class="btn btn-primary btn-block btn-flat" value="Sign In" />
            </div><!-- /.col -->
          </div>
        </form>

        <a href="<?php echo base_url() ?>forgotPassword">Forgot Password</a><br>
        
      </div><!-- /.login-box-body -->
      <!--</div>--><!-- /.login-box -->

      <script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
      <script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    </section>
  </body>
  </html>