-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2020 at 03:35 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_course`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_access_rights`
--

CREATE TABLE `tbl_access_rights` (
  `Access_ID` int(11) NOT NULL,
  `Access_Name` varchar(100) NOT NULL,
  `Status` char(1) NOT NULL,
  `Used_For` tinytext NOT NULL COMMENT 'Funtions of the Menu',
  `Access_Label` varchar(100) NOT NULL,
  `Parent_Access_ID` int(11) NOT NULL,
  `Display_Order` int(3) NOT NULL,
  `Access_View` varchar(100) NOT NULL,
  `Icon_class` varchar(50) NOT NULL,
  `Go_Back_View` varchar(100) NOT NULL,
  `Creation_Date` date NOT NULL,
  `Created_By` int(11) NOT NULL,
  `Change_Date` date NOT NULL,
  `Changed_By` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_access_rights`
--

INSERT INTO `tbl_access_rights` (`Access_ID`, `Access_Name`, `Status`, `Used_For`, `Access_Label`, `Parent_Access_ID`, `Display_Order`, `Access_View`, `Icon_class`, `Go_Back_View`, `Creation_Date`, `Created_By`, `Change_Date`, `Changed_By`) VALUES
(1, 'HOME', 'A', '', 'Dashboard', 0, 1, 'dashboard', 'fa fa-dashboard', '', '0000-00-00', 1005, '0000-00-00', 1005),
(2, 'STUDENT', 'A', '', 'Student', 0, 2, 'student', 'fa fa-graduation-cap', '', '0000-00-00', 1005, '0000-00-00', 1005),
(3, 'COURSE', 'A', '', 'Course', 0, 3, 'course', 'fa fa-book', '', '0000-00-00', 1005, '0000-00-00', 1005);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course_master`
--

CREATE TABLE `tbl_course_master` (
  `id` int(11) NOT NULL,
  `course_name` varchar(100) DEFAULT NULL,
  `course_type` varchar(100) NOT NULL,
  `course_duration` varchar(100) DEFAULT NULL,
  `createdBy` int(10) DEFAULT NULL,
  `createdDtm` datetime DEFAULT NULL,
  `updatedBy` int(10) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_course_master`
--

INSERT INTO `tbl_course_master` (`id`, `course_name`, `course_type`, `course_duration`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'Demo', 'Demo', '2 year', 1, '2020-09-17 15:06:55', 1, '2020-09-17 15:20:11'),
(2, 'Demo', 'Demo', '2 year', 1, '2020-09-17 15:19:28', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_last_login`
--

CREATE TABLE `tbl_last_login` (
  `id` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  `sessionData` varchar(2048) NOT NULL,
  `machineIp` varchar(1024) NOT NULL,
  `userAgent` varchar(128) NOT NULL,
  `agentString` varchar(1024) NOT NULL,
  `platform` varchar(128) NOT NULL,
  `createdDtm` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_last_login`
--

INSERT INTO `tbl_last_login` (`id`, `userId`, `sessionData`, `machineIp`, `userAgent`, `agentString`, `platform`, `createdDtm`) VALUES
(1, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"System Administrator\",\"center_id\":\"1\",\"center_name\":\"Bharatiya Samaj Seva Kendra \",\"city\":\"2763\",\"c_name\":\"Pune\",\"center_code\":\"PN\"}', '123.201.100.129', 'Chrome 76.0.3809.100', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 'Windows 7', '0000-00-00 00:00:00'),
(2296, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2297, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2298, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2299, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2300, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2301, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2302, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2303, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2304, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2305, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2306, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2307, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2308, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2309, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2310, 1, '{\"role\":\"1\",\"roleText\":\"System Administrator\",\"name\":\"Snehal Hase\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00'),
(2311, 2, '{\"role\":\"2\",\"roleText\":\"Admin\",\"name\":\"Shardul\"}', '::1', 'Chrome 85.0.4183.102', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'Windows 8.1', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_roles`
--

CREATE TABLE `tbl_roles` (
  `roleId` tinyint(4) NOT NULL COMMENT 'role id',
  `role` varchar(50) NOT NULL COMMENT 'role text'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_roles`
--

INSERT INTO `tbl_roles` (`roleId`, `role`) VALUES
(1, 'System Administrator'),
(2, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_role_access_rights`
--

CREATE TABLE `tbl_role_access_rights` (
  `Roles_Access_Rights_ID` int(11) NOT NULL,
  `Role_ID` int(11) NOT NULL,
  `Access_ID` int(11) NOT NULL,
  `Status` char(1) NOT NULL,
  `Creation_Date` date NOT NULL,
  `Created_By` int(11) NOT NULL,
  `Change_Date` date NOT NULL,
  `Changed_By` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_role_access_rights`
--

INSERT INTO `tbl_role_access_rights` (`Roles_Access_Rights_ID`, `Role_ID`, `Access_ID`, `Status`, `Creation_Date`, `Created_By`, `Change_Date`, `Changed_By`) VALUES
(1, 1, 1, 'A', '2018-11-06', 10000, '2018-11-06', 10000),
(2, 1, 2, 'A', '2018-11-06', 10000, '2018-11-06', 10000),
(3, 1, 3, 'A', '2018-11-06', 10000, '2018-11-06', 10000),
(4, 2, 1, 'A', '0000-00-00', 0, '0000-00-00', 0),
(5, 2, 2, 'A', '2020-09-08', 1000, '2020-09-09', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student_master`
--

CREATE TABLE `tbl_student_master` (
  `id` int(10) NOT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `student_gender` enum('F','M') DEFAULT NULL,
  `student_birth_date` date DEFAULT NULL,
  `student_admit_date` date DEFAULT NULL,
  `student_admit_status` varchar(20) DEFAULT NULL,
  `remark` varchar(500) DEFAULT NULL,
  `status` varchar(10) DEFAULT 'active',
  `createdBy` int(10) DEFAULT NULL,
  `createdDtm` datetime DEFAULT NULL,
  `updatedBy` int(10) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_student_master`
--

INSERT INTO `tbl_student_master` (`id`, `student_name`, `student_gender`, `student_birth_date`, `student_admit_date`, `student_admit_status`, `remark`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'Snehal', 'F', '1996-09-05', '2020-09-01', 'Admit', 'ok', 'active', 1, '2020-09-17 12:55:09', NULL, NULL),
(2, 'Shardul', 'M', '2003-01-08', '2020-09-01', 'NAdmit', 'ok', 'deactive', 1, '2020-09-17 13:44:06', 1, '2020-09-17 13:50:47');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `userId` int(11) NOT NULL,
  `email` varchar(128) NOT NULL COMMENT 'login email',
  `password` varchar(128) NOT NULL COMMENT 'hashed login password',
  `name` varchar(128) NOT NULL COMMENT 'full name of user',
  `mobile` varchar(20) DEFAULT NULL,
  `roleId` tinyint(4) NOT NULL,
  `isDeleted` tinyint(4) NOT NULL DEFAULT 0,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`userId`, `email`, `password`, `name`, `mobile`, `roleId`, `isDeleted`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`) VALUES
(1, 'superadmin@gmail.com', '$2y$10$LPs0rd072pOODkIFPbpdreYSYEumam3IhUQsemLWTqzNBJxiQHS2e', 'Snehal Hase', '7878787878', 1, 0, 0, '2015-07-01 18:56:49', 1, '2020-09-17 15:24:13'),
(2, 'admin@gmail.com', '$2y$10$LPs0rd072pOODkIFPbpdreYSYEumam3IhUQsemLWTqzNBJxiQHS2e', 'Shardul', '9898989998', 2, 0, 100, '2020-09-23 18:54:49', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_access_rights`
--
ALTER TABLE `tbl_access_rights`
  ADD PRIMARY KEY (`Access_ID`);

--
-- Indexes for table `tbl_course_master`
--
ALTER TABLE `tbl_course_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_last_login`
--
ALTER TABLE `tbl_last_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_roles`
--
ALTER TABLE `tbl_roles`
  ADD PRIMARY KEY (`roleId`);

--
-- Indexes for table `tbl_role_access_rights`
--
ALTER TABLE `tbl_role_access_rights`
  ADD PRIMARY KEY (`Roles_Access_Rights_ID`);

--
-- Indexes for table `tbl_student_master`
--
ALTER TABLE `tbl_student_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`userId`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `FK_tbl_users_tbl_roles` (`roleId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_access_rights`
--
ALTER TABLE `tbl_access_rights`
  MODIFY `Access_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;

--
-- AUTO_INCREMENT for table `tbl_course_master`
--
ALTER TABLE `tbl_course_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_last_login`
--
ALTER TABLE `tbl_last_login`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2312;

--
-- AUTO_INCREMENT for table `tbl_roles`
--
ALTER TABLE `tbl_roles`
  MODIFY `roleId` tinyint(4) NOT NULL AUTO_INCREMENT COMMENT 'role id', AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_role_access_rights`
--
ALTER TABLE `tbl_role_access_rights`
  MODIFY `Roles_Access_Rights_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1204;

--
-- AUTO_INCREMENT for table `tbl_student_master`
--
ALTER TABLE `tbl_student_master`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
